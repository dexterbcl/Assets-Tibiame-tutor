// Pasta das imagens do Amorpheon (se as imagens nao aparecerem, confira aqui se o nome da pasta
// esta igual ao do celular, inclusive maiusculas/minusculas).
var IMG_AMORPHEON = "img/bosses/amorpheon/";

// Pasta dos icones de elementos (fire, hit, ice, light, soul .png). Se os icones nao aparecerem,
// confira se o nome da pasta esta igual ao do celular, inclusive maiusculas/minusculas.
// O codigo tenta tambem a versao em MAIUSCULAS (IMG/ELEMENTOS/) automaticamente.
var IMG_ELEMENTOS = "img/elementos/";

var DB_TIBIAME = {
    Bosses: [
        {
            nome: "3 Dogs",
            ataques: "Físico e Fogo",
            fraqueza: "Raio",
            level: "100+",
            ilha: "Ashmor",
            hp: "43.470 HP (cada cachorro) + 14.900 HP (Hellflame)",
            xp: "36.000 EP (até 2 players) / 12.000 EP (3-6) / 7.200 EP (7-10) / 1.100 EP (11+)",
            gold: "900 Gold",
            drops: "Hellfire Bulwark (Armadura), Demonic Shield (Escudo), Talisman (Amuleto), Burning Ore (Minério usado para melhorar equipamentos)",
            recompensasBoss: "Demonic Relic",
            imagem: "img/bosses/3dogs/Fluffy.png",
            mobs: [
                {
                    nome: "Fluffy",
                    ataques: "Fogo",
                    fraqueza: "Raio",
                    level: "80+",
                    ilha: "Ashmor",
                    hp: "43.470 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Demonic Relic",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/3dogs/Fluffy.png"
                },
                {
                    nome: "Buffy",
                    ataques: "Físico e Fogo",
                    fraqueza: "Raio",
                    level: "80+",
                    ilha: "Ashmor",
                    hp: "43.470 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Demonic Relic",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/3dogs/Buffy.png"
                },
                {
                    nome: "Ruffy",
                    ataques: "Físico",
                    fraqueza: "Raio",
                    level: "80+",
                    ilha: "Ashmor",
                    hp: "43.470 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Demonic Relic",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/3dogs/Ruffy.png"
                },
                {
                    nome: "Hellflame",
                    ataques: "Fogo",
                    fraqueza: "Gelo",
                    level: "65+",
                    ilha: "Ashmor",
                    hp: "14.900 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/3dogs/Hellflame.png"
                }
            ]
        },
        {
            nome: "Akrathes",
            ataques: "Físico e Sagrado",
            fraqueza: "Fogo e Sagrado",
            level: "120/140+",
            ilha: "Solahmar",
            hp: "79.803 HP (Akrathes) + 5.840 HP (Guardian) + 4.750 HP (Soultaken) + 1.717 HP (Sentinel)",
            xp: "36.000 EP (até 2 players) / 12.000 EP (3-6) / 7.200 EP (7-10) / 1.100 EP (11+)",
            gold: "900/1000 Gold",
            drops: "Forcebender Ring, Brute Force, Leveller, Chain of Force, K'a Shard",
            recompensasBoss: "Recompensa da Boss Battle (até 36.000 EP)",
            imagem: "img/bosses/akrathes/akrathes.png",
            mobs: [
                {
                    nome: "Akrathes",
                    ataques: "Físico e Sagrado",
                    fraqueza: "Fogo e Sagrado",
                    level: "+80",
                    ilha: "Solahmar",
                    hp: "79.803 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Forcebender Ring, Brute Force, Leveller, Chain of Force, K'a Shard",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/akrathes/akrathes.png"
                },
                {
                    nome: "Guardian",
                    ataques: "Físico e Gelo",
                    fraqueza: "Sagrado",
                    level: "+80",
                    ilha: "Solahmar",
                    hp: "5.840 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/akrathes/guardian.png"
                },
                {
                    nome: "Sentinel",
                    ataques: "Físico e Gelo",
                    fraqueza: "Fogo",
                    level: "+80",
                    ilha: "Solahmar",
                    hp: "1.717 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/akrathes/sentinel.png"
                },
                {
                    nome: "Soultaken",
                    ataques: "Gelo e Raio",
                    fraqueza: "Físico",
                    level: "+80",
                    ilha: "Solahmar",
                    hp: "4.750 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/akrathes/soultaken.png"
                }
            ]
        },
        {
            nome: "Amorpheon",
            ataques: "Varia por forma (veja cada uma)",
            fraqueza: "Varia por forma (veja cada uma)",
            level: "150+",
            ilha: "Ephialtis",
            hp: "96.870 HP (Amorpheon 1ª e 2ª) + 6.277 HP (Transformação de Fogo) + 5.744 HP (Lightmorph) + 7.832 HP (Coldmorph) + 6.633 HP (Metamorfose da Alma) + 957 HP (Frostisso) + 854 HP (Biestig) + 798 HP (Acrathes) + 712 HP (Chilong)",
            xp: "36.000 EP (até 2 players) / 12.000 EP (3-6) / 7.200 EP (7-10) / 1.100 EP (11+)",
            gold: "1.000 Gold",
            drops: "Morphing Bag, Raw Material",
            recompensasBoss: "Recompensa da Boss Battle (até 36.000 EP)",
            imagem: IMG_AMORPHEON + "mummy.png",
            mobs: [
                {
                    nome: "Acrathes",
                    ataques: "Físico e Sagrado",
                    fraqueza: "Fogo",
                    level: "100/120+",
                    ilha: "Ephialtis",
                    hp: "798 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: IMG_AMORPHEON + "mummy.png"
                },
                {
                    nome: "Biestig",
                    ataques: "Fogo e Sagrado",
                    fraqueza: "Raio",
                    level: "100/120+",
                    ilha: "Ephialtis",
                    hp: "854 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: IMG_AMORPHEON + "demon.png"
                },
                {
                    nome: "Chilong",
                    ataques: "Gelo e Raio",
                    fraqueza: "Físico",
                    level: "100/120+",
                    ilha: "Ephialtis",
                    hp: "712 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: IMG_AMORPHEON + "long.png"
                },
                {
                    nome: "Frostisso",
                    ataques: "Físico e Gelo",
                    fraqueza: "Fogo",
                    level: "100/120+",
                    ilha: "Ephialtis",
                    hp: "957 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: IMG_AMORPHEON + "icedragon.png"
                },
                {
                    nome: "Amorpheon (1ª) - Terra",
                    ataques: "Físico e Sagrado",
                    fraqueza: "Fogo",
                    level: "100/120+",
                    ilha: "Ephialtis",
                    hp: "96.870 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Morphing Bag, Raw Material",
                    recompensasBoss: "A definir",
                    imagem: IMG_AMORPHEON + "mummy.png"
                },
                {
                    nome: "Amorpheon (1ª) - Fogo",
                    ataques: "Fogo e Sagrado",
                    fraqueza: "Raio",
                    level: "100/120+",
                    ilha: "Ephialtis",
                    hp: "96.870 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Morphing Bag, Raw Material",
                    recompensasBoss: "A definir",
                    imagem: IMG_AMORPHEON + "demon.png"
                },
                {
                    nome: "Amorpheon (1ª) - Raio",
                    ataques: "Gelo e Raio",
                    fraqueza: "Físico",
                    level: "100/120+",
                    ilha: "Ephialtis",
                    hp: "96.870 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Morphing Bag, Raw Material",
                    recompensasBoss: "A definir",
                    imagem: IMG_AMORPHEON + "long.png"
                },
                {
                    nome: "Amorpheon (1ª) - Gelo",
                    ataques: "Físico e Gelo",
                    fraqueza: "Fogo",
                    level: "100/120+",
                    ilha: "Ephialtis",
                    hp: "96.870 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Morphing Bag, Raw Material",
                    recompensasBoss: "A definir",
                    imagem: IMG_AMORPHEON + "icedragon.png"
                },
                {
                    nome: "Amorpheon (2ª) - Terra",
                    ataques: "Físico e Sagrado",
                    fraqueza: "Fogo",
                    level: "100/120+",
                    ilha: "Ephialtis",
                    hp: "96.870 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: IMG_AMORPHEON + "mummy.png"
                },
                {
                    nome: "Amorpheon (2ª) - Fogo",
                    ataques: "Fogo e Sagrado",
                    fraqueza: "Raio",
                    level: "100/120+",
                    ilha: "Ephialtis",
                    hp: "96.870 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: IMG_AMORPHEON + "demon.png"
                },
                {
                    nome: "Amorpheon (2ª) - Raio",
                    ataques: "Gelo e Raio",
                    fraqueza: "Físico",
                    level: "100/120+",
                    ilha: "Ephialtis",
                    hp: "96.870 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: IMG_AMORPHEON + "long.png"
                },
                {
                    nome: "Amorpheon (2ª) - Gelo",
                    ataques: "Físico e Gelo",
                    fraqueza: "Fogo",
                    level: "100/120+",
                    ilha: "Ephialtis",
                    hp: "96.870 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: IMG_AMORPHEON + "icedragon.png"
                },
                {
                    nome: "Transformação de Fogo",
                    ataques: "Fogo",
                    fraqueza: "Gelo",
                    level: "100/120+",
                    ilha: "Ephialtis",
                    hp: "6.277 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: IMG_AMORPHEON + "flame.png"
                },
                {
                    nome: "Lightmorph",
                    ataques: "Físico e Raio",
                    fraqueza: "Gelo",
                    level: "100/120+",
                    ilha: "Ephialtis",
                    hp: "5.744 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: IMG_AMORPHEON + "wisp.png"
                },
                {
                    nome: "Coldmorph",
                    ataques: "Físico e Gelo",
                    fraqueza: "Fogo",
                    level: "100/120+",
                    ilha: "Ephialtis",
                    hp: "7.832 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: IMG_AMORPHEON + "captor.png"
                },
                {
                    nome: "Metamorfose da Alma",
                    ataques: "Gelo e Sagrado",
                    fraqueza: "Sagrado",
                    level: "100/120+",
                    ilha: "Ephialtis",
                    hp: "6.633 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: IMG_AMORPHEON + "forgotten.png"
                }
            ]
        },
        {
            nome: "Crush",
            ataques: "Físico",
            fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
            level: "48+",
            ilha: "Vargos (2º andar)",
            hp: "9.000 HP (Crush) + 2.820 HP (Fire Guard)",
            xp: "Jewel Of Experience (3.000 EP)",
            gold: "500 Gold",
            drops: "Frost Smasher (Arma Warrior), Necklace Of Crush (Amuleto Warrior/Wizard), Magma Pants (Armadura Wizard)",
            recompensasBoss: "Jewel Of Experience (3.000 EP)",
            imagem: "img/bosses/Crush/cyclops.png",
            mobs: [
                {
                    nome: "Crush",
                    ataques: "Físico",
                    fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
                    level: "A definir",
                    ilha: "Vargos",
                    hp: "9.000 HP",
                    xp: "Recompensa da Boss Battle (Jewel Of Experience 3.000 EP)",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Crush/cyclops.png"
                },
                {
                    nome: "Fire Guard",
                    ataques: "Fogo",
                    fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
                    level: "A definir",
                    ilha: "Vargos",
                    hp: "2.820 HP",
                    xp: "Recompensa da Boss Battle (Jewel Of Experience 3.000 EP)",
                    gold: "0",
                    drops: "Fire Essence",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Crush/flame.png"
                }
            ]
        },
        {
            nome: "Oculus",
            ataques: "Físico e Fogo",
            fraqueza: "Gelo",
            level: "48+",
            ilha: "Vargos (5º andar)",
            hp: "2.420 HP (Oculus) + 1.210 HP (cada: Gazer, Watcher, Eye)",
            xp: "Jewel Of Experience (3.000 EP)",
            gold: "500 Gold",
            drops: "Blessed Greatstaff (Arma Wizard), Magma Legguards (Calça Warrior), Magma Aegis (Escudo Wizard)",
            recompensasBoss: "Jewel Of Experience (3.000 EP)",
            imagem: "img/bosses/Oculus/eye.png",
            mobs: [
                {
                    nome: "Oculus",
                    ataques: "Físico e Fogo",
                    fraqueza: "Gelo",
                    level: "A definir",
                    ilha: "Vargos",
                    hp: "2.420 HP",
                    xp: "Recompensa da Boss Battle (Jewel Of Experience 3.000 EP)",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Oculus/eye.png"
                },
                {
                    nome: "Gazer",
                    ataques: "Físico e Fogo",
                    fraqueza: "Gelo",
                    level: "A definir",
                    ilha: "Vargos",
                    hp: "1.210 HP",
                    xp: "Recompensa da Boss Battle (Jewel Of Experience 3.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Oculus/eye.png"
                },
                {
                    nome: "Watcher",
                    ataques: "Físico e Fogo",
                    fraqueza: "Gelo",
                    level: "A definir",
                    ilha: "Vargos",
                    hp: "1.210 HP",
                    xp: "Recompensa da Boss Battle (Jewel Of Experience 3.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Oculus/eye.png"
                },
                {
                    nome: "Eye",
                    ataques: "Físico e Fogo",
                    fraqueza: "Gelo",
                    level: "A definir",
                    ilha: "Vargos",
                    hp: "1.210 HP",
                    xp: "Recompensa da Boss Battle (Jewel Of Experience 3.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Oculus/eye.png"
                }
            ]
        },
        {
            nome: "Arkanis",
            ataques: "Físico",
            fraqueza: "Gelo",
            level: "48+",
            ilha: "Vargos (6º andar)",
            hp: "14.933 HP (Arkanis) + 1.243 HP (Drakewhelp)",
            xp: "Jewel Of Experience (3.000 EP)",
            gold: "500 Gold",
            drops: "Edge Of Storm (Arma Warrior), Magma Cuirass (Armadura Warrior), Broodmother Ring (Anel Warrior/Wizard)",
            recompensasBoss: "Jewel Of Experience (3.000 EP)",
            imagem: "img/bosses/Arkanis/dragon.png",
            mobs: [
                {
                    nome: "Arkanis",
                    ataques: "Físico",
                    fraqueza: "Gelo",
                    level: "A definir",
                    ilha: "Vargos",
                    hp: "14.933 HP",
                    xp: "Recompensa da Boss Battle (Jewel Of Experience 3.000 EP)",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Arkanis/dragon.png"
                },
                {
                    nome: "Drakewhelp",
                    ataques: "Fogo",
                    fraqueza: "Gelo",
                    level: "A definir",
                    ilha: "Vargos",
                    hp: "1.243 HP",
                    xp: "Recompensa da Boss Battle (Jewel Of Experience 3.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Arkanis/firedrake.png"
                }
            ]
        },
        {
            nome: "Hieronymus",
            ataques: "Físico e Fogo",
            fraqueza: "Físico",
            level: "48+ (rec. 70)",
            ilha: "Vargos (7º andar)",
            hp: "21.682 HP (Hieronymus) + 1 HP (Clone)",
            xp: "Jewel Of Experience (3.000 EP)",
            gold: "500 Gold",
            drops: "Eye Of Cyclone (Arma Wizard), Magma Robe (Armadura Wizard), Magma Bulwark (Escudo Warrior)",
            recompensasBoss: "Jewel Of Experience (3.000 EP)",
            imagem: "img/bosses/Hieronymus/apprentice.png",
            mobs: [
                {
                    nome: "Hieronymus",
                    ataques: "Físico e Fogo",
                    fraqueza: "Físico",
                    level: "A definir",
                    ilha: "Vargos",
                    hp: "21.682 HP",
                    xp: "Recompensa da Boss Battle (Jewel Of Experience 3.000 EP)",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Hieronymus/apprentice.png"
                },
                {
                    nome: "Hieronymus (Clone)",
                    ataques: "Físico e Fogo",
                    fraqueza: "Físico",
                    level: "A definir",
                    ilha: "Vargos",
                    hp: "1 HP",
                    xp: "Recompensa da Boss Battle (Jewel Of Experience 3.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Hieronymus/apprentice.png"
                }
            ]
        },
        {
            nome: "Chilong (N)",
            ataques: "Físico e Raio",
            fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
            level: "30+",
            ilha: "Yabutu (cidade)",
            hp: "20.000 HP (Chilong) + 2.750 HP (Earthvant) + 420 HP (Stomacid)",
            xp: "Jewel Of Experience (1.100 EP)",
            gold: "100 Gold",
            drops: "Green Belt (Calça Wizard), Green Hardbelt (Calça Warrior), Health Potion, Miracle Herb",
            recompensasBoss: "Jewel Of Experience (1.100 EP)",
            imagem: "img/bosses/Chilong (N)/long.png",
            mobs: [
                {
                    nome: "Chilong",
                    ataques: "Físico e Raio",
                    fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
                    level: "A definir",
                    ilha: "Yabutu",
                    hp: "20.000 HP",
                    xp: "Recompensa da Boss Battle (Jewel Of Experience 1.100 EP)",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Chilong (N)/long.png"
                },
                {
                    nome: "Earthvant",
                    ataques: "Raio",
                    fraqueza: "Fogo",
                    level: "A definir",
                    ilha: "Yabutu",
                    hp: "2.750 HP",
                    xp: "Recompensa da Boss Battle (Jewel Of Experience 1.100 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Chilong (N)/kappa.png"
                },
                {
                    nome: "Stomacid",
                    ataques: "Raio",
                    fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
                    level: "A definir",
                    ilha: "Yabutu",
                    hp: "420 HP",
                    xp: "Recompensa da Boss Battle (Jewel Of Experience 1.100 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Chilong (N)/slime.png"
                }
            ]
        },
        {
            nome: "Chilong (H)",
            ataques: "Gelo e Raio",
            fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
            level: "70+",
            ilha: "Yabutu (cidade)",
            hp: "40.000 HP (Chilong) + 9.510 HP (Dragon Son) + 7.010 HP (Earthvant) + 1.070 HP (Stomacid)",
            xp: "36.000 EP (até 2 players) / 12.000 EP (3-6) / 7.200 EP (7-10) / 1.100 EP (11+)",
            gold: "800 Gold",
            drops: "Claw Of Chilong (Arma Warrior), Earthshaker (Arma Wizard), To-sabaki Helm, To-Maga Hood, Energy Ring, Amulet Of Earth",
            recompensasBoss: "Lightning Fragment",
            imagem: "img/bosses/Chilong (H)/flutto.png",
            mobs: [
                {
                    nome: "Chilong",
                    ataques: "Gelo e Raio",
                    fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
                    level: "A definir",
                    ilha: "Yabutu",
                    hp: "40.000 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Chilong (H)/flutto.png"
                },
                {
                    nome: "Dragon Son",
                    ataques: "Gelo e Raio",
                    fraqueza: "Fogo",
                    level: "A definir",
                    ilha: "Yabutu",
                    hp: "9.510 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Chilong (N)/long.png"
                },
                {
                    nome: "Earthvant",
                    ataques: "Raio",
                    fraqueza: "Fogo",
                    level: "A definir",
                    ilha: "Yabutu",
                    hp: "7.010 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Chilong (H)/kreppan.png"
                },
                {
                    nome: "Stomacid",
                    ataques: "Raio",
                    fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
                    level: "A definir",
                    ilha: "Yabutu",
                    hp: "1.070 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Chilong (H)/ooze.png"
                },
                {
                    nome: "Wisp Bomb",
                    ataques: "A definir",
                    fraqueza: "A definir",
                    level: "A definir",
                    ilha: "Yabutu",
                    hp: "0 HP",
                    xp: "Sem XP",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Biestig/wisp.png"
                }
            ]
        },
        {
            nome: "Frostisso",
            ataques: "Físico e Gelo",
            fraqueza: "Fogo",
            level: "70+",
            ilha: "St. Nivalis",
            hp: "95.710 HP (Frostisso) + 5.420 HP (Ice Slave)",
            xp: "36.000 EP (até 2 players) / 12.000 EP (3-6) / 7.200 EP (7-10) / 1.100 EP (11+)",
            gold: "800 Gold",
            drops: "Subzero, Rod Of Eternal Ice, Frostscale Legplates, Deepfrozen Pants, Amulet Of Snow, Hardwater Ring",
            recompensasBoss: "Frozen Scale",
            imagem: "img/bosses/Frostisso/icedragon.png",
            mobs: [
                {
                    nome: "Frostisso",
                    ataques: "Físico e Gelo",
                    fraqueza: "Fogo",
                    level: "A definir",
                    ilha: "St. Nivalis",
                    hp: "95.710 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Frostisso/icedragon.png"
                },
                {
                    nome: "Ice Slave",
                    ataques: "Gelo",
                    fraqueza: "Fogo",
                    level: "A definir",
                    ilha: "St. Nivalis",
                    hp: "5.420 HP",
                    xp: "Recompensa da Boss Battle (até 36.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Frostisso/yeti.png"
                }
            ]
        },
        {
            nome: "Twin Kings",
            ataques: "Sagrado",
            fraqueza: "Gelo",
            level: "70+",
            ilha: "Banuna",
            hp: "59.590 HP (Avarro) + 59.590 HP (Gonius)",
            xp: "36.000 EP (até 2 players) / 12.000 EP (3-6) / 7.200 EP (7-10) / 1.100 EP (11+)",
            gold: "800 Gold",
            drops: "Divine Amulet, Sanctification Ring, Divine Twinblade, Divine Twinstaff, Divine Protector, Sanctification Ward",
            recompensasBoss: "Ancient Artifact",
            imagem: "img/bosses/Twinkings/musco.png",
            mobs: [
                {
                    nome: "Avarro",
                    ataques: "Sagrado",
                    fraqueza: "Gelo",
                    level: "A definir",
                    ilha: "Banuna",
                    hp: "59.590 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Twinkings/musco.png"
                },
                {
                    nome: "Gonius",
                    ataques: "Sagrado",
                    fraqueza: "Gelo",
                    level: "A definir",
                    ilha: "Banuna",
                    hp: "59.590 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Twinkings/musco.png"
                }
            ]
        },
        {
            nome: "Hornig",
            ataques: "Fogo e Sagrado",
            fraqueza: "Raio",
            level: "70+",
            ilha: "Ashmor",
            hp: "44.300 HP (Hornig) + 12.000 HP (cada Hellhound) + 5.070 HP (Shadow) + 4.530 HP (Demon) + 3.750 HP (Lich King)",
            xp: "36.000 EP (até 2 players) / 12.000 EP (3-6) / 7.200 EP (7-10) / 1.100 EP (11+)",
            gold: "800 Gold",
            drops: "Talisman, Steel Chain, Demonic Essence, Hammer Of Kha'zur, Hellfire Breastplate, Demonic Cloak",
            recompensasBoss: "Demonic Relic",
            imagem: "img/bosses/Hornig/demon.png",
            mobs: [
                {
                    nome: "Hornig",
                    ataques: "Fogo e Sagrado",
                    fraqueza: "Raio",
                    level: "A definir",
                    ilha: "Ashmor",
                    hp: "44.300 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Hornig/demon.png"
                },
                {
                    nome: "Hellhound 1",
                    ataques: "Fogo",
                    fraqueza: "Raio",
                    level: "A definir",
                    ilha: "Ashmor",
                    hp: "12.000 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Hornig/cerberusr.png"
                },
                {
                    nome: "Hellhound 2",
                    ataques: "Fogo",
                    fraqueza: "Raio",
                    level: "A definir",
                    ilha: "Ashmor",
                    hp: "12.000 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Hornig/cerberusr.png"
                },
                {
                    nome: "Shadow",
                    ataques: "Fogo e Sagrado",
                    fraqueza: "Raio",
                    level: "A definir",
                    ilha: "Ashmor",
                    hp: "5.070 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Hornig/shadow.png"
                },
                {
                    nome: "Demon",
                    ataques: "Fogo e Sagrado",
                    fraqueza: "Raio",
                    level: "A definir",
                    ilha: "Ashmor",
                    hp: "4.530 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Hornig/demon.png"
                },
                {
                    nome: "Lich King",
                    ataques: "Sagrado",
                    fraqueza: "Raio",
                    level: "A definir",
                    ilha: "Ashmor",
                    hp: "3.750 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Hornig/lichking.png"
                }
            ]
        },
        {
            nome: "Igor",
            ataques: "Fogo e Sagrado",
            fraqueza: "Sagrado",
            level: "70+",
            ilha: "Ashmor",
            hp: "89.660 HP (Igor) + 3.260 HP (Subject B) + 1.900 HP (Subject A)",
            xp: "36.000 EP (até 2 players) / 12.000 EP (3-6) / 7.200 EP (7-10) / 1.100 EP (11+)",
            gold: "800 Gold",
            drops: "Talisman, Void Ore, Hellfire Helmet, Demonic Hood",
            recompensasBoss: "Demonic Relic",
            imagem: "img/bosses/Igor/culttutor.png",
            mobs: [
                {
                    nome: "Igor",
                    ataques: "Fogo e Sagrado",
                    fraqueza: "Sagrado",
                    level: "A definir",
                    ilha: "Ashmor",
                    hp: "89.660 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Igor/culttutor.png"
                },
                {
                    nome: "Subject B",
                    ataques: "Fogo",
                    fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
                    level: "A definir",
                    ilha: "Ashmor",
                    hp: "3.260 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Igor/behemoth.png"
                },
                {
                    nome: "Subject A",
                    ataques: "Sagrado",
                    fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
                    level: "A definir",
                    ilha: "Ashmor",
                    hp: "1.900 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Igor/zombie.png"
                }
            ]
        },
        {
            nome: "Nekrion",
            ataques: "Físico",
            fraqueza: "Sagrado",
            level: "70+",
            ilha: "Ashmor",
            hp: "91.290 HP (Nekrion) + 5.870 HP (cada Nekrion menor, 3x) + 2.170 HP (Ghoul)",
            xp: "36.000 EP (até 2 players) / 12.000 EP (3-6) / 7.200 EP (7-10) / 1.100 EP (11+)",
            gold: "800 Gold",
            drops: "Talisman, Blood Ore, Hellfire legplates, Demonic Trousers",
            recompensasBoss: "Demonic Relic",
            imagem: "img/bosses/Nekrion/vampire.png",
            mobs: [
                {
                    nome: "Nekrion",
                    ataques: "Físico",
                    fraqueza: "Sagrado",
                    level: "A definir",
                    ilha: "Ashmor",
                    hp: "91.290 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Nekrion/vampire.png"
                },
                {
                    nome: "Nekrion menor 1",
                    ataques: "Físico",
                    fraqueza: "Sagrado",
                    level: "A definir",
                    ilha: "Ashmor",
                    hp: "5.870 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Nekrion/bat.png"
                },
                {
                    nome: "Nekrion menor 2",
                    ataques: "Físico",
                    fraqueza: "Sagrado",
                    level: "A definir",
                    ilha: "Ashmor",
                    hp: "5.870 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Nekrion/wolf.png"
                },
                {
                    nome: "Nekrion menor 3",
                    ataques: "Físico",
                    fraqueza: "Raio",
                    level: "A definir",
                    ilha: "Ashmor",
                    hp: "5.870 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Nekrion/vampire.png"
                },
                {
                    nome: "Ghoul",
                    ataques: "Gelo",
                    fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
                    level: "A definir",
                    ilha: "Ashmor",
                    hp: "2.170 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Nekrion/zombie.png"
                }
            ]
        },
        {
            nome: "Azael",
            ataques: "Gelo",
            fraqueza: "Sagrado",
            level: "20 a 30+",
            ilha: "Ashmor",
            hp: "14.000 HP (Azael) + 1.230 HP (Alchemist) + 382 HP (Gatekeeper)",
            xp: "500 EP (Jewel of Experience no baú)",
            gold: "75 Gold",
            drops: "Truesilver Mace, Great Soul Rune, Lesser Might Potion",
            recompensasBoss: "Jewel Of Experience (0,5k)",
            imagem: "img/bosses/Azael/lich.png",
            mobs: [
                {
                    nome: "Azael",
                    ataques: "Gelo",
                    fraqueza: "Sagrado",
                    level: "A definir",
                    ilha: "Ashmor",
                    hp: "14.000 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Azael/lich.png"
                },
                {
                    nome: "Alchemist",
                    ataques: "Gelo",
                    fraqueza: "Sagrado",
                    level: "A definir",
                    ilha: "Ashmor",
                    hp: "1.230 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Azael/acolyte.png"
                },
                {
                    nome: "Gatekeeper",
                    ataques: "Gelo",
                    fraqueza: "Sagrado",
                    level: "A definir",
                    ilha: "Ashmor",
                    hp: "382 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: ""
                }
            ]
        },
        {
            nome: "Bragnak",
            ataques: "Físico",
            fraqueza: "Raio",
            level: "12+",
            ilha: "Aurea",
            hp: "2.540 HP (Bragnak) + 1.050 HP (Orc Shaman)",
            xp: "Sem EP (boss não dá experiência)",
            gold: "0 Gold (sem baú)",
            drops: "(+) Flash Hacker, (+) Spark Stick, Minor Health Potion, Minor Mana Potion",
            recompensasBoss: "Nenhuma (sem baú de recompensa)",
            imagem: "img/bosses/Bragnak/orc.png",
            mobs: [
                {
                    nome: "Bragnak",
                    ataques: "Físico",
                    fraqueza: "Raio",
                    level: "A definir",
                    ilha: "Aurea",
                    hp: "2.540 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Bragnak/orc.png"
                },
                {
                    nome: "Orc Shaman",
                    ataques: "Físico e Fogo",
                    fraqueza: "Raio",
                    level: "A definir",
                    ilha: "Aurea",
                    hp: "1.050 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Bragnak/cultist.png"
                }
            ]
        },
        {
            nome: "Oakvine",
            ataques: "Físico",
            fraqueza: "Fogo",
            level: "20+",
            ilha: "Fabulara",
            hp: "12.020 HP (Oakvine) + 2.150 HP (Treant)",
            xp: "1.900 EP (Jewel of Experience no baú)",
            gold: "300 Gold",
            drops: "Cutting Leafs, Branch of Oakvine, Lesser Might Potion",
            recompensasBoss: "Jewel Of Experience (1,9k)",
            imagem: "img/bosses/Oakvine/treant.png",
            mobs: [
                {
                    nome: "Oakvine",
                    ataques: "Físico",
                    fraqueza: "Fogo",
                    level: "A definir",
                    ilha: "Fabulara",
                    hp: "12.020 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Oakvine/treant.png"
                },
                {
                    nome: "Treant",
                    ataques: "Físico",
                    fraqueza: "Fogo",
                    level: "A definir",
                    ilha: "Fabulara",
                    hp: "2.150 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Oakvine/treant.png"
                }
            ]
        },
        {
            nome: "Biestig",
            ataques: "Fogo e Sagrado",
            fraqueza: "Físico e Raio",
            level: "100+",
            ilha: "Erebos",
            hp: "85.440 HP (Biestig) + 43.470 HP (Castor) + 43.470 HP (Pollux) + 7.320 HP (Inferno) + 6.710 HP (Demondrake) + 6.100 HP (Spirital)",
            xp: "45.000 EP (até 2 players) / 15.000 EP (3-6) / 9.000 EP (7-10) / 1.375 EP (11+)",
            gold: "2.800 Gold",
            drops: "Astral Seal, Demon Skin Bag, Chain Link, Control Crystal",
            recompensasBoss: "1 Astral Seal e experiência (EP); chance de dropar a mochila Demon Skin Bag",
            imagem: "img/bosses/Biestig/culttutor.png",
            mobs: [
                {
                    nome: "Biestig",
                    ataques: "Fogo e Sagrado",
                    fraqueza: "Físico e Raio",
                    level: "A definir",
                    ilha: "Erebos",
                    hp: "85.440 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Biestig/culttutor.png"
                },
                {
                    nome: "Castor",
                    ataques: "Fogo",
                    fraqueza: "Raio",
                    level: "A definir",
                    ilha: "Erebos",
                    hp: "43.470 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Biestig/cerberusr.png"
                },
                {
                    nome: "Pollux",
                    ataques: "Físico e Fogo",
                    fraqueza: "Raio",
                    level: "A definir",
                    ilha: "Erebos",
                    hp: "43.470 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Biestig/cerberusr.png"
                },
                {
                    nome: "Inferno",
                    ataques: "Fogo",
                    fraqueza: "Gelo",
                    level: "A definir",
                    ilha: "Erebos",
                    hp: "7.320 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Biestig/flame.png"
                },
                {
                    nome: "Demondrake",
                    ataques: "Físico",
                    fraqueza: "Sagrado",
                    level: "A definir",
                    ilha: "Erebos",
                    hp: "6.710 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Biestig/blackdrake.png"
                },
                {
                    nome: "Spirital",
                    ataques: "Sagrado",
                    fraqueza: "Raio",
                    level: "A definir",
                    ilha: "Erebos",
                    hp: "6.100 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Biestig/wisp.png"
                }
            ]
        },
        {
            nome: "Mutabor",
            ataques: "Físico, Gelo e Sagrado",
            fraqueza: "Sagrado",
            level: "100+",
            ilha: "Ephialtis",
            hp: "74.500 HP (Mutabor) + 8.110 HP (Spectre)",
            xp: "54.000 EP (até 2 players) / 18.000 EP (3-6) / 10.800 EP (7-10) / 1.650 EP (11+)",
            gold: "5.200 Gold",
            drops: "Chaos Shred, Ethereal Bag",
            recompensasBoss: "Garantida: 1 Chaos Shred (troca/forja de equipamentos de Ephialtis). Aleatórios: mochila Ethereal Bag (Blazing Ore e Etheric Ore) e equipamentos de Fogo (Divine Cuirass, Divine Greaves, Ancient Helmet)",
            imagem: "img/bosses/Mutabor/lich.png",
            mobs: [
                {
                    nome: "Mutabor",
                    ataques: "Físico, Gelo e Sagrado",
                    fraqueza: "Sagrado",
                    level: "A definir",
                    ilha: "Ephialtis",
                    hp: "74.500 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Mutabor/lich.png"
                },
                {
                    nome: "Spectre",
                    ataques: "Físico e Gelo",
                    fraqueza: "Fogo e Sagrado",
                    level: "A definir",
                    ilha: "Ephialtis",
                    hp: "8.110 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Mutabor/shadow.png"
                }
            ]
        },
        {
            nome: "Tauragor",
            ataques: "Físico, Fogo e Sagrado",
            fraqueza: "Fogo",
            level: "100+",
            ilha: "Gorgoros",
            hp: "98.760 HP (Tauragor) + 6.366 HP (Furor)",
            xp: "90.000 EP",
            gold: "1.200 Gold (baús)",
            drops: "Sem loots",
            recompensasBoss: "Tauron Bag",
            imagem: "img/bosses/Tauragor/darktaur.png",
            mobs: [
                {
                    nome: "Tauragor",
                    ataques: "Físico, Fogo e Sagrado",
                    fraqueza: "Fogo",
                    level: "A definir",
                    ilha: "Gorgoros",
                    hp: "98.760 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Tauragor/darktaur.png"
                },
                {
                    nome: "Furor",
                    ataques: "Fogo",
                    fraqueza: "Fogo",
                    level: "A definir",
                    ilha: "Gorgoros",
                    hp: "6.366 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Tauragor/flame.png"
                }
            ]
        },
        {
            nome: "Carneiro",
            evento: "carneiro",
            ataques: "Raio",
            fraqueza: "Físico, Fogo, Gelo e Sagrado",
            level: "80+",
            ilha: "Aurea",
            hp: "19.630 HP (Carneiro) + 19.630 HP (Carneiro espelho)",
            xp: "520 EP (ao iniciar a missão)",
            gold: "A definir",
            drops: "Ninja Mask, Porate Captain Mask, Mask Piece",
            recompensasBoss: "A definir",
            imagem: "img/bosses/Carneiro/sheep.png",
            mobs: [
                {
                    nome: "Carneiro",
                    ataques: "Raio",
                    fraqueza: "Físico, Fogo, Gelo e Sagrado",
                    level: "A definir",
                    ilha: "Aurea",
                    hp: "19.630 HP",
                    xp: "Recompensa da Boss Battle (520 EP ao iniciar a missão)",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Carneiro/sheep.png"
                },
                {
                    nome: "Carneiro (espelho)",
                    ataques: "Raio",
                    fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
                    level: "A definir",
                    ilha: "Aurea",
                    hp: "19.630 HP",
                    xp: "0 EP",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Carneiro/sheep.png"
                }
            ]
        },
        {
            nome: "Matriarch",
            evento: "dragonrutting",
            ataques: "Fogo",
            fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
            level: "60+",
            ilha: "Aurea",
            hp: "60.000 HP (Matriarch) + 636 HP (cada Whelpling)",
            xp: "0 EP",
            gold: "A definir",
            drops: "Golden Dragon Egg, Bônus de 5% de dano por 2 horas para a ilha",
            recompensasBoss: "Golden Dragon Egg (evento Dragon Rutting)",
            imagem: "img/bosses/Matriarch/dragon.png",
            mobs: [
                {
                    nome: "Matriarch",
                    ataques: "Fogo",
                    fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
                    level: "A definir",
                    ilha: "Aurea",
                    hp: "60.000 HP",
                    xp: "0 EP",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Matriarch/dragon.png"
                },
                {
                    nome: "Whelpling 1",
                    ataques: "Fogo",
                    fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
                    level: "A definir",
                    ilha: "Aurea",
                    hp: "636 HP",
                    xp: "0 EP",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Matriarch/whelpling.png"
                },
                {
                    nome: "Whelpling 2",
                    ataques: "Fogo",
                    fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
                    level: "A definir",
                    ilha: "Aurea",
                    hp: "636 HP",
                    xp: "0 EP",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Matriarch/whelpling.png"
                }
            ]
        },
        {
            nome: "Seelacor",
            ataques: "Físico, Fogo, Raio e Sagrado",
            fraqueza: "Físico",
            level: "120+ (em grupo) / 140+ (solo, bem equipado)",
            ilha: "Maleisla",
            hp: "?? HP (Seelacor) + ?? HP (Spore) + ?? HP (Shroomspaw) + ?? HP (Anti) + ?? HP (Infecspaw)",
            xp: "108.000 EP",
            gold: "2.500 Gold e Revelations (baús)",
            drops: "Sem loots",
            recompensasBoss: "Bag of Corruption",
            imagem: "img/bosses/Seelacor/abominatio.png",
            mobs: [
                {
                    nome: "Seelacor",
                    ataques: "Físico, Fogo, Raio e Sagrado",
                    fraqueza: "Físico",
                    level: "A definir",
                    ilha: "Maleisla",
                    hp: "?? HP",
                    xp: "Recompensa da Boss Battle (108.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Seelacor/abominatio.png"
                },
                {
                    nome: "Spore",
                    ataques: "Físico e Gelo",
                    fraqueza: "Fogo e Sagrado",
                    level: "A definir",
                    ilha: "Maleisla",
                    hp: "?? HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Seelacor/zombie.png"
                },
                {
                    nome: "Shroomspaw",
                    ataques: "Sagrado",
                    fraqueza: "Raio e Sagrado",
                    level: "A definir",
                    ilha: "Maleisla",
                    hp: "?? HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Seelacor/behemoth.png"
                },
                {
                    nome: "Anti",
                    ataques: "Sagrado",
                    fraqueza: "Gelo e Raio",
                    level: "A definir",
                    ilha: "Maleisla",
                    hp: "?? HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Seelacor/wisp.png"
                },
                {
                    nome: "Infecspaw",
                    ataques: "A definir",
                    fraqueza: "Físico e Sagrado",
                    level: "A definir",
                    ilha: "Maleisla",
                    hp: "?? HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Seelacor/aquata.png"
                }
            ]
        },
        {
            nome: "Kyklopes",
            ataques: "Físico, Fogo e Sagrado",
            fraqueza: "Gelo e Raio",
            level: "100+ (em grupo) / 120+ (bem equipado)",
            ilha: "Gorgoros",
            hp: "62.430 HP (Kyklopes) + 6.320 HP (Automaton)",
            xp: "90.000 EP",
            gold: "1.800 Gold (baús)",
            drops: "Sem loots no Kyklopes; Automaton dropa 1 item (nome a definir)",
            recompensasBoss: "A definir",
            imagem: "img/bosses/Kyklopes/petraclops.png",
            mobs: [
                {
                    nome: "Kyklopes",
                    ataques: "Físico, Fogo e Sagrado",
                    fraqueza: "Gelo e Raio",
                    level: "A definir",
                    ilha: "Gorgoros",
                    hp: "62.430 HP",
                    xp: "Recompensa da Boss Battle (90.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Kyklopes/petraclops.png"
                },
                {
                    nome: "Automaton",
                    ataques: "Fogo",
                    fraqueza: "Raio",
                    level: "A definir",
                    ilha: "Gorgoros",
                    hp: "6.320 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Item (nome a definir)",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Kyklopes/hellguard.png"
                }
            ]
        },
        {
            nome: "Medusa",
            ataques: "Raio e Sagrado",
            fraqueza: "Sagrado",
            level: "100+ (em grupo) / 120+ (bem equipado)",
            ilha: "Gorgoros",
            hp: "100.000 HP (Medusa) + 6.666 HP (Bloodlizar) + 600 HP (Viper)",
            xp: "90.000 EP",
            gold: "2.500 Gold (baús)",
            drops: "Sem loots na Medusa e na Viper; Bloodlizar dropa 1 item (nome a definir)",
            recompensasBoss: "A definir",
            imagem: "img/bosses/Medusa/medusa.png",
            mobs: [
                {
                    nome: "Medusa",
                    ataques: "Raio e Sagrado",
                    fraqueza: "Sagrado",
                    level: "A definir",
                    ilha: "Gorgoros",
                    hp: "100.000 HP",
                    xp: "Recompensa da Boss Battle (90.000 EP)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Medusa/medusa.png"
                },
                {
                    nome: "Bloodlizar",
                    ataques: "Sagrado",
                    fraqueza: "Gelo",
                    level: "A definir",
                    ilha: "Gorgoros",
                    hp: "6.666 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Item (nome a definir)",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Medusa/bloodlizar.png"
                },
                {
                    nome: "Viper",
                    ataques: "Sagrado",
                    fraqueza: "Sagrado",
                    level: "A definir",
                    ilha: "Gorgoros",
                    hp: "600 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Medusa/viper.png"
                }
            ]
        },
        {
            nome: "Everdragon",
            ataques: "Físico, Gelo e Sagrado",
            fraqueza: "Sagrado",
            level: "90+",
            ilha: "Doratia",
            hp: "91.430 HP (Everdragon) + 8.110 HP (Shadow) + 6.320 HP (Hitguard) + 5.730 HP (Everlich) + 4.870 HP (Hitzard) + 969 HP (Eversite)",
            xp: "60.000 EP",
            gold: "750 Gold (baú)",
            drops: "Bone Focus (baú)",
            recompensasBoss: "Ever Bag, Peças do set Elder/Ancient (armaduras lvl 99)",
            imagem: "img/bosses/Everdragon/bonedragon.png",
            mobs: [
                {
                    nome: "Everdragon",
                    ataques: "Físico, Gelo e Sagrado",
                    fraqueza: "Sagrado",
                    level: "A definir",
                    ilha: "Doratia",
                    hp: "91.430 HP",
                    xp: "Recompensa da Boss Battle (60.000 EP)",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Everdragon/bonedragon.png"
                },
                {
                    nome: "Shadow",
                    ataques: "Gelo e Sagrado",
                    fraqueza: "Sagrado",
                    level: "A definir",
                    ilha: "Doratia",
                    hp: "8.110 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Everdragon/shadow.png"
                },
                {
                    nome: "Hitguard",
                    ataques: "Físico e Sagrado",
                    fraqueza: "Gelo",
                    level: "A definir",
                    ilha: "Doratia",
                    hp: "6.320 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Everdragon/hellguard.png"
                },
                {
                    nome: "Everlich",
                    ataques: "Físico e Gelo",
                    fraqueza: "Sagrado",
                    level: "A definir",
                    ilha: "Doratia",
                    hp: "5.730 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Everdragon/lich.png"
                },
                {
                    nome: "Hitzard",
                    ataques: "Físico e Sagrado",
                    fraqueza: "Físico",
                    level: "A definir",
                    ilha: "Doratia",
                    hp: "4.870 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Everdragon/apprentice.png"
                },
                {
                    nome: "Eversite",
                    ataques: "Físico e Sagrado",
                    fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
                    level: "A definir",
                    ilha: "Doratia",
                    hp: "969 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Recompensa da Boss Battle",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Everdragon/fireball.png"
                }
            ]
        },
        {
            nome: "Odon",
            ataques: "Físico e Gelo",
            fraqueza: "Sagrado",
            level: "140+ (em grupo)",
            ilha: "Aurea",
            hp: "268.600 HP (Odon) + 3.072 HP (Archvampire) + 2.617 HP (Vampire Lord)",
            xp: "108.000 EP",
            gold: "A definir",
            drops: "Sem loots no Odon; Archvampire e Vampire Lord dropam itens (nomes a definir)",
            recompensasBoss: "A definir",
            imagem: "img/bosses/Odon/vamplord.png",
            mobs: [
                {
                    nome: "Odon",
                    ataques: "Físico e Gelo",
                    fraqueza: "Sagrado",
                    level: "A definir",
                    ilha: "Aurea",
                    hp: "268.600 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Odon/vamplord.png"
                },
                {
                    nome: "Archvampire",
                    ataques: "A definir",
                    fraqueza: "A definir",
                    level: "A definir",
                    ilha: "Aurea",
                    hp: "3.072 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Itens (nomes a definir)",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Odon/vampire.png"
                },
                {
                    nome: "Vampire Lord",
                    ataques: "A definir",
                    fraqueza: "A definir",
                    level: "A definir",
                    ilha: "Aurea",
                    hp: "2.617 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Itens (nomes a definir)",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Odon/vamplord.png"
                }
            ]
        },
        {
            nome: "Ten'ta'cul",
            ataques: "Físico e Raio",
            fraqueza: "Gelo",
            level: "80+ (em grupo) / 100+ (bem equipado)",
            ilha: "Riftion",
            hp: "68.000 HP (Ten'ta'cul) + 6.342 HP (Mindslave) + 3.144 HP (Cutaculus)",
            xp: "45.000 EP",
            gold: "2.800 Gold (baús)",
            drops: "Bane Stone (dropado pelo Mindslave)",
            recompensasBoss: "Otherworld Bag, Sphinx Tamer; baú: Otherworld Essence",
            imagem: "img/bosses/Ten'ta'cul/krakomin.png",
            mobs: [
                {
                    nome: "Ten'ta'cul",
                    ataques: "Físico e Raio",
                    fraqueza: "Gelo",
                    level: "A definir",
                    ilha: "Riftion",
                    hp: "68.000 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Ten'ta'cul/krakomin.png"
                },
                {
                    nome: "Mindslave",
                    ataques: "Físico e Raio",
                    fraqueza: "Gelo",
                    level: "A definir",
                    ilha: "Riftion",
                    hp: "6.342 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Bane Stone",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Ten'ta'cul/ninjana.png"
                },
                {
                    nome: "Cutaculus",
                    ataques: "Físico e Raio",
                    fraqueza: "Físico, Fogo, Gelo e Raio",
                    level: "A definir",
                    ilha: "Riftion",
                    hp: "3.144 HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Ten'ta'cul/tentacle.png"
                }
            ]
        },
        {
            nome: "Trocker",
            ataques: "Físico e Fogo",
            fraqueza: "Físico e Gelo",
            level: "120+ (em grupo) / 150+ (bem equipado)",
            ilha: "Orthoma",
            hp: "?? HP (Trocker) + ?? HP (Borc Leader) + ?? HP (Borc Warrior) + ?? HP (Worcester Leader) + ?? HP (Worc Warrior)",
            xp: "108.000 EP",
            gold: "10.000 Gold (baús)",
            drops: "Sem loots",
            recompensasBoss: "A definir",
            imagem: "img/bosses/Trocker/borclord.png",
            mobs: [
                {
                    nome: "Trocker",
                    ataques: "Físico e Fogo",
                    fraqueza: "Físico e Gelo",
                    level: "A definir",
                    ilha: "Orthoma",
                    hp: "?? HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Trocker/borclord.png"
                },
                {
                    nome: "Borc Leader",
                    ataques: "Físico e Gelo",
                    fraqueza: "Físico e Fogo",
                    level: "A definir",
                    ilha: "Orthoma",
                    hp: "?? HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Trocker/borclord.png"
                },
                {
                    nome: "Borc Warrior",
                    ataques: "Físico e Gelo",
                    fraqueza: "Físico e Fogo",
                    level: "A definir",
                    ilha: "Orthoma",
                    hp: "?? HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Trocker/eliteborc.png"
                },
                {
                    nome: "Worcester Leader",
                    ataques: "Físico e Fogo",
                    fraqueza: "Físico e Gelo",
                    level: "A definir",
                    ilha: "Orthoma",
                    hp: "?? HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Trocker/worcsmith.png"
                },
                {
                    nome: "Worc Warrior",
                    ataques: "Físico e Fogo",
                    fraqueza: "Físico e Gelo",
                    level: "A definir",
                    ilha: "Orthoma",
                    hp: "?? HP",
                    xp: "Recompensa da Boss Battle",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Trocker/eliteworc.png"
                }
            ]
        },
        {
            nome: "Alternor",
            ataques: "A definir",
            fraqueza: "A definir",
            level: "90+",
            ilha: "Castle Rock",
            hp: "A definir",
            xp: "0 EP",
            gold: "A definir",
            drops: "A definir",
            recompensasBoss: "A definir",
            imagem: "img/bosses/Alternor/vampire.png"
        },
        {
            nome: "Balinor",
            evento: "aniversario",
            ataques: "Fogo",
            fraqueza: "Sagrado",
            level: "Qualquer nível (em grupo)",
            ilha: "Aurea (portal especial de evento na ilha inicial)",
            hp: "18.889 HP (Balinor) + 4.293 HP (Modorok) + 4.293 HP (Tapio) (valores do fansite; o jogo pode escalar conforme o nível médio dos jogadores)",
            xp: "0 EP (no abate direto do boss)",
            gold: "0",
            drops: "Sem loots (evento de aniversário)",
            recompensasBoss: "Conquista Balinor Basher (1 pt) ao vencer 10 vezes; conta para as metas de vencer os 9 GM Bosses (1x, 10x e 100x). Rotação diária dos 9 bosses: falar com o NPC Blessaro rende o Exp Necklace do evento e tokens comemorativos.",
            imagem: "img/bosses/Balinor/demon.png",
            mobs: [
                {
                    nome: "Balinor",
                    ataques: "Fogo",
                    fraqueza: "Sagrado",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Aurea",
                    hp: "18.889 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Balinor/demon.png"
                },
                {
                    nome: "Modorok",
                    ataques: "Físico e Fogo",
                    fraqueza: "Raio",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Aurea",
                    hp: "4.293 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Balinor/cerberus.png"
                },
                {
                    nome: "Tapio",
                    ataques: "Físico e Fogo",
                    fraqueza: "Raio",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Aurea",
                    hp: "4.293 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Balinor/cerberus (1).png"
                }
            ]
        },
        {
            nome: "Isolan",
            evento: "aniversario",
            ataques: "Físico",
            fraqueza: "Gelo",
            level: "Qualquer nível (em grupo)",
            ilha: "Ashmor (portal especial de evento)",
            hp: "5.000 HP (Isolan) + 299 HP (Goblin) (valores do fansite; o jogo pode escalar conforme o nível médio dos jogadores)",
            xp: "0 EP (no abate direto do boss)",
            gold: "0",
            drops: "Sem loots (evento de aniversário)",
            recompensasBoss: "Conquista Isolan's Demise (1 pt) ao vencer 10 vezes; conta para as metas de vencer os 9 GM Bosses (1x, 10x e 100x). Rotação diária dos 9 bosses: falar com o NPC Blessaro rende o Exp Necklace do evento e tokens comemorativos.",
            imagem: "img/bosses/Isolan/witch.png",
            mobs: [
                {
                    nome: "Isolan",
                    ataques: "Físico",
                    fraqueza: "Gelo",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Ashmor",
                    hp: "5.000 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Isolan/witch.png"
                },
                {
                    nome: "Goblin",
                    ataques: "Físico",
                    fraqueza: "Físico e Sagrado",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Ashmor",
                    hp: "299 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Isolan/goblin.png"
                }
            ]
        },
        {
            nome: "Magos & Skathari",
            evento: "aniversario",
            ataques: "Físico",
            fraqueza: "Fogo",
            level: "Qualquer nível (em grupo)",
            ilha: "Vargos (portal especial de evento)",
            hp: "Escala conforme o nível médio dos jogadores na sala (sem valor fixo); Magos e Skathari têm barras de vida separadas, além dos Bugs",
            xp: "0 EP (no abate direto do boss)",
            gold: "0",
            drops: "Sem loots (evento de aniversário)",
            recompensasBoss: "Conquista Curse of Magos (1 pt) ao exterminar a dupla 10 vezes; conta para as metas de vencer os 9 GM Bosses (1x, 10x e 100x). Rotação diária dos 9 bosses: falar com o NPC Blessaro rende o Exp Necklace do evento e tokens comemorativos.",
            imagem: "img/bosses/Magos&skathari/bug.png",
            mobs: [
                {
                    nome: "Magos",
                    ataques: "Físico",
                    fraqueza: "Fogo",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Vargos",
                    hp: "Escala conforme os jogadores",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Magos&skathari/bug.png"
                },
                {
                    nome: "Skathari",
                    ataques: "Físico",
                    fraqueza: "Fogo",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Vargos",
                    hp: "Escala conforme os jogadores",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Magos&skathari/bug.png"
                },
                {
                    nome: "Bugs",
                    ataques: "A definir",
                    fraqueza: "A definir",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Vargos",
                    hp: "Escala conforme os jogadores",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Magos&skathari/bug.png"
                }
            ]
        },
        {
            nome: "Lyxoph",
            evento: "aniversario",
            ataques: "Físico",
            fraqueza: "Raio",
            level: "Qualquer nível (em grupo)",
            ilha: "Starrfish Island (portal no navio em chamas ancorado na praia)",
            hp: "15.744 HP (Lyxoph) + 1.300 HP (Bola de Fogo) (valores do fansite; o jogo pode escalar conforme o nível médio dos jogadores)",
            xp: "0 EP (no abate direto do boss)",
            gold: "0",
            drops: "Sem loots (evento de aniversário)",
            recompensasBoss: "Conquista Lyxoph's Bane (1 pt) ao vencer 10 vezes; conta para as metas de vencer os 9 GM Bosses (1x, 10x e 100x). Rotação diária dos 9 bosses: falar com o NPC Blessaro rende o Exp Necklace do evento e tokens comemorativos.",
            imagem: "img/bosses/Lyxoph/swabby.png",
            mobs: [
                {
                    nome: "Lyxoph",
                    ataques: "Físico",
                    fraqueza: "Raio",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Starrfish Island",
                    hp: "15.744 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Lyxoph/swabby.png"
                },
                {
                    nome: "Bola de Fogo",
                    ataques: "Fogo",
                    fraqueza: "Fogo e Gelo",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Starrfish Island",
                    hp: "1.300 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Lyxoph/furball.png"
                }
            ]
        },
        {
            nome: "Judigator",
            evento: "aniversario",
            ataques: "Físico e Gelo",
            fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
            level: "Qualquer nível (em grupo)",
            ilha: "St. Nivalis (portal especial de evento)",
            hp: "4.799 HP (Judigator) + 12 HP (Furball) (valores do fansite; o jogo pode escalar conforme o nível médio dos jogadores)",
            xp: "0 EP (no abate direto do boss)",
            gold: "0",
            drops: "Sem loots (evento de aniversário)",
            recompensasBoss: "Conquista Judge of Judigator (1 pt) ao vencer 10 vezes seguidas; conta para as metas de vencer os 9 GM Bosses (1x, 10x e 100x). Rotação diária dos 9 bosses: falar com o NPC Blessaro rende o Exp Necklace do evento e tokens comemorativos.",
            imagem: "img/bosses/Judigator/apprentice.png",
            mobs: [
                {
                    nome: "Judigator",
                    ataques: "Físico e Gelo",
                    fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
                    level: "Qualquer nível (em grupo)",
                    ilha: "St. Nivalis",
                    hp: "4.799 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Judigator/apprentice.png"
                },
                {
                    nome: "Furball",
                    ataques: "Físico",
                    fraqueza: "Fogo",
                    level: "Qualquer nível (em grupo)",
                    ilha: "St. Nivalis",
                    hp: "12 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Judigator/furball.png"
                }
            ]
        },
        {
            nome: "Karvar",
            evento: "aniversario",
            ataques: "Fogo",
            fraqueza: "Gelo",
            level: "Qualquer nível (em grupo)",
            ilha: "Solahmar (portal especial de evento perto da antiga Academia de Magia)",
            hp: "6.840 HP (Karvar) + 5.472 HP (Techninja) + 6.566 HP (Penciljack) (valores do fansite; o jogo pode escalar conforme o nível médio dos jogadores)",
            xp: "0 EP (no abate direto do boss)",
            gold: "0",
            drops: "Sem loots (evento de aniversário)",
            recompensasBoss: "Conquista Doom of Karvar (1 pt) ao vencer na arena mais de 10 vezes; conta para as metas de vencer os 9 GM Bosses (1x, 10x e 100x). Rotação diária dos 9 bosses: falar com o NPC Blessaro rende o Exp Necklace do evento e tokens comemorativos.",
            imagem: "img/bosses/Karvar/dragon.png",
            mobs: [
                {
                    nome: "Karvar",
                    ataques: "Fogo",
                    fraqueza: "Gelo",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Solahmar",
                    hp: "6.840 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Karvar/dragon.png"
                },
                {
                    nome: "Techninja",
                    ataques: "Físico",
                    fraqueza: "Físico",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Solahmar",
                    hp: "5.472 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Karvar/ninjaman.png"
                },
                {
                    nome: "Penciljack",
                    ataques: "Sagrado",
                    fraqueza: "Raio",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Solahmar",
                    hp: "6.566 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Karvar/evoke.png"
                }
            ]
        },
        {
            nome: "Tannin",
            evento: "aniversario",
            ataques: "Físico",
            fraqueza: "Físico",
            level: "Qualquer nível (em grupo)",
            ilha: "Banuna (portal especial de evento na selva)",
            hp: "Escala conforme o nível médio dos jogadores na sala (sem valor fixo)",
            xp: "0 EP (no abate direto do boss)",
            gold: "0",
            drops: "Sem loots (evento de aniversário)",
            recompensasBoss: "Conquista Tannin's Terror (1 pt) ao vencer 10 vezes; conta para as metas de vencer os 9 GM Bosses (1x, 10x e 100x). Rotação diária dos 9 bosses: falar com o NPC Blessaro rende o Exp Necklace do evento e tokens comemorativos.",
            imagem: "img/bosses/Tannin/crocodile.png"
        },
        {
            nome: "Testor",
            evento: "aniversario",
            ataques: "Fogo",
            fraqueza: "Sagrado",
            level: "Qualquer nível (em grupo)",
            ilha: "Yabutu (portal especial de evento nas ruínas/acampamento)",
            hp: "4.747 HP (Testor) + 1.846 HP (Delany) + 1.582 HP (Bolfrim) + 1.714 HP (Siramal) (valores do fansite; o jogo pode escalar conforme o nível médio dos jogadores)",
            xp: "0 EP (no abate direto do boss)",
            gold: "0",
            drops: "Sem loots (evento de aniversário)",
            recompensasBoss: "Conquista Ruin of Testor (1 pt) ao derrubar 10 vezes; conta para as metas de vencer os 9 GM Bosses (1x, 10x e 100x). Rotação diária dos 9 bosses: falar com o NPC Blessaro rende o Exp Necklace do evento e tokens comemorativos.",
            imagem: "img/bosses/Testor/demon.png",
            mobs: [
                {
                    nome: "Testor",
                    ataques: "Fogo",
                    fraqueza: "Sagrado",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Yabutu",
                    hp: "4.747 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Testor/demon.png"
                },
                {
                    nome: "Delany",
                    ataques: "Fogo",
                    fraqueza: "Raio",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Yabutu",
                    hp: "1.846 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Testor/shadow.png"
                },
                {
                    nome: "Bolfrim",
                    ataques: "Sagrado",
                    fraqueza: "Fogo",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Yabutu",
                    hp: "1.582 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Testor/culttutor.png"
                },
                {
                    nome: "Siramal",
                    ataques: "Físico e Raio",
                    fraqueza: "Sagrado",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Yabutu",
                    hp: "1.714 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Testor/skelpirate.png"
                }
            ]
        },
        {
            nome: "Gods",
            evento: "aniversario",
            ataques: "Físico, Fogo e Sagrado",
            fraqueza: "Varia por Deus (veja cada um)",
            level: "Qualquer nível (em grupo)",
            ilha: "Fabulara (portal especial de evento)",
            hp: "1.401 HP (Durante) + 1.345 HP (Steve) + 1.345 HP (Estêvão) + 1.289 HP (Guido) (valores do fansite; o jogo pode escalar conforme o nível médio dos jogadores)",
            xp: "0 EP (no abate direto do boss)",
            gold: "0",
            drops: "Sem loots (evento de aniversário)",
            recompensasBoss: "Conquista Contender of Gods (1 pt); conta para as metas de vencer os 9 GM Bosses (1x, 10x e 100x). Rotação diária dos 9 bosses: falar com o NPC Blessaro rende o Exp Necklace do evento e tokens comemorativos.",
            imagem: "img/bosses/Gods/dwarf.png",
            mobs: [
                {
                    nome: "Durante",
                    ataques: "Físico, Fogo e Sagrado",
                    fraqueza: "Raio",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Fabulara",
                    hp: "1.401 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Gods/dwarf.png"
                },
                {
                    nome: "Steve",
                    ataques: "Físico",
                    fraqueza: "Físico e Fogo",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Fabulara",
                    hp: "1.345 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Gods/acolyte.png"
                },
                {
                    nome: "Estêvão",
                    ataques: "Físico e Fogo",
                    fraqueza: "Sagrado",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Fabulara",
                    hp: "1.345 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Gods/hellguard.png"
                },
                {
                    nome: "Guido",
                    ataques: "Físico e Sagrado",
                    fraqueza: "Sagrado",
                    level: "Qualquer nível (em grupo)",
                    ilha: "Fabulara",
                    hp: "1.289 HP",
                    xp: "0 EP (evento de aniversário)",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Gods/behemoth.png"
                }
            ]
        },
        {
            nome: "Hexana",
            evento: "carneiro",
            ataques: "Físico e Fogo",
            fraqueza: "Raio",
            level: "80+ (em grupo)",
            ilha: "Aurea (pântano; acessada após entregar as 3 chaves do evento do Carneiro: Charred Mask, Dull Mirror e Carneiro's Eye)",
            hp: "81.920 HP (Hexana) + 410 HP (Hexana espelho); perde cerca de 1/4 da vida a cada espelho da sala destruído pela explosão dos clones",
            xp: "0 EP (no abate direto do boss)",
            gold: "777 Gold (saque dos baús)",
            drops: "Jewel of Experience, Witch Pouch",
            recompensasBoss: "Mask Pieces extras, máscaras cosméticas do festival de Carnaval e itens de evento para trocar com o NPC em Aurea",
            imagem: "img/bosses/Hexana/witch.png",
            mobs: [
                {
                    nome: "Hexana",
                    ataques: "Físico e Fogo",
                    fraqueza: "Raio",
                    level: "80+ (em grupo)",
                    ilha: "Aurea",
                    hp: "81.920 HP",
                    xp: "0 EP",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "Saque dos baús: 777 Gold e uma gema vermelha",
                    imagem: "img/bosses/Hexana/witch.png"
                },
                {
                    nome: "Hexana (espelho)",
                    ataques: "Físico e Fogo",
                    fraqueza: "Raio",
                    level: "80+ (em grupo)",
                    ilha: "Aurea",
                    hp: "410 HP",
                    xp: "0 EP",
                    gold: "0",
                    drops: "Sem loots",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Hexana/witch.png"
                }
            ]
        },
        {
            nome: "Black Matriarch",
            evento: "dragonrutting",
            ataques: "Fogo e Sagrado",
            fraqueza: "Físico",
            level: "100/120+ (em grupo)",
            ilha: "Ephialtis (invocada no altar de dragões da ilha, sem tempo de recarga entre invocações; disponível apenas no evento Dragon Rutting / Acasalamento dos Dragões)",
            hp: "90.000 HP (Black Matriarch) + 969 HP (Dagasite)",
            xp: "0 EP (no abate direto do boss)",
            gold: "0",
            drops: "Black Heart (Black Matriarch); Drake Bone, Fire Sac, Magic Gem (Dagasite)",
            recompensasBoss: "Black Heart, Golden Eggs e ovos raros (ex.: Blackdrake Egg, para o pet Blackdrake). Bônus de +5% de dano na ilha de Ephialtis por 2 horas",
            imagem: "img/bosses/Blackmatriarch/blackdrake.png",
            mobs: [
                {
                    nome: "Black Matriarch",
                    ataques: "Fogo e Sagrado",
                    fraqueza: "Físico",
                    level: "100/120+ (em grupo)",
                    ilha: "Ephialtis",
                    hp: "90.000 HP",
                    xp: "0 EP",
                    gold: "0",
                    drops: "Black Heart",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Blackmatriarch/blackdrake.png"
                },
                {
                    nome: "Dagasite",
                    ataques: "Físico e Sagrado",
                    fraqueza: "Físico, Fogo, Gelo, Raio e Sagrado",
                    level: "A definir",
                    ilha: "Ephialtis",
                    hp: "969 HP",
                    xp: "A definir",
                    gold: "0",
                    drops: "Drake Bone, Fire Sac, Magic Gem",
                    recompensasBoss: "A definir",
                    imagem: "img/bosses/Blackmatriarch/fireball.png"
                }
            ]
        }
    ],
    Mobs: [
        { nome: "Bug", level: "a definir", hp: "29 HP", xp: "1 EP", gold: "1", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea, Lybera, Fabulara", drops: "Chili Stick, Little Sword, Minor Health Potion, Minor Mana Potion" },
        { nome: "Furball", level: "a definir", hp: "12 HP", xp: "1 EP", gold: "0", "tipo de atk": "", fraqueza: "Físico", locais: "St. Nivalis", drops: "Sem loots" },
        { nome: "Snake", level: "a definir", hp: "44 HP", xp: "2 EP", gold: "1", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea, Lybera, Fabulara, Banuna, Solahmar Isles", drops: "Feathered Stick, Glowing Hammer, Minor Health Potion, Minor Mana Potion" },
        { nome: "Squirrel", level: "a definir", hp: "65 HP", xp: "2 EP", gold: "2", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea", drops: "Minor Health Potion, Minor Mana Potion" },
        { nome: "Frog", level: "a definir", hp: "65 HP", xp: "3 EP", gold: "2", "tipo de atk": "", fraqueza: "Gelo", locais: "Lybera, Fabulara", drops: "Blazing Crystal, Feathered Stick, Glowing Hammer, Melee Mallet, Minor Health Potion, Minor Mana Potion" },
        { nome: "Spider", level: "a definir", hp: "79 HP", xp: "4 EP", gold: "2", "tipo de atk": "", fraqueza: "Gelo", locais: "Aurea, Lybera, Fabulara", drops: "Blazing Crystal, Melee Mallet, Minor Health Potion, Minor Mana Potion" },
        { nome: "Wolf", level: "a definir", hp: "92 HP", xp: "5 EP", gold: "3", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea, Lybera, Fabulara", drops: "Magic Spoon, Minor Health Potion, Minor Mana Potion, Short Sword" },
        { nome: "Slime", level: "a definir", hp: "109 HP", xp: "7 EP", gold: "3", "tipo de atk": "", fraqueza: "Fogo", locais: "Aurea, Lybera", drops: "Magic Spoon, Minor Health Potion, Minor Mana Potion, Short Sword" },
        { nome: "Hornet", level: "a definir", hp: "130 HP", xp: "9 EP", gold: "4", "tipo de atk": "", fraqueza: "Fogo", locais: "Aurea, Lybera", drops: "Fire Rune, Flame Spear, Minor Health Potion, Minor Mana Potion" },
        { nome: "Flummy", level: "a definir", hp: "156 HP", xp: "10 EP", gold: "0", "tipo de atk": "", fraqueza: "Físico", locais: "Hunterra", drops: "Sem loots" },
        { nome: "Mean Wolf", level: "a definir", hp: "143 HP", xp: "12 EP", gold: "4", "tipo de atk": "", fraqueza: "Físico", locais: "Lybera", drops: "Fire Rune, Flame Spear, Minor Health Potion, Minor Mana Potion" },
        { nome: "Lizardman", level: "a definir", hp: "159 HP", xp: "14 EP", gold: "5", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea, Lybera, Fabulara", drops: "Emerald, Mercenary Helmet, Minor Health Potion, Minor Mana Potion, Spell Student Hood" },
        { nome: "Scorpion", level: "a definir", hp: "173 HP", xp: "18 EP", gold: "5", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea, Solahmar Isles, Solahmar", drops: "Mace, Magic Root, Minor Health Potion, Minor Mana Potion" },
        { nome: "Zompforz", level: "a definir", hp: "666 HP", xp: "20 EP", gold: "5", "tipo de atk": "", fraqueza: "Fogo", locais: "Ashmor", drops: "Basting Shirt, Field Helmet, Ice Rune, Minor Health Potion" },
        { nome: "Bat", level: "a definir", hp: "198 HP", xp: "21 EP", gold: "6", "tipo de atk": "", fraqueza: "Físico", locais: "Ashmor", drops: "Bat Skin, Freezer Planks, Lesser Health Potion, Lesser Mana Potion, Mace, Nivalian Ring" },
        { nome: "Lizarogue", level: "a definir", hp: "198 HP", xp: "21 EP", gold: "6", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea", drops: "Mercenary Helmet, Spell Student Hood, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Skeleton", level: "a definir", hp: "198 HP", xp: "21 EP", gold: "6", "tipo de atk": "", fraqueza: "Fogo", locais: "Aurea, Ashmor, Solahmar Isles, Solahmar", drops: "Flash Hacker, Freezer Shield, Lesser Health Potion, Lesser Mana Potion, Spark Stick" },
        { nome: "Bear", level: "a definir", hp: "214 HP", xp: "25 EP", gold: "6", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea", drops: "Flogging Rune, Lesser Health Potion, Lesser Mana Potion, Priest Ring, Sword" },
        { nome: "Ghost", level: "a definir", hp: "214 HP", xp: "25 EP", gold: "6", "tipo de atk": "", fraqueza: "Gelo", locais: "Ashmor", drops: "Fur-Lined Cap, Fur-Lined Legs, Lesser Health Potion, Lesser Mana Potion, Magic Root, Twinkling Emerald" },
        { nome: "Ooze", level: "a definir", hp: "214 HP", xp: "25 EP", gold: "6", "tipo de atk": "", fraqueza: "Fogo", locais: "Ashmor", drops: "Lesser Health Potion, Lesser Mana Potion, Magic Spoon, Short Sword, Topaz" },
        { nome: "Lich", level: "a definir", hp: "200 HP", xp: "30 EP", gold: "7", "tipo de atk": "", fraqueza: "Sagrado", locais: "Ashmor", drops: "A conferir" },
        { nome: "Vamp Bat", level: "a definir", hp: "228 HP", xp: "30 EP", gold: "7", "tipo de atk": "", fraqueza: "Fogo", locais: "Ashmor", drops: "Freezer Planks, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Acolyte", level: "a definir", hp: "240 HP", xp: "34 EP", gold: "7", "tipo de atk": "", fraqueza: "Gelo", locais: "Ashmor", drops: "Acolyte Hood, Acolyte Legs, Acolyte Robe, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Restless", level: "a definir", hp: "242 HP", xp: "34 EP", gold: "7", "tipo de atk": "", fraqueza: "Fogo", locais: "Ashmor", drops: "Branding Stamp, Fur-Lined Cap, Fur-Lined Legs, Lesser Health Potion, Lesser Mana Potion, Twinkling Emerald" },
        { nome: "Lizazzin", level: "a definir", hp: "255 HP", xp: "39 EP", gold: "8", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea", drops: "Lesser Health Potion, Lesser Mana Potion, Mercenary Helmet, Spell Student Hood" },
        { nome: "Skelenary", level: "a definir", hp: "255 HP", xp: "39 EP", gold: "8", "tipo de atk": "", fraqueza: "Fogo", locais: "Ashmor", drops: "Axe, Freezer Shield, Incensor, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Acid Slime", level: "a definir", hp: "289 HP", xp: "45 EP", gold: "8", "tipo de atk": "", fraqueza: "Fogo", locais: "Ashmor", drops: "Contaminated Slime Sample, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Giant Bat", level: "a definir", hp: "289 HP", xp: "45 EP", gold: "8", "tipo de atk": "", fraqueza: "Físico", locais: "Ashmor", drops: "Bat Wings, Freezer Planks, Ice Rune, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Lich Lord", level: "a definir", hp: "253 HP", xp: "45 EP", gold: "8", "tipo de atk": "", fraqueza: "Físico", locais: "Ashmor", drops: "Basting Shirt, Field Helmet, Lesser Health Potion, Lesser Mana Potion, Sapphire, Silver Mace" },
        { nome: "Rabid Bear", level: "a definir", hp: "289 HP", xp: "45 EP", gold: "8", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea", drops: "Flogging Rune, Minor Health Potion, Minor Mana Potion" },
        { nome: "Orc", level: "a definir", hp: "303 HP", xp: "50 EP", gold: "9", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea, Fabulara", drops: "Freezer Rune, Frostbringer, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Widow", level: "a definir", hp: "303 HP", xp: "50 EP", gold: "9", "tipo de atk": "", fraqueza: "Físico", locais: "Ashmor", drops: "Fire Rune, Incensor, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Cult Tutor", level: "a definir", hp: "212 HP", xp: "57 EP", gold: "9", "tipo de atk": "", fraqueza: "Sagrado", locais: "Ashmor", drops: "Fur-Lined Cap, Fur-Lined Legs, Lesser Health Potion" },
        { nome: "Fanatic", level: "a definir", hp: "320 HP", xp: "57 EP", gold: "9", "tipo de atk": "", fraqueza: "Gelo", locais: "Ashmor", drops: "Lesser Health Potion, Lesser Mana Potion, Nivalian Ring" },
        { nome: "Skeleguard", level: "a definir", hp: "318 HP", xp: "57 EP", gold: "9", "tipo de atk": "", fraqueza: "Fogo", locais: "Aurea, Ashmor", drops: "Fire Discus, Fire Rune, Freezer Shield, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Tutor Lord", level: "a definir", hp: "248 HP", xp: "57 EP", gold: "9", "tipo de atk": "", fraqueza: "Físico", locais: "Ashmor", drops: "Fur-Lined Cap, Fur-Lined Legs, Minor Health Potion" },
        { nome: "Small Eye", level: "a definir", hp: "293 HP", xp: "62 EP", gold: "8", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea, Banuna", drops: "Holy Discus, Holy Lance" },
        { nome: "Lich King", level: "a definir", hp: "291 HP", xp: "63 EP", gold: "10", "tipo de atk": "", fraqueza: "Físico", locais: "Ashmor", drops: "Basting Shirt, Field Helmet, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Zombie", level: "a definir", hp: "387 HP", xp: "63 EP", gold: "10", "tipo de atk": "", fraqueza: "Fogo", locais: "Aurea, Ashmor, Solahmar", drops: "Basting Shirt, Field Helmet, Ice Rune, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Killerbear", level: "a definir", hp: "353 HP", xp: "67 EP", gold: "10", "tipo de atk": "", fraqueza: "Físico", locais: "Ashmor", drops: "Gurumistick, Shiver Rune, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Minotaur", level: "a definir", hp: "353 HP", xp: "67 EP", gold: "10", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea, Fabulara", drops: "Frozarium, Lesser Health Potion, Lesser Mana Potion, Shiver Rune, Syorta Ore" },
        { nome: "Polar Bear", level: "a definir", hp: "353 HP", xp: "67 EP", gold: "10", "tipo de atk": "", fraqueza: "Fogo", locais: "St. Nivalis", drops: "Basting Hood, Leather Legs, Lesser Health Potion, Lesser Mana Potion, Twinkling Sapphire" },
        { nome: "Walrus", level: "a definir", hp: "353 HP", xp: "67 EP", gold: "10", "tipo de atk": "", fraqueza: "Gelo", locais: "St. Nivalis", drops: "Field Ring, Focus Helmet, Lesser Health Potion, Lesser Mana Potion, Spellwielder Shirt, Twinkling Sapphire" },
        { nome: "Cultist", level: "a definir", hp: "186 HP", xp: "71 EP", gold: "11", "tipo de atk": "", fraqueza: "Gelo", locais: "St. Nivalis", drops: "Fortified Legs, Spellwielder Hat, Onyx, Twinkling Sapphire, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Sabrecat", level: "a definir", hp: "372 HP", xp: "71 EP", gold: "11", "tipo de atk": "", fraqueza: "Físico", locais: "St. Nivalis", drops: "Basting Shield, Field Armour, Field Ring, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Tarantula", level: "a definir", hp: "372 HP", xp: "71 EP", gold: "11", "tipo de atk": "", fraqueza: "Físico", locais: "St. Nivalis", drops: "Fire Rune, Incensor, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Fire Drake", level: "a definir", hp: "386 HP", xp: "76 EP", gold: "11", "tipo de atk": "", fraqueza: "Gelo", locais: "St. Nivalis", drops: "Dragon Pearl, Drake Skin, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Frost Bear", level: "a definir", hp: "386 HP", xp: "76 EP", gold: "11", "tipo de atk": "", fraqueza: "Fogo", locais: "St. Nivalis", drops: "Basting Hood, Leather Legs, Lesser Health Potion, Lesser Mana Potion, Twinkling Sapphire" },
        { nome: "Orc Raider", level: "a definir", hp: "386 HP", xp: "76 EP", gold: "11", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea", drops: "Freezer Rune, Frostbringer, Lesser Health Potion, Lesser Mana Potion, Power Ring, Ruby" },
        { nome: "Hissy", level: "a definir", hp: "401 HP", xp: "80 EP", gold: "12", "tipo de atk": "", fraqueza: "Físico", locais: "St. Nivalis", drops: "Basting Shield, Field Armour, Field Ring, Lesser Health Potion, Lesser Mana Potion, Sabre Tooth" },
        { nome: "Walrull", level: "a definir", hp: "401 HP", xp: "80 EP", gold: "12", "tipo de atk": "", fraqueza: "Gelo", locais: "St. Nivalis", drops: "Field Ring, Focus Helmet, Lesser Health Potion, Lesser Mana Potion, Spellwielder Hat, Twinkling Sapphire" },
        { nome: "Angrax", level: "a definir", hp: "240 HP", xp: "85 EP", gold: "12", "tipo de atk": "", fraqueza: "Gelo", locais: "St. Nivalis", drops: "Fortified Legs, Lesser Health Potion, Lesser Mana Potion, Onyx, Spellwielder Hat, Twinkling Sapphire" },
        { nome: "Icy Bear", level: "a definir", hp: "441 HP", xp: "89 EP", gold: "13", "tipo de atk": "", fraqueza: "Fogo", locais: "St. Nivalis", drops: "Basting Hood, Leather Legs, Lesser Health Potion, Lesser Mana Potion, Twinkling Sapphire" },
        { nome: "Minosol", level: "a definir", hp: "441 HP", xp: "89 EP", gold: "13", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea", drops: "Frozarium, Lesser Health Potion, Lesser Mana Potion, Shiver Rune, Syorta Ore" },
        { nome: "Shombie", level: "a definir", hp: "515 HP", xp: "89 EP", gold: "13", "tipo de atk": "", fraqueza: "Fogo", locais: "Aurea", drops: "Basting Shirt, Field Helmet, Ice Rune, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Frostcat", level: "a definir", hp: "460 HP", xp: "94 EP", gold: "13", "tipo de atk": "", fraqueza: "Fogo", locais: "St. Nivalis", drops: "Blue Defroster, Red Defroster" },
        { nome: "Hatcher", level: "a definir", hp: "400 HP", xp: "94 EP", gold: "11", "tipo de atk": "", fraqueza: "Gelo", locais: "Aurea", drops: "Holy Discus, Holy Lance" },
        { nome: "Sabrerus", level: "a definir", hp: "460 HP", xp: "94 EP", gold: "13", "tipo de atk": "", fraqueza: "Físico", locais: "St. Nivalis", drops: "Field Ring, Focus Helmet, Spellwielder Shirt, Twinkling Sapphire, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Scratchy", level: "a definir", hp: "460 HP", xp: "94 EP", gold: "13", "tipo de atk": "", fraqueza: "Físico", locais: "St. Nivalis", drops: "Basting Shield, Field Armour, Field Ring, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Cultix", level: "a definir", hp: "288 HP", xp: "99 EP", gold: "14", "tipo de atk": "", fraqueza: "Gelo", locais: "St. Nivalis", drops: "Fortified Legs, Spellwielder Hat, Onyx, Twinkling Sapphire, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Bloodfly", level: "a definir", hp: "475 HP", xp: "104 EP", gold: "14", "tipo de atk": "", fraqueza: "Gelo", locais: "Yabutu", drops: "Enlighted Necklace, Lesser Health Potion, Lesser Mana Potion, Orange Belt, Orange Hardbelt" },
        { nome: "Orc Leader", level: "a definir", hp: "496 HP", xp: "104 EP", gold: "14", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea", drops: "Freezer Rune, Frostbringer, Lesser Health Potion, Lesser Mana Potion, Ruby" },
        { nome: "Peasant", level: "a definir", hp: "496 HP", xp: "104 EP", gold: "14", "tipo de atk": "", fraqueza: "Físico", locais: "Yabutu", drops: "Faraday Skirt, Lesser Health Potion, Lesser Mana Potion, Mithril Helmet" },
        { nome: "Kappa", level: "a definir", hp: "510 HP", xp: "108 EP", gold: "15", "tipo de atk": "", fraqueza: "Raio", locais: "Yabutu", drops: "Enlighted Ring, Kappa Ichor, Lesser Health Potion, Lesser Mana Potion, Nunchaku, Shuriken" },
        { nome: "Recruit", level: "a definir", hp: "510 HP", xp: "108 EP", gold: "15", "tipo de atk": "", fraqueza: "Fogo", locais: "Yabutu", drops: "Bommelsword, Fan, Focus Shield, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Tempguard", level: "a definir", hp: "510 HP", xp: "108 EP", gold: "15", "tipo de atk": "", fraqueza: "Fogo", locais: "Yabutu", drops: "Bommelsword, Fan, Focus Shield, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Criminal", level: "a definir", hp: "525 HP", xp: "113 EP", gold: "15", "tipo de atk": "", fraqueza: "Físico", locais: "Yabutu", drops: "No loots" },
        { nome: "Monk", level: "a definir", hp: "525 HP", xp: "113 EP", gold: "15", "tipo de atk": "", fraqueza: "Fogo", locais: "Yabutu", drops: "Enlighted Shield, Sai, Sanchaku, Small Health Potion, Small Mana Potion" },
        { nome: "Shogun", level: "a definir", hp: "525 HP", xp: "113 EP", gold: "15", "tipo de atk": "", fraqueza: "Físico", locais: "Yabutu", drops: "Brass Helmet, Enlighted Shirt, Shaoshield Mill, Small Health Potion, Small Mana Potion, Tiger Oil" },
        { nome: "Twombie", level: "a definir", hp: "613 HP", xp: "113 EP", gold: "15", "tipo de atk": "", fraqueza: "Fogo", locais: "Ashmor", drops: "Basting Shirt, Field Helmet, Ice Rune, Small Health Potion, Small Mana Potion" },
        { nome: "Warden", level: "a definir", hp: "525 HP", xp: "113 EP", gold: "15", "tipo de atk": "", fraqueza: "Físico", locais: "Yabutu", drops: "Bommelsword, Cell Key, Fan, Focus Shield" },
        { nome: "Buzzy", level: "a definir", hp: "521 HP", xp: "117 EP", gold: "16", "tipo de atk": "", fraqueza: "Gelo", locais: "Yabutu", drops: "Enlighted Necklace, Orange Belt, Orange Hardbelt, Small Health Potion, Small Mana Potion" },
        { nome: "Long", level: "a definir", hp: "544 HP", xp: "117 EP", gold: "16", "tipo de atk": "", fraqueza: "Raio", locais: "Yabutu", drops: "Energy Blade, Energy Discus, Phial of Yellow Dragon Blood, Small Health Potion, Small Mana Potion, Topaz" },
        { nome: "Ninjaman", level: "a definir", hp: "567 HP", xp: "117 EP", gold: "16", "tipo de atk": "", fraqueza: "Físico", locais: "Yabutu", drops: "Mind Crusher, Small Health Potion, Small Mana Potion, Sparking Plug" },
        { nome: "Tempdragon", level: "a definir", hp: "567 HP", xp: "117 EP", gold: "16", "tipo de atk": "", fraqueza: "Físico", locais: "Yabutu", drops: "No loots" },
        { nome: "Watchdog", level: "a definir", hp: "495 HP", xp: "117 EP", gold: "16", "tipo de atk": "", fraqueza: "Físico", locais: "Yabutu", drops: "No loots" },
        { nome: "Kreppan", level: "a definir", hp: "535 HP", xp: "121 EP", gold: "16", "tipo de atk": "", fraqueza: "Raio", locais: "Yabutu", drops: "Enlighted Ring, Nunchaku, Shuriken, Small Health Potion, Small Mana Potion" },
        { nome: "Primeguard", level: "a definir", hp: "558 HP", xp: "121 EP", gold: "16", "tipo de atk": "", fraqueza: "Fogo", locais: "Yabutu", drops: "Bommelsword, Fan, Focus Shield, Small Health Potion, Small Mana Potion" },
        { nome: "Ristless", level: "a definir", hp: "558 HP", xp: "121 EP", gold: "16", "tipo de atk": "", fraqueza: "Físico", locais: "Yabutu", drops: "Faraday Skirt, Mithril Helmet, Small Health Potion" },
        { nome: "Farmzombie", level: "a definir", hp: "610 HP", xp: "125 EP", gold: "17", "tipo de atk": "", fraqueza: "Fogo", locais: "Yabutu", drops: "Curved Reaver, Mithril Amulet, Ornate Battle Stick, Small Health Potion, Small Mana Potion" },
        { nome: "Nimon", level: "a definir", hp: "586 HP", xp: "125 EP", gold: "17", "tipo de atk": "", fraqueza: "Fogo", locais: "Yabutu", drops: "Enlighted Shield, Sai, Sanchaku, Small Health Potion, Small Mana Potion" },
        { nome: "Wiashi", level: "a definir", hp: "586 HP", xp: "125 EP", gold: "17", "tipo de atk": "", fraqueza: "Físico", locais: "Yabutu", drops: "Brass Legs, Enlighted Cap, Shaoshield Mill, Small Health Potion, Small Mana Potion" },
        { nome: "Bozzy", level: "a definir", hp: "572 HP", xp: "128 EP", gold: "17", "tipo de atk": "", fraqueza: "Gelo e Raio", locais: "Banuna", drops: "Enlighted Necklace, Minor Mana Potion" },
        { nome: "Crocodile", level: "a definir", hp: "600 HP", xp: "128 EP", gold: "17", "tipo de atk": "", fraqueza: "Físico", locais: "Banuna", drops: "Crocodile Tooth, Fortified Armour, Holy Legs, Lesser Health Potion, Lesser Mana Potion" },
        { nome: "Kruppuk", level: "a definir", hp: "600 HP", xp: "128 EP", gold: "17", "tipo de atk": "", fraqueza: "Raio", locais: "Yabutu", drops: "Enlighted Ring, Minor Mana Potion, Nunchaku, Shuriken" },
        { nome: "Mantis", level: "a definir", hp: "540 HP", xp: "128 EP", gold: "17", "tipo de atk": "", fraqueza: "Sagrado", locais: "Banuna", drops: "Small Health Potion, Small Mana Potion, Splatter Helmet, Splatter Hood" },
        { nome: "Minorrior", level: "a definir", hp: "600 HP", xp: "128 EP", gold: "17", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea", drops: "Angelic Armour, Angelic Mantle, Lesser Health Potion, Lesser Mana Potion, Syorta Ore" },
        { nome: "Skonkey", level: "a definir", hp: "614 HP", xp: "131 EP", gold: "18", "tipo de atk": "", fraqueza: "Físico", locais: "Banuna", drops: "Chastity Legs, Chastity Pants, Onyx, Skull Ring, Small Health Potion, Small Mana Potion" },
        { nome: "Tempee", level: "a definir", hp: "614 HP", xp: "131 EP", gold: "18", "tipo de atk": "", fraqueza: "Físico", locais: "Yabutu", drops: "Bommelsword, Fan, Focus Shield" },
        { nome: "Troll", level: "a definir", hp: "547 HP", xp: "131 EP", gold: "18", "tipo de atk": "", fraqueza: "Fogo", locais: "Ashmor, Aurea, Banuna", drops: "Chain Helmet, Emerald, Paradisas, Small Health Potion, Small Mana Potion, Winter Legs" },
        { nome: "Flutto", level: "a definir", hp: "634 HP", xp: "134 EP", gold: "18", "tipo de atk": "", fraqueza: "Físico", locais: "Yabutu", drops: "Energy Blade, Energy Discus, Small Health Potion, Small Mana Potion" },
        { nome: "Sanmon", level: "a definir", hp: "634 HP", xp: "134 EP", gold: "18", "tipo de atk": "", fraqueza: "Fogo", locais: "Yabutu", drops: "Enlighted Shield, Sai, Sanchaku, Small Health Potion, Small Mana Potion" },
        { nome: "Shigun", level: "a definir", hp: "634 HP", xp: "134 EP", gold: "18", "tipo de atk": "", fraqueza: "Fogo", locais: "Yabutu", drops: "Brass Legs, Enlighted Cap, Shaoshield Mill" },
        { nome: "Yeti", level: "a definir", hp: "571 HP", xp: "134 EP", gold: "18", "tipo de atk": "", fraqueza: "Fogo", locais: "St. Nivalis", drops: "Crystal Chain, Sapphire, Small Health Potion, Small Mana Potion, Twinkling Sapphire" },
        { nome: "Alligator", level: "a definir", hp: "656 HP", xp: "137 EP", gold: "19", "tipo de atk": "", fraqueza: "Físico", locais: "Banuna e Starfish Island", drops: "Fortified Armour, Holy Legs, Miracle Herb, Small Health Potion, Small Mana Potion" },
        { nome: "Cyclops", level: "a definir", hp: "656 HP", xp: "137 EP", gold: "19", "tipo de atk": "", fraqueza: "Físico", locais: "Banuna", drops: "Frostbringer, Rune of Winter, Spark Chain, Topaz, Small Health Potion, Small Mana Potion" },
        { nome: "Miomantis", level: "a definir", hp: "590 HP", xp: "137 EP", gold: "19", "tipo de atk": "", fraqueza: "Sagrado", locais: "Banuna", drops: "Small Health Potion, Small Mana Potion, Splatter Helmet, Splatter Hood" },
        { nome: "Cleptoman", level: "a definir", hp: "670 HP", xp: "139 EP", gold: "19", "tipo de atk": "", fraqueza: "Físico", locais: "Banuna", drops: "Chastity Legs, Chastity Pants, Onyx, Skull Ring, Small Health Potion, Small Mana Potion" },
        { nome: "Trollsmash", level: "a definir", hp: "553 HP", xp: "139 EP", gold: "19", "tipo de atk": "", fraqueza: "Fogo", locais: "Banuna", drops: "Chain Helmet, Emerald, Small Health Potion, Small Mana Potion, Winter Legs" },
        { nome: "Musco", level: "a definir", hp: "685 HP", xp: "141 EP", gold: "20", "tipo de atk": "", fraqueza: "Fogo", locais: "Banuna", drops: "Small Health Potion, Small Mana Potion, Soulfire Ring" },
        { nome: "Half Gazer", level: "a definir", hp: "756 HP", xp: "144 EP", gold: "16", "tipo de atk": "", fraqueza: "Físico", locais: "Vargos", drops: "Holy Discus, Holy Lance" },
        { nome: "Evil Sheep", level: "a definir", hp: "699 HP", xp: "146 EP", gold: "20", "tipo de atk": "", fraqueza: "Gelo", locais: "Aurea, Fabulara", drops: "Armoured Ring, Small Health Potion, Small Mana Potion" },
        { nome: "Goblin", level: "a definir", hp: "699 HP", xp: "146 EP", gold: "20", "tipo de atk": "", fraqueza: "Sagrado", locais: "Fabulara, Starfish Island", drops: "Armoured Legs, Armoured Trousers" },
        { nome: "Mammoth", level: "a definir", hp: "699 HP", xp: "146 EP", gold: "20", "tipo de atk": "", fraqueza: "Fogo", locais: "St. Nivalis", drops: "Crystal Ring, Small Health Potion, Small Mana Potion" },
        { nome: "Taumantis", level: "a definir", hp: "639 HP", xp: "146 EP", gold: "20", "tipo de atk": "", fraqueza: "Sagrado", locais: "Aurea", drops: "Small Health Potion, Small Mana Potion, Splatter Helmet, Splatter Hood" },
        { nome: "Witch", level: "a definir", hp: "699 HP", xp: "146 EP", gold: "20", "tipo de atk": "", fraqueza: "Fogo", locais: "Aurea, Fabulara", drops: "Robes, Small Health Potion, Small Mana Potion, Twinkling Emerald" },
        { nome: "Dwarf", level: "a definir", hp: "726 HP", xp: "155 EP", gold: "18", "tipo de atk": "", fraqueza: "Físico", locais: "Fabulara", drops: "Ruby, Small Health Potion, Small Mana Potion" },
        { nome: "Smelliot", level: "a definir", hp: "654 HP", xp: "155 EP", gold: "20", "tipo de atk": "", fraqueza: "Fogo", locais: "St. Nivalis", drops: "Crystal Chain, Sapphire, Small Health Potion, Small Mana Potion, Twinkling Sapphire" },
        { nome: "Trangler", level: "a definir", hp: "599 HP", xp: "155 EP", gold: "20", "tipo de atk": "", fraqueza: "Fogo", locais: "Banuna", drops: "Chain Helmet, Emerald, Small Health Potion, Small Mana Potion" },
        { nome: "Treant", level: "a definir", hp: "726 HP", xp: "155 EP", gold: "20", "tipo de atk": "", fraqueza: "Fogo", locais: "Fabulara", drops: "Crystal Chain, Emerald, Rune Of Winter, Shimmering Onyx, Small Health Potion, Small Mana Potion" },
        { nome: "Ibex", level: "a definir", hp: "748 HP", xp: "163 EP", gold: "17", "tipo de atk": "", fraqueza: "Físico", locais: "Fabulara, Starfish Island", drops: "Brass Helmet, Flogging Rune, Small Health Potion, Small Mana Potion" },
        { nome: "Muscolant", level: "a definir", hp: "748 HP", xp: "163 EP", gold: "21", "tipo de atk": "", fraqueza: "Fogo", locais: "Banuna", drops: "Soulfire Ring, Health Potion" },
        { nome: "Ricombie", level: "a definir", hp: "748 HP", xp: "163 EP", gold: "21", "tipo de atk": "", fraqueza: "Fogo", locais: "Yabutu", drops: "Shaolin Robe, Shogun Armour" },
        { nome: "Shadow", level: "a definir", hp: "748 HP", xp: "163 EP", gold: "21", "tipo de atk": "", fraqueza: "Físico", locais: "Fabulara", drops: "Arctic Spike, Shiver Rune, Small Health Potion, Small Mana Potion, Twinkling Emerald" },
        { nome: "Bantinel", level: "a definir", hp: "762 HP", xp: "172 EP", gold: "22", "tipo de atk": "", fraqueza: "Físico", locais: "Banuna", drops: "Chastity Legs, Chastity Pants, Onyx, Skull Ring, Small Health Potion, Small Mana Potion" },
        { nome: "Crocodylus", level: "a definir", hp: "762 HP", xp: "172 EP", gold: "22", "tipo de atk": "", fraqueza: "Físico", locais: "Banuna", drops: "Fortified Armour, Holy Legs, Miracle Herb" },
        { nome: "Firant", level: "a definir", hp: "762 HP", xp: "172 EP", gold: "22", "tipo de atk": "", fraqueza: "Fogo", locais: "St. Nivalis", drops: "Crystal Chain, Emerald, Rune Of Winter, Shimmering Onyx" },
        { nome: "Hobgoblin", level: "a definir", hp: "762 HP", xp: "172 EP", gold: "22", "tipo de atk": "", fraqueza: "Sagrado", locais: "Fabulara", drops: "Armoured Legs, Armoured Trousers, Lesser Health Potion, Minor Might Potion, Shimmering Onyx" },
        { nome: "Thunderey", level: "a definir", hp: "762 HP", xp: "172 EP", gold: "22", "tipo de atk": "", fraqueza: "Fogo", locais: "Aurea", drops: "Robes, Small Health Potion, Small Mana Potion, Twinkling Emerald" },
        { nome: "Zuppel", level: "a definir", hp: "762 HP", xp: "172 EP", gold: "22", "tipo de atk": "", fraqueza: "Fogo", locais: "St. Nivalis", drops: "Crystal Ring, Small Health Potion, Small Mana Potion" },
        { nome: "Berseclops", level: "a definir", hp: "777 HP", xp: "180 EP", gold: "22", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea", drops: "Frostbringer, Rune Of Winter, Spark Chain, Topaz" },
        { nome: "Petty", level: "a definir", hp: "777 HP", xp: "180 EP", gold: "22", "tipo de atk": "", fraqueza: "Físico", locais: "Starfish Island", drops: "Sailor Cap, Sailor Helmet, Small Health Potion, Small Mana Potion" },
        { nome: "Terrorbird", level: "a definir", hp: "777 HP", xp: "180 EP", gold: "22", "tipo de atk": "", fraqueza: "Fogo", locais: "Starfish Island", drops: "Armoured Cap, Armoured Shield (Wizard), Small Health Potion, Small Mana Potion" },
        { nome: "Vampire", level: "a definir", hp: "738 HP", xp: "180 EP", gold: "22", "tipo de atk": "", fraqueza: "Físico", locais: "Aurea", drops: "Cozy Warmring, Dragon Slayer, Ice Discus, Ruby Ring, Small Health Potion, Small Mana Potion" },
        { nome: "Werewolf", level: "a definir", hp: "753 HP", xp: "180 EP", gold: "22", "tipo de atk": "", fraqueza: "Fogo", locais: "Aurea", drops: "Fugazor, Small Health Potion, Small Mana Potion, Splatter Stick" },
        { nome: "Bokk", level: "a definir", hp: "799 HP", xp: "188 EP", gold: "18", "tipo de atk": "", fraqueza: "Físico", locais: "Starfish Island", drops: "Brass Helmet, Flogging Rune, Small Health Potion, Small Mana Potion" },
        { nome: "Muscolator", level: "a definir", hp: "799 HP", xp: "188 EP", gold: "23", "tipo de atk": "", fraqueza: "Fogo", locais: "Banuna", drops: "Soulfire Ring, Health Potion" },
        { nome: "Stalker", level: "a definir", hp: "799 HP", xp: "188 EP", gold: "23", "tipo de atk": "", fraqueza: "Físico", locais: "St. Nivalis", drops: "Arctic Spike, Shiver Rune, Twinkling Emerald" },
        { nome: "Swabby", level: "a definir", hp: "799 HP", xp: "188 EP", gold: "23", "tipo de atk": "", fraqueza: "Físico", locais: "Starfish Island", drops: "Sailor Legs, Sailor Pants, Small Health Potion, Small Mana Potion" },
        { nome: "Tentacle", level: "a definir", hp: "772 HP", xp: "188 EP", gold: "23", "tipo de atk": "", fraqueza: "Físico", locais: "Starfish Island", drops: "Armoured Amulet, Small Health Potion, Small Mana Potion" },
        { nome: "Watcher", level: "a definir", hp: "799 HP", xp: "188 EP", gold: "23", "tipo de atk": "", fraqueza: "Físico", locais: "Ashmor e Fabulara", drops: "Sapphire, Holy Discus, Holy Lance" },
        { nome: "Bratty", level: "a definir", hp: "819 HP", xp: "196 EP", gold: "23", "tipo de atk": "", fraqueza: "Físico", locais: "Starfish Island", drops: "Sailor Armour, Sailor Jacket, Small Health Potion, Small Mana Potion" },
        { nome: "Captain", level: "a definir", hp: "819 HP", xp: "196 EP", gold: "23", "tipo de atk": "", fraqueza: "Físico", locais: "Starfish Island", drops: "Corsair Tricorn, Pirate Headband, Small Health Potion, Small Mana Potion" },
        { nome: "Flappy", level: "a definir", hp: "819 HP", xp: "196 EP", gold: "23", "tipo de atk": "", fraqueza: "Físico", locais: "Yabutu", drops: "Energy Blade, Energy Discus, Small Health Potion, Small Mana Potion" },
        { nome: "Forofnat", level: "a definir", hp: "819 HP", xp: "196 EP", gold: "23", "tipo de atk": "", fraqueza: "Fogo", locais: "Starfish Island", drops: "Crystal Chain, Rune of Winter, Shimmering Onyx, Small Health Potion, Small Mana Potion" },
        { nome: "Goldminer", level: "a definir", hp: "819 HP", xp: "196 EP", gold: "18", "tipo de atk": "", fraqueza: "Físico", locais: "Fabulara", drops: "Miracle Herb, Ruby, Small Health Potion, Small Mana Potion, Static Shield, Thunder Shield" },
        { nome: "Gremlin", level: "a definir", hp: "819 HP", xp: "196 EP", gold: "23", "tipo de atk": "", fraqueza: "Sagrado", locais: "Starfish Island", drops: "Armoured Legs, Armoured Trousers, Shimmering Onyx, Small Health Potion, Small Mana Potion" },
        { nome: "Stinkilot", level: "a definir", hp: "737 HP", xp: "196 EP", gold: "23", "tipo de atk": "", fraqueza: "Fogo", locais: "Banuna", drops: "Crystal Chain, Emerald, Twinkling Sapphire" },
        { nome: "Stormey", level: "a definir", hp: "819 HP", xp: "196 EP", gold: "23", "tipo de atk": "", fraqueza: "Fogo", locais: "Aurea", drops: "Robes, Small Health Potion, Small Mana Potion, Twinkling Emerald" },
        { nome: "Dragon", level: "a definir", hp: "833 HP", xp: "203 EP", gold: "20", "tipo de atk": "", fraqueza: "Físico", locais: "Fabulara, St. Nivalis", drops: "Dragon Pearl, Fire Ring, Glove Of Eternity, Gold Ring, Phial of Red Dragon Blood, Shield Ring, Small Health Potion" },
        { nome: "Firetty", level: "a definir", hp: "833 HP", xp: "203 EP", gold: "24", "tipo de atk": "", fraqueza: "Físico", locais: "Starfish Island", drops: "Sailor Cap, Sailor Helmet, Small Health Potion, Small Mana Potion" },
        { nome: "Phorus", level: "a definir", hp: "833 HP", xp: "203 EP", gold: "24", "tipo de atk": "", fraqueza: "Fogo", locais: "Starfish Island", drops: "Armoured Cap, Armoured Shield (Wizard), Small Health Potion, Small Mana Potion" },
        { nome: "Zottel", level: "a definir", hp: "833 HP", xp: "203 EP", gold: "24", "tipo de atk": "", fraqueza: "Fogo", locais: "St. Nivalis", drops: "Crystal Ring, Small Health Potion, Small Mana Potion" },
        { nome: "Dessnake", level: "a definir", hp: "787 HP", xp: "211 EP", gold: "25", "tipo de atk": "", fraqueza: "Gelo", locais: "Solahmar", drops: "Battle Ring, Small Health Potion, Small Mana Potion" },
        { nome: "Haunter", level: "a definir", hp: "848 HP", xp: "211 EP", gold: "24", "tipo de atk": "", fraqueza: "Físico", locais: "Ashmor", drops: "Arctic Spike, Shiver Rune, Small Health Potion, Small Mana Potion" },
        { nome: "Markhor", level: "a definir", hp: "848 HP", xp: "211 EP", gold: "19", "tipo de atk": "", fraqueza: "Físico", locais: "Starfish Island", drops: "Brass Helmet, Flogging Rune, Small Health Potion, Small Mana Potion" },
        { nome: "Mummy", level: "a definir", hp: "848 HP", xp: "211 EP", gold: "25", "tipo de atk": "", fraqueza: "Fogo", locais: "Solahmar", drops: "Magma Crown, Magma Headpiece, Small Health Potion, Small Mana Potion" },
        { nome: "Scorpiant", level: "a definir", hp: "777 HP", xp: "211 EP", gold: "24", "tipo de atk": "", fraqueza: "Gelo", locais: "Solahmar", drops: "Battle Ring, Small Health Potion, Small Mana Potion" },
        { nome: "Construct", level: "a definir", hp: "876 HP", xp: "217 EP", gold: "25", "tipo de atk": "", fraqueza: "Gelo", locais: "Solahmar", drops: "Glacier Chain, Small Health Potion" },
        { nome: "Invulruct", level: "a definir", hp: "876 HP", xp: "217 EP", gold: "25", "tipo de atk": "", fraqueza: "Gelo", locais: "Solahmar", drops: "Energy Crystal" },
        { nome: "Raider", level: "a definir", hp: "856 HP", xp: "217 EP", gold: "25", "tipo de atk": "", fraqueza: "Gelo", locais: "Solahmar", drops: "Battle Amulet, Small Health Potion, Small Mana Potion" },
        { nome: "Rivcroc", level: "a definir", hp: "862 HP", xp: "217 EP", gold: "25", "tipo de atk": "", fraqueza: "Físico", locais: "Solahmar", drops: "No loots" },
        { nome: "Scarab", level: "a definir", hp: "862 HP", xp: "217 EP", gold: "25", "tipo de atk": "", fraqueza: "Gelo", locais: "Solahmar", drops: "Blessed Brooch, Small Health Potion, Small Mana Potion" },
        { nome: "Solahmari", level: "a definir", hp: "856 HP", xp: "217 EP", gold: "25", "tipo de atk": "", fraqueza: "Gelo", locais: "Solahmar", drops: "Battle Amulet, Small Health Potion" },
        { nome: "Old Petty", level: "a definir", hp: "884 HP", xp: "224 EP", gold: "25", "tipo de atk": "", fraqueza: "Físico", locais: "Starfish Island", drops: "Sabre Eye Patch" },
        { nome: "Scorpigotu", level: "a definir", hp: "884 HP", xp: "224 EP", gold: "25", "tipo de atk": "", fraqueza: "Gelo", locais: "Solahmar", drops: "Battle Ring, Small Health Potion, Small Mana Potion" },
        { nome: "Titanis", level: "a definir", hp: "884 HP", xp: "224 EP", gold: "26", "tipo de atk": "", fraqueza: "Fogo", locais: "Banuna", drops: "Armoured Cap, Armoured Shield (Warrior), Armoured Shield (Wizard), Health Potion" },
        { nome: "Apprentice", level: "a definir", hp: "912 HP", xp: "230 EP", gold: "26", "tipo de atk": "", fraqueza: "Físico", locais: "Ashmor", drops: "Glacier Chain, Health Potion, Mana Potion" },
        { nome: "Assassin", level: "a definir", hp: "912 HP", xp: "230 EP", gold: "26", "tipo de atk": "", fraqueza: "Físico", locais: "Trasure Island", drops: "Shaolin Pants, Shogun Legs, Emerald, Health Potion, Mana Potion" },
        { nome: "Ice Dragon", level: "a definir", hp: "912 HP", xp: "230 EP", gold: "26", "tipo de atk": "", fraqueza: "Fogo", locais: "St. Nivalis", drops: "Chastity Ring, Dragon Pearl, Glove Of Eternity, Gold Ring" },
        { nome: "Raidguar", level: "a definir", hp: "925 HP", xp: "235 EP", gold: "26", "tipo de atk": "", fraqueza: "Gelo", locais: "Solahmar", drops: "Battle Amulet, Small Health Potion, Small Mana Potion" },
        { nome: "Rottummy", level: "a definir", hp: "912 HP", xp: "235 EP", gold: "26", "tipo de atk": "", fraqueza: "Fogo", locais: "Solahmar, Treasure Island", drops: "Health Potion, Magma Crown" },
        { nome: "Scarapha", level: "a definir", hp: "912 HP", xp: "235 EP", gold: "26", "tipo de atk": "", fraqueza: "Gelo", locais: "Solahmar", drops: "Blessed Brooch, Small Health Potion, Small Mana Potion" },
        { nome: "Slaveward", level: "a definir", hp: "912 HP", xp: "235 EP", gold: "26", "tipo de atk": "", fraqueza: "Fogo", locais: "Solahmar", drops: "NO DROPS" },
        { nome: "Solahmaga", level: "a definir", hp: "925 HP", xp: "238 EP", gold: "27", "tipo de atk": "", fraqueza: "Gelo", locais: "Solahmar", drops: "Battle Amulet, Small Health Potion, Small Mana Potion" },
        { nome: "Vampmaster", level: "a definir", hp: "864 HP", xp: "238 EP", gold: "27", "tipo de atk": "", fraqueza: "Físico", locais: "Ashmor, Treasure Island", drops: "Cozy Warmring, Dragon Slayer, Health Potion, Ice Discus, Mana Potion, Ruby Ring" },
        { nome: "Djinn", level: "a definir", hp: "921 HP", xp: "242 EP", gold: "27", "tipo de atk": "", fraqueza: "Físico", locais: "Solahmar", drops: "Crystal Shard Ring, Health Potion, Mana Potion" },
        { nome: "Pond Croco", level: "a definir", hp: "927 HP", xp: "245 EP", gold: "27", "tipo de atk": "", fraqueza: "Físico", locais: "Treasure Island", drops: "No loots" },
        { nome: "Sphinx", level: "a definir", hp: "927 HP", xp: "245 EP", gold: "27", "tipo de atk": "", fraqueza: "Físico", locais: "Solahmar", drops: "Health Potion, Mana Potion, Sphinx Eye Talisman" },
        { nome: "Rishombie", level: "a definir", hp: "942 HP", xp: "248 EP", gold: "28", "tipo de atk": "", fraqueza: "Fogo", locais: "Treasure Island", drops: "Health Potion, Mana Potion, Shaolin Robe, Shogun Armour" },
        { nome: "Chaomy", level: "a definir", hp: "964 HP", xp: "252 EP", gold: "28", "tipo de atk": "", fraqueza: "Fogo", locais: "Treasure Island, Solahmar", drops: "Health Potion, Magma Crown, Magma Headpiece" },
        { nome: "Redeath", level: "a definir", hp: "979 HP", xp: "255 EP", gold: "28", "tipo de atk": "", fraqueza: "Físico", locais: "Hunterra", drops: "Health Potion, Mana Potion" },
        { nome: "Dark Mage", level: "a definir", hp: "999 HP", xp: "260 EP", gold: "29", "tipo de atk": "", fraqueza: "Físico", locais: "Ashmor", drops: "Glacier Chain, Health Potion, Mana Potion" },
        { nome: "Dreamninja", level: "a definir", hp: "999 HP", xp: "260 EP", gold: "29", "tipo de atk": "", fraqueza: "Físico", locais: "Starfish Island", drops: "Shaolin Pants, Shogun Legs, Health Potion" },
        { nome: "Bloodbeak", level: "a definir", hp: "1036 HP", xp: "265 EP", gold: "29", "tipo de atk": "", fraqueza: "Fogo", locais: "Hunterra", drops: "Health Potion, Mana Potion" },
        { nome: "Flame", level: "a definir", hp: "1040 HP", xp: "268 EP", gold: "30", "tipo de atk": "", fraqueza: "Gelo", locais: "Fabulara, Banuna", drops: "Magma Axe, Scepter Of Fire, Ruby, Miracle Herb, Health Potion, Mana Potion" },
        { nome: "Mythrilon", level: "a definir", hp: "1040 HP", xp: "268 EP", gold: "30", "tipo de atk": "", fraqueza: "Físico", locais: "Banuna", drops: "Dragon Pearl" },
        { nome: "Nunaquatch", level: "a definir", hp: "1053 HP", xp: "272 EP", gold: "30", "tipo de atk": "", fraqueza: "Fogo", locais: "Hunterra", drops: "Health Potion, Mana Potion, Nuna Filet" },
        { nome: "Foresdrake", level: "a definir", hp: "1062 HP", xp: "275 EP", gold: "30", "tipo de atk": "", fraqueza: "Fogo", locais: "Hunterra", drops: "Health Potion, Mana Potion" },
        { nome: "Ritorment", level: "a definir", hp: "1062 HP", xp: "275 EP", gold: "30", "tipo de atk": "", fraqueza: "Físico", locais: "Yabutu", drops: "Miracle Herb, Shaolin Headbelt, Shogun Helmet" },
        { nome: "Tyraclops", level: "a definir", hp: "1062 HP", xp: "275 EP", gold: "30", "tipo de atk": "", fraqueza: "Físico", locais: "Vargos", drops: "Frostbringer, Rune Of Winter, Small Health Potion, Small Mana Potion, Spark Chain, Topaz" },
        { nome: "Shiveron", level: "a definir", hp: "1088 HP", xp: "280 EP", gold: "31", "tipo de atk": "", fraqueza: "Fogo", locais: "St. Nivalis", drops: "Chastity Ring, Dragon Pearl, Glove Of Eternity, Gold Ring, Hardwater Ring, Health Potion, Mana Potion, Sword Of Legend" },
        { nome: "Gigantula", level: "a definir", hp: "1092 HP", xp: "282 EP", gold: "31", "tipo de atk": "", fraqueza: "Físico", locais: "Erebos", drops: "Spider Crystal, Health Potion, Mana Potion" },
        { nome: "Gazer", level: "a definir", hp: "1105 HP", xp: "285 EP", gold: "31", "tipo de atk": "", fraqueza: "Físico", locais: "Vargos", drops: "Holy Discus, Holy Lance" },
        { nome: "Aquata", level: "a definir", hp: "1118 HP", xp: "288 EP", gold: "31", "tipo de atk": "", fraqueza: "Físico", locais: "Starrfish Island", drops: "Health Potion" },
        { nome: "Horrornet", level: "a definir", hp: "1140 HP", xp: "292 EP", gold: "32", "tipo de atk": "", fraqueza: "Fogo", locais: "Hunterra, Erebos", drops: "Health Potion" },
        { nome: "Skelpirate", level: "a definir", hp: "1140 HP", xp: "292 EP", gold: "32", "tipo de atk": "", fraqueza: "Físico", locais: "Starrfish Island", drops: "Health Potion" },
        { nome: "Leechacle", level: "a definir", hp: "1152 HP", xp: "295 EP", gold: "32", "tipo de atk": "", fraqueza: "Físico", locais: "Hunterra", drops: "Health Potion" },
        { nome: "Abysson", level: "a definir", hp: "1164 HP", xp: "298 EP", gold: "32", "tipo de atk": "", fraqueza: "Físico", locais: "Vargos, Circusia", drops: "Dragon Pearl, Fire Ring, Glove Of Eternity, Gold Ring, Health Potion, Mana Potion, Shield Ring, Sword Of Legend" },
        { nome: "Crysmantis", level: "a definir", hp: "1164 HP", xp: "298 EP", gold: "32", "tipo de atk": "", fraqueza: "Sagrado", locais: "Hunterra", drops: "Crystal Eye, Health Potion, Mana Potion" },
        { nome: "Crustea", level: "a definir", hp: "1176 HP", xp: "302 EP", gold: "33", "tipo de atk": "", fraqueza: "Físico", locais: "Hunterra", drops: "Health Potion, Mana Potion" },
        { nome: "Crystallon", level: "a definir", hp: "1188 HP", xp: "305 EP", gold: "33", "tipo de atk": "", fraqueza: "Fogo", locais: "St. Nivalis", drops: "Chastity Ring, Dragon Pearl, Glove Of Eternity, Gold Ring, Great Health Potion, Great Mana Potion, Hardwater Ring, Sword Of Legend" },
        { nome: "Kapami", level: "a definir", hp: "1188 HP", xp: "305 EP", gold: "33", "tipo de atk": "", fraqueza: "Raio", locais: "Erebos", drops: "Health Potion, Mana Potion, Nudelishroom" },
        { nome: "Bastinx", level: "a definir", hp: "1200 HP", xp: "310 EP", gold: "33", "tipo de atk": "", fraqueza: "Físico", locais: "Hunterra, Erebos", drops: "Health Potion, Mana Potion" },
        { nome: "Ifrit", level: "a definir", hp: "1200 HP", xp: "310 EP", gold: "33", "tipo de atk": "", fraqueza: "Gelo", locais: "Hunterra, Erebos", drops: "Health Potion, Mana Potion" },
        { nome: "Ninjana", level: "a definir", hp: "1230 HP", xp: "315 EP", gold: "34", "tipo de atk": "", fraqueza: "Físico", locais: "Banuna", drops: "Blazing Ore, Blue Rift Jewel, Crown Helmet, Great Health Potion, Great Mana Potion, King'S Hood, Ninja Ring" },
        { nome: "Behemoth", level: "a definir", hp: "1248 HP", xp: "320 EP", gold: "34", "tipo de atk": "", fraqueza: "Fogo", locais: "Erebos", drops: "Lightning Conductor, Major Health Potion, Storming Ore" },
        { nome: "Blaze (1)", level: "a definir", hp: "1260 HP", xp: "325 EP", gold: "34", "tipo de atk": "", fraqueza: "Gelo", locais: "Erebos", drops: "Blaze Ash, Major Health Potion, Major Mana Potion" },
        { nome: "Blaze (2)", level: "a definir", hp: "1260 HP", xp: "325 EP", gold: "34", "tipo de atk": "", fraqueza: "Gelo", locais: "Erebos", drops: "Blaze Ash, Major Health Potion, Major Mana Potion" },
        { nome: "Cerberus", level: "a definir", hp: "1272 HP", xp: "330 EP", gold: "35", "tipo de atk": "", fraqueza: "Gelo", locais: "Erebos", drops: "Blazing Ore, Hell Crystal, Major Health Potion, Major Mana Potion" },
        { nome: "Hell Guard", level: "a definir", hp: "1284 HP", xp: "332 EP", gold: "35", "tipo de atk": "", fraqueza: "Gelo", locais: "Erebos", drops: "Crystal Cutter, Heavy Ore, Major Health Potion, Major Mana Potion, Onset Of Winter" },
        { nome: "Fireball", level: "a definir", hp: "1296 HP", xp: "335 EP", gold: "35", "tipo de atk": "", fraqueza: "Gelo", locais: "Erebos", drops: "Major Health Potion, Major Mana Potion" },
        { nome: "Chaleton", level: "a definir", hp: "1875 HP", xp: "367 EP", gold: "53", "tipo de atk": "", fraqueza: "Fogo e Raio", locais: "Ephialtis", drops: "Great Health Potion, Great Mana Potion, Great Might Potion, Major Health Potion, Major Mana Potion" },
        { nome: "Chaombie", level: "a definir", hp: "1895 HP", xp: "369 EP", gold: "53", "tipo de atk": "", fraqueza: "Fogo", locais: "Ephialtis", drops: "Great Health Potion, Great Mana Potion, Great Might Potion, Major Health Potion, Major Mana Potion" },
        { nome: "Chaodrake", level: "a definir", hp: "1985 HP", xp: "405 EP", gold: "40", "tipo de atk": "", fraqueza: "Sagrado", locais: "Ephialtis", drops: "Etheric Ore, Soulkeeper, Spiritbane, Fine Health Potion" },
        { nome: "Demon", level: "a definir", hp: "1997 HP", xp: "379 EP", gold: "41", "tipo de atk": "", fraqueza: "Gelo", locais: "Ephialtis", drops: "Fine Health Potion, Fine Mana Potion, Magma Axe, Scepter Of Fire, Steel Chain" },
        { nome: "Wisp", level: "a definir", hp: "1997 HP", xp: "379 EP", gold: "41", "tipo de atk": "", fraqueza: "Físico", locais: "Fabulara", drops: "Energy Ring, Fine Health Potion, Fine Mana Potion, Magma Axe, Scepter Of Fire" },
        { nome: "Fouldrake", level: "a definir", hp: "2049 HP", xp: "384 EP", gold: "42", "tipo de atk": "", fraqueza: "Sagrado", locais: "Ephialtis", drops: "Etheric Ore, Soulkeeper, Spiritbane, Fine Health Potion" },
        { nome: "Demon Lord", level: "a definir", hp: "2067 HP", xp: "386 EP", gold: "42", "tipo de atk": "", fraqueza: "Gelo", locais: "Ephialtis", drops: "Blazing Ore, Conflagrator, Fine Health Potion, Fine Mana Potion, Fine Might Potion, Fire Nexus" },
        { nome: "Archdemon", level: "a definir", hp: "2136 HP", xp: "392 EP", gold: "43", "tipo de atk": "", fraqueza: "Gelo", locais: "Ephialtis, Circusia", drops: "Blazing Ore, Conflagrator, Fine Health Potion, Fine Mana Potion, Fine Might Potion, Fire Nexus" },
        { nome: "Vamplord", level: "a definir", hp: "2150 HP", xp: "431 EP", gold: "44", "tipo de atk": "", fraqueza: "Físico", locais: "Ashmor", drops: "Cozy Warmring, Dragon Slayer, Health Potion, Ice Discus, Mana Potion, Ruby Ring" },
        { nome: "Darkwiz", level: "a definir", hp: "2165 HP", xp: "433 EP", gold: "44", "tipo de atk": "", fraqueza: "Físico", locais: "Ashmor", drops: "Glacier Chain, Health Potion, Mana Potion, Mandrake, Onyx, Spiritual Amulet, Twinkling Emerald" },
        { nome: "ElderDjinn", level: "a definir", hp: "2180 HP", xp: "433 EP", gold: "45", "tipo de atk": "", fraqueza: "Físico", locais: "Solahmar", drops: "Crystal Shard Ring, Health Potion, Mana Potion" },
        { nome: "Borc", level: "a definir", hp: "1162 HP", xp: "320 EP", gold: "34", "tipo de atk": "", fraqueza: "Raio e Físico", locais: "Orthoma", drops: "Health Potion, Mana Potion, Skull Armour, Skull Cloak" },
        { nome: "Borc Guard", level: "a definir", hp: "1205 HP", xp: "326 EP", gold: "35", "tipo de atk": "", fraqueza: "Raio e Físico", locais: "Orthoma", drops: "Health Potion, Mana Potion, Skull Armour, Skull Cloak" },
        { nome: "Borc Lord", level: "a definir", hp: "1234 HP", xp: "331 EP", gold: "35", "tipo de atk": "", fraqueza: "Raio e Físico", locais: "Orthoma", drops: "Health Potion, Mana Potion, Skull Armour, Skull Cloak" },
        { nome: "Worc", level: "a definir", hp: "1334 HP", xp: "346 EP", gold: "37", "tipo de atk": "", fraqueza: "Gelo e Físico", locais: "Orthoma", drops: "Health Potion, Mana Potion, Skull Deflector, Skull Shield" },
        { nome: "Worc Miner", level: "a definir", hp: "1379 HP", xp: "350 EP", gold: "38", "tipo de atk": "", fraqueza: "Gelo e Físico", locais: "Orthoma", drops: "Health Potion, Mana Potion, Skull Deflector, Skull Shield" },
        { nome: "Worc Smith", level: "a definir", hp: "1417 HP", xp: "355 EP", gold: "39", "tipo de atk": "", fraqueza: "Gelo e Físico", locais: "Orthoma", drops: "Health Potion, Mana Potion, Skull Deflector, Skull Shield" },
        { nome: "Redliz", level: "a definir", hp: "1118 HP", xp: "300 EP", gold: "32", "tipo de atk": "", fraqueza: "Gelo e Físico", locais: "Orthoma", drops: "Health Potion, Mana Potion, Skull Legs, Skull Pants" },
        { nome: "RoyalGhoul", level: "a definir", hp: "1292 HP", xp: "308 EP", gold: "36", "tipo de atk": "", fraqueza: "A conferir", locais: "Circusia", drops: "Health Potion, Mana Potion, Sapphire" },
        { nome: "Drowned", level: "a definir", hp: "1307 HP", xp: "310 EP", gold: "36", "tipo de atk": "", fraqueza: "A conferir", locais: "Underwater, Starfish Island", drops: "Desconhecidos" },
        { nome: "Manycolour", level: "a definir", hp: "1431 HP", xp: "325 EP", gold: "39", "tipo de atk": "", fraqueza: "A conferir", locais: "Desconhecido", drops: "No loots" },
        { nome: "Corrusnake", level: "a definir", hp: "1553 HP", xp: "336 EP", gold: "42", "tipo de atk": "", fraqueza: "Fogo e Físico", locais: "Aurea", drops: "No loots" },
        { nome: "Tyrannix", level: "a definir", hp: "1452 HP", xp: "336 EP", gold: "43", "tipo de atk": "", fraqueza: "A conferir", locais: "Riftion", drops: "Crown Legs, Freezing Ore, Great Health Potion, Great Mana Potion, Red Rift Jewel" },
        { nome: "Guardian", level: "a definir", hp: "833 HP", xp: "215 EP", gold: "0", "tipo de atk": "", fraqueza: "A conferir", locais: "Orthoma Arena", drops: "No loots" }
    ],
    Itens: [],   // gerada automaticamente a partir das lojas (e de ITENS_MANUAIS) mais abaixo

    // Lojas: cada loja tem uma lista "itens" (armas e armaduras). Para adicionar um item real, copie
    // uma linha e preencha:  tipo: "Arma" ou "Armadura" | level | vocacao: "Guerreiro" ou "Mago" |
    // elemento (so armas): "Fisico", "Fogo", "Gelo", "Raio" ou "Sagrado" (ex.: "Fogo e Gelo").
    // Campos extras (opcionais): preco: "30 gp" | dano: [["Fisico","1-5"],["Fogo","1-10"]] |
    // materiais: "texto" (ferreiros/trocas) | mana: "3" (armas de mago) | defesa: [["Fisico","14"],["Raio","5"]] (porcentagens) | obs: "texto".
    // Tudo que estiver "A definir" ainda precisa ser conferido.
    Lojas: [
        {
            nome: "Lybera - Pruftin's Blades", ilha: "Lybera", cidade: "Lybera", npc: "Pruftin's Blades",
            itensVenda: "Armas iniciais exclusivas de Warrior (nivel 0-10)",
            itens: [
                {nome: "Little Sword", tipo: "Arma", level: "0", vocacao: "Guerreiro", preco: "30 gp", mana: "", dano: [["Físico", "1-12"]], defesa: [], npc: "Pruftin's Blades"},
                {nome: "Glowing Hammer", tipo: "Arma", level: "3", vocacao: "Guerreiro", preco: "40 gp", mana: "", dano: [["Físico", "1-5"], ["Fogo", "1-10"]], defesa: [], npc: "Pruftin's Blades"},
                {nome: "Meelee Mallet", tipo: "Arma", level: "4", vocacao: "Guerreiro", preco: "50 gp", mana: "", dano: [["Físico", "1-16"]], defesa: [], npc: "Pruftin's Blades"},
                {nome: "Short Sword", tipo: "Arma", level: "5", vocacao: "Guerreiro", preco: "60 gp", mana: "", dano: [["Físico", "1-16"]], defesa: [], npc: "Pruftin's Blades"},
                {nome: "Barbarian Axe", tipo: "Arma", level: "7", vocacao: "Guerreiro", preco: "100 gp", mana: "", dano: [["Gelo", "1-22"]], defesa: [], npc: "Pruftin's Blades"},
                {nome: "Mace", tipo: "Arma", level: "9", vocacao: "Guerreiro", preco: "150 gp", mana: "", dano: [["Físico", "1-25"]], defesa: [], npc: "Pruftin's Blades"},
                {nome: "Flash Hacker", tipo: "Arma", level: "10", vocacao: "Guerreiro", preco: "170 gp", mana: "", dano: [["Físico", "1-12"], ["Raio", "1-15"]], defesa: [], npc: "Pruftin's Blades"}
            ]
        },
        {
            nome: "Lybera - Buzz & Flash Samsalus", ilha: "Lybera", cidade: "Lybera", npc: "Buzz & Flash Samsalus",
            itensVenda: "Cajados, cristais e runas iniciais exclusivos de Wizard (nivel 0-11)",
            itens: [
                {nome: "Chili Stick", tipo: "Arma", level: "0", vocacao: "Mago", preco: "20 gp", mana: "1", dano: [["Fogo", "1-12"]], defesa: [], npc: "Buzz & Flash Samsalus"},
                {nome: "Feathered Stick", tipo: "Arma", level: "3", vocacao: "Mago", preco: "30 gp", mana: "2", dano: [["Físico", "1-16"]], defesa: [], npc: "Buzz & Flash Samsalus"},
                {nome: "Blazing Crystal", tipo: "Arma", level: "4", vocacao: "Mago", preco: "40 gp", mana: "2", dano: [["Fogo", "1-18"]], defesa: [], npc: "Buzz & Flash Samsalus"},
                {nome: "Magic Root", tipo: "Arma", level: "11", vocacao: "Mago", preco: "60 gp", mana: "4", dano: [["Físico", "1-38"]], defesa: [], npc: "Buzz & Flash Samsalus"},
                {nome: "Magic Spoon", tipo: "Arma", level: "6", vocacao: "Mago", preco: "70 gp", mana: "3", dano: [["Físico", "1-24"]], defesa: [], npc: "Buzz & Flash Samsalus"},
                {nome: "Ice Crystal", tipo: "Arma", level: "7", vocacao: "Mago", preco: "80 gp", mana: "3", dano: [["Gelo", "1-26"]], defesa: [], npc: "Buzz & Flash Samsalus"},
                {nome: "Spark Stick", tipo: "Arma", level: "9", vocacao: "Mago", preco: "100 gp", mana: "3", dano: [["Raio", "1-30"]], defesa: [], npc: "Buzz & Flash Samsalus"},
                {nome: "Fire Rune", tipo: "Arma", level: "10", vocacao: "Mago", preco: "120 gp", mana: "3", dano: [["Fogo", "1-34"]], defesa: [], npc: "Buzz & Flash Samsalus"}
            ]
        },
        {
            nome: "Lybera - Jekato's Defense", ilha: "Lybera", cidade: "Lybera", npc: "Jekato's Defense",
            itensVenda: "Pecas defensivas iniciais (elmos, armaduras leves e escudos)",
            itens: [
                {nome: "Leather Legs", tipo: "Calça", level: "1", vocacao: "Guerreiro", preco: "10 gp", mana: "", dano: [], defesa: [["Físico", "2"]], npc: "Jekato's Defense"},
                {nome: "Headband", tipo: "Elmo", level: "1", vocacao: "Guerreiro e Mago", preco: "20 gp", mana: "", dano: [], defesa: [["Físico", "1"]], npc: "Jekato's Defense"},
                {nome: "Brass Helmet", tipo: "Elmo", level: "5", vocacao: "Guerreiro", preco: "40 gp", mana: "", dano: [], defesa: [["Físico", "3"]], npc: "Jekato's Defense"},
                {nome: "Leather Armor", tipo: "Armadura", level: "18", vocacao: "Guerreiro", preco: "50 gp", mana: "", dano: [], defesa: [["Fogo", "10"], ["Gelo", "10"]], npc: "Jekato's Defense"},
                {nome: "Griffin Shield", tipo: "Escudo", level: "36", vocacao: "Guerreiro e Mago", preco: "60 gp", mana: "", dano: [], defesa: [["Fogo", "10"], ["Gelo", "10"]], npc: "Jekato's Defense"},
                {nome: "Brass Armor", tipo: "Armadura", level: "25", vocacao: "Guerreiro", preco: "125 gp", mana: "", dano: [], defesa: [["Físico", "14"], ["Raio", "5"]], npc: "Jekato's Defense"},
                {nome: "Light Armour", tipo: "Armadura", level: "1-6", vocacao: "A definir", preco: "A definir", mana: "", dano: [], defesa: [["Físico", "2"]], obs: "Nota da fonte: catalogo mais recente de Lybera (nivel 1-6).", npc: "Jekato's Defense"},
                {nome: "Sworder Armour", tipo: "Armadura", level: "1-6", vocacao: "A definir", preco: "156 gp", mana: "", dano: [], defesa: [["Físico", "5"]], obs: "Nota da fonte: catalogo mais recente de Lybera (nivel 1-6).", npc: "Jekato's Defense"}
            ]
        },
        {
            nome: "Aurea - Arsenal", ilha: "Aurea", cidade: "Aurea", npc: "Arsenal",
            itensVenda: "Armas de Warrior de nivel 5 a 23",
            itens: [
                {nome: "Short Sword", tipo: "Arma", level: "5", vocacao: "Guerreiro", preco: "60 gp", mana: "", dano: [["Físico", "1-16"]], defesa: [], npc: "Arsenal"},
                {nome: "Flame Spear", tipo: "Arma", level: "6", vocacao: "Guerreiro", preco: "85 gp", mana: "", dano: [["Físico", "1-4"], ["Fogo", "1-15"]], defesa: [], npc: "Arsenal"},
                {nome: "Barbarian Axe", tipo: "Arma", level: "7", vocacao: "Guerreiro", preco: "100 gp", mana: "", dano: [["Gelo", "1-22"]], defesa: [], npc: "Arsenal"},
                {nome: "Mace", tipo: "Arma", level: "9", vocacao: "Guerreiro", preco: "150 gp", mana: "", dano: [["Físico", "1-25"]], defesa: [], npc: "Arsenal"},
                {nome: "Flash Hacker", tipo: "Arma", level: "10", vocacao: "Guerreiro", preco: "204 gp", mana: "", dano: [["Físico", "1-12"], ["Raio", "1-15"]], defesa: [], npc: "Arsenal"},
                {nome: "Axe", tipo: "Arma", level: "11", vocacao: "Guerreiro", preco: "210 gp", mana: "", dano: [["Físico", "1-30"]], defesa: [], npc: "Arsenal"},
                {nome: "Incensor", tipo: "Arma", level: "12", vocacao: "Guerreiro", preco: "232 gp", mana: "", dano: [["Fogo", "1-32"]], defesa: [], npc: "Arsenal"},
                {nome: "Sword", tipo: "Arma", level: "15", vocacao: "Guerreiro", preco: "268 gp", mana: "", dano: [["Físico", "1-35"]], defesa: [], npc: "Arsenal"},
                {nome: "War Hammer", tipo: "Arma", level: "17", vocacao: "Guerreiro", preco: "310 gp", mana: "", dano: [["Físico", "1-40"]], defesa: [], npc: "Arsenal"},
                {nome: "Fire Sword", tipo: "Arma", level: "19", vocacao: "Guerreiro", preco: "350 gp", mana: "", dano: [["Fogo", "1-40"]], defesa: [], npc: "Arsenal"},
                {nome: "Battle Axe", tipo: "Arma", level: "23", vocacao: "Guerreiro", preco: "410 gp", mana: "", dano: [["Físico", "1-45"]], defesa: [], npc: "Arsenal"}
            ]
        },
        {
            nome: "Aurea - Orcish Goods", ilha: "Aurea", cidade: "Aurea", npc: "Orcish Goods",
            itensVenda: "Equipamentos brutos de Warrior (vila dos Orcs, norte de Aurea)",
            itens: [
                {nome: "Club", tipo: "Arma", level: "0", vocacao: "Guerreiro", preco: "15 gp", mana: "", dano: [["Físico", "1-9"]], defesa: [], npc: "Orcish Goods"},
                {nome: "Meelee Mallet", tipo: "Arma", level: "4", vocacao: "Guerreiro", preco: "50 gp", mana: "", dano: [["Físico", "1-16"]], defesa: [], npc: "Orcish Goods"},
                {nome: "Axe", tipo: "Arma", level: "11", vocacao: "Guerreiro", preco: "210 gp", mana: "", dano: [["Físico", "1-30"]], defesa: [], npc: "Orcish Goods"},
                {nome: "War Hammer", tipo: "Arma", level: "17", vocacao: "Guerreiro", preco: "310 gp", mana: "", dano: [["Físico", "1-40"]], defesa: [], npc: "Orcish Goods"},
                {nome: "Battle Axe", tipo: "Arma", level: "23", vocacao: "Guerreiro", preco: "410 gp", mana: "", dano: [["Físico", "1-45"]], defesa: [], npc: "Orcish Goods"},
                {nome: "Studded / Orcish Shield", tipo: "Escudo", level: "10", vocacao: "Guerreiro", preco: "140 gp", mana: "", dano: [], defesa: [["Físico", "4"]], npc: "Orcish Goods"}
            ]
        },
        {
            nome: "Aurea - Wizard Zoran", ilha: "Aurea", cidade: "Aurea", npc: "Wizard Zoran",
            itensVenda: "Armas magicas de Wizard de nivel 6 a 22",
            itens: [
                {nome: "Magic Spoon", tipo: "Arma", level: "6", vocacao: "Mago", preco: "70 gp", mana: "3", dano: [["Físico", "1-24"]], defesa: [], npc: "Wizard Zoran"},
                {nome: "Ice Crystal", tipo: "Arma", level: "7", vocacao: "Mago", preco: "80 gp", mana: "3", dano: [["Gelo", "1-26"]], defesa: [], npc: "Wizard Zoran"},
                {nome: "Spark Stick", tipo: "Arma", level: "9", vocacao: "Mago", preco: "100 gp", mana: "3", dano: [["Raio", "1-30"]], defesa: [], npc: "Wizard Zoran"},
                {nome: "Fire Rune", tipo: "Arma", level: "10", vocacao: "Mago", preco: "120 gp", mana: "3", dano: [["Fogo", "1-34"]], defesa: [], npc: "Wizard Zoran"},
                {nome: "Magic Root", tipo: "Arma", level: "11", vocacao: "Mago", preco: "140 gp", mana: "4", dano: [["Físico", "1-38"]], defesa: [], npc: "Wizard Zoran"},
                {nome: "Ice Rune", tipo: "Arma", level: "13", vocacao: "Mago", preco: "180 gp", mana: "4", dano: [["Gelo", "1-42"]], defesa: [], npc: "Wizard Zoran"},
                {nome: "Flogging Rune", tipo: "Arma", level: "15", vocacao: "Mago", preco: "268 gp", mana: "6", dano: [["Físico", "1-48"]], defesa: [], npc: "Wizard Zoran"},
                {nome: "Fire Discus", tipo: "Arma", level: "18", vocacao: "Mago", preco: "320 gp", mana: "6", dano: [["Fogo", "1-54"]], defesa: [], npc: "Wizard Zoran"},
                {nome: "Energy Rune", tipo: "Arma", level: "19", vocacao: "Mago", preco: "350 gp", mana: "6", dano: [["Raio", "1-58"]], defesa: [], npc: "Wizard Zoran"},
                {nome: "Brass Rod", tipo: "Arma", level: "22", vocacao: "Mago", preco: "410 gp", mana: "7", dano: [["Físico", "1-66"]], defesa: [], npc: "Wizard Zoran"}
            ]
        },
        {
            nome: "Aurea - Sam's Armoury", ilha: "Aurea", cidade: "Aurea", npc: "Sam's Armoury",
            itensVenda: "Armaduras, escudos e elmos para Warrior e Wizard (ate Plate Armour)",
            itens: [
                {nome: "Light Armour", tipo: "Armadura", level: "2", vocacao: "Guerreiro", preco: "40 gp", mana: "", dano: [], defesa: [["Físico", "2"]], npc: "Sam's Armoury"},
                {nome: "Light Shirt", tipo: "Armadura", level: "2", vocacao: "Mago", preco: "40 gp", mana: "", dano: [], defesa: [["Físico", "2"]], npc: "Sam's Armoury"},
                {nome: "Sworder Armour", tipo: "Armadura", level: "6", vocacao: "Guerreiro", preco: "156 gp", mana: "", dano: [], defesa: [["Físico", "5"]], npc: "Sam's Armoury"},
                {nome: "Apprentice Shirt", tipo: "Armadura", level: "6", vocacao: "Mago", preco: "156 gp", mana: "", dano: [], defesa: [["Físico", "6"]], npc: "Sam's Armoury"},
                {nome: "Mercenary Helmet", tipo: "Elmo", level: "10", vocacao: "Guerreiro", preco: "140 gp", mana: "", dano: [], defesa: [["Físico", "4"]], npc: "Sam's Armoury"},
                {nome: "Spell Student Hood", tipo: "Elmo", level: "10", vocacao: "Mago", preco: "140 gp", mana: "", dano: [], defesa: [["Físico", "5"]], npc: "Sam's Armoury"},
                {nome: "Mercenary Armour", tipo: "Armadura", level: "11", vocacao: "Guerreiro", preco: "220 gp", mana: "", dano: [], defesa: [["Físico", "7"]], npc: "Sam's Armoury"},
                {nome: "Spell Student Shirt", tipo: "Armadura", level: "11", vocacao: "Mago", preco: "220 gp", mana: "", dano: [], defesa: [["Físico", "8"]], npc: "Sam's Armoury"},
                {nome: "Mercenary Shield", tipo: "Escudo", level: "12", vocacao: "Guerreiro", preco: "160 gp", mana: "", dano: [], defesa: [["Físico", "4"]], npc: "Sam's Armoury"},
                {nome: "Spell Student Shield", tipo: "Escudo", level: "12", vocacao: "Mago", preco: "160 gp", mana: "", dano: [], defesa: [["Físico", "5"]], npc: "Sam's Armoury"},
                {nome: "Leather Armour", tipo: "Armadura", level: "18", vocacao: "Guerreiro", preco: "350 gp", mana: "", dano: [], defesa: [["Fogo", "10"], ["Gelo", "10"]], npc: "Sam's Armoury"},
                {nome: "Night Shirt", tipo: "Armadura", level: "18", vocacao: "Mago", preco: "350 gp", mana: "", dano: [], defesa: [["Fogo", "13"], ["Gelo", "13"]], npc: "Sam's Armoury"},
                {nome: "Field Armour", tipo: "Armadura", level: "20", vocacao: "Guerreiro", preco: "420 gp", mana: "", dano: [], defesa: [["Físico", "12"]], npc: "Sam's Armoury"},
                {nome: "Plate Armour", tipo: "Armadura", level: "75", vocacao: "Guerreiro", preco: "856 gp", mana: "", dano: [], defesa: [["Físico", "35"], ["Raio", "-9"]], obs: "Nivel 75 por 856 gp: valor a conferir no jogo.", npc: "Sam's Armoury"}
            ]
        },
        {
            nome: "Ashmor - Rustblaze", ilha: "Ashmor", cidade: "Ashmor", npc: "Rustblaze",
            itensVenda: "Armas de Warrior e de Wizard (mesmo NPC)",
            itens: [
                {nome: "Barbarian Axe", tipo: "Arma", level: "7", vocacao: "Guerreiro", preco: "195 gp", mana: "", dano: [["Gelo", "1-22"]], defesa: [], npc: "Rustblaze"},
                {nome: "Prayer Club", tipo: "Arma", level: "8", vocacao: "Guerreiro", preco: "236 gp", mana: "", dano: [["Sagrado", "1-22"]], defesa: [], npc: "Rustblaze"},
                {nome: "Flash Hacker", tipo: "Arma", level: "10", vocacao: "Guerreiro", preco: "204 gp", mana: "", dano: [["Físico", "1-12"], ["Raio", "1-15"]], defesa: [], npc: "Rustblaze"},
                {nome: "Incensor", tipo: "Arma", level: "12", vocacao: "Guerreiro", preco: "232 gp", mana: "", dano: [["Fogo", "1-32"]], defesa: [], npc: "Rustblaze"},
                {nome: "Silver Mace", tipo: "Arma", level: "13", vocacao: "Guerreiro", preco: "244 gp", mana: "", dano: [["Físico", "1-5"], ["Sagrado", "1-30"]], defesa: [], npc: "Rustblaze"},
                {nome: "Sword", tipo: "Arma", level: "15", vocacao: "Guerreiro", preco: "268 gp", mana: "", dano: [["Físico", "1-35"]], defesa: [], npc: "Rustblaze"},
                {nome: "Ice Crystal", tipo: "Arma", level: "7", vocacao: "Mago", preco: "195 gp", mana: "3", dano: [["Gelo", "1-26"]], defesa: [], obs: "Arma exclusiva de Wizard (o site Hexat a lista junto das de Warrior por erro de icone).", npc: "Rustblaze"},
                {nome: "Staff of Forgetting", tipo: "Arma", level: "8", vocacao: "Mago", preco: "236 gp", mana: "2", dano: [["Sagrado", "1-28"]], defesa: [], npc: "Rustblaze"},
                {nome: "Spark Stick", tipo: "Arma", level: "9", vocacao: "Mago", preco: "276 gp", mana: "3", dano: [["Raio", "1-30"]], defesa: [], npc: "Rustblaze"},
                {nome: "Fire Rune", tipo: "Arma", level: "10", vocacao: "Mago", preco: "204 gp", mana: "3", dano: [["Fogo", "1-34"]], defesa: [], npc: "Rustblaze"},
                {nome: "Flogging Rune", tipo: "Arma", level: "15", vocacao: "Mago", preco: "268 gp", mana: "6", dano: [["Físico", "1-48"]], defesa: [], npc: "Rustblaze"}
            ]
        },
        {
            nome: "Ashmor - Protus' Armoury", ilha: "Ashmor", cidade: "Ashmor", npc: "Protus' Armoury",
            itensVenda: "Armaduras, escudos e aneis para Warrior e Wizard (nivel 10-18)",
            itens: [
                {nome: "Mercenary Helmet", tipo: "Elmo", level: "10", vocacao: "Guerreiro", preco: "140 gp", mana: "", dano: [], defesa: [["Físico", "4"]], npc: "Protus' Armoury"},
                {nome: "Spell Student Hood", tipo: "Elmo", level: "10", vocacao: "Mago", preco: "140 gp", mana: "", dano: [], defesa: [["Físico", "5"]], npc: "Protus' Armoury"},
                {nome: "Mercenary Armour", tipo: "Armadura", level: "11", vocacao: "Guerreiro", preco: "220 gp", mana: "", dano: [], defesa: [["Físico", "7"]], npc: "Protus' Armoury"},
                {nome: "Spell Student Shirt", tipo: "Armadura", level: "11", vocacao: "Mago", preco: "220 gp", mana: "", dano: [], defesa: [["Físico", "8"]], npc: "Protus' Armoury"},
                {nome: "Mercenary Shield", tipo: "Escudo", level: "12", vocacao: "Guerreiro", preco: "160 gp", mana: "", dano: [], defesa: [["Físico", "4"]], npc: "Protus' Armoury"},
                {nome: "Spell Student Shield", tipo: "Escudo", level: "12", vocacao: "Mago", preco: "160 gp", mana: "", dano: [], defesa: [["Físico", "5"]], npc: "Protus' Armoury"},
                {nome: "Power Ring", tipo: "Anel", level: "15", vocacao: "Guerreiro e Mago", preco: "160 gp", mana: "", dano: [], defesa: [["Físico", "5"]], npc: "Protus' Armoury"},
                {nome: "Priest Ring", tipo: "Anel", level: "15", vocacao: "Guerreiro e Mago", preco: "160 gp", mana: "", dano: [], defesa: [["Sagrado", "5"]], npc: "Protus' Armoury"},
                {nome: "Leather Armour", tipo: "Armadura", level: "18", vocacao: "Guerreiro", preco: "350 gp", mana: "", dano: [], defesa: [["Fogo", "10"], ["Gelo", "10"]], npc: "Protus' Armoury"},
                {nome: "Night Shirt", tipo: "Armadura", level: "18", vocacao: "Mago", preco: "350 gp", mana: "", dano: [], defesa: [["Fogo", "13"], ["Gelo", "13"]], npc: "Protus' Armoury"}
            ]
        },
        {
            nome: "St. Nivalis - Nivial Arts", ilha: "St. Nivalis", cidade: "St. Nivalis", npc: "Nivial Arts",
            itensVenda: "Cajados, orbes e runas exclusivos de Wizard (nivel 13-31). Precos com ~ sao medias aproximadas.",
            itens: [
                {nome: "Ice Rune", tipo: "Arma", level: "13", vocacao: "Mago", preco: "~180 gp", mana: "4", dano: [["Gelo", "1-42"]], defesa: [], npc: "Nivial Arts"},
                {nome: "Soul Rune", tipo: "Arma", level: "16", vocacao: "Mago", preco: "~280 gp", mana: "5", dano: [["Sagrado", "1-50"]], defesa: [], npc: "Nivial Arts"},
                {nome: "Fire Discus", tipo: "Arma", level: "18", vocacao: "Mago", preco: "~320 gp", mana: "6", dano: [["Fogo", "1-54"]], defesa: [], npc: "Nivial Arts"},
                {nome: "Energy Rune", tipo: "Arma", level: "19", vocacao: "Mago", preco: "~350 gp", mana: "6", dano: [["Raio", "1-58"]], defesa: [], npc: "Nivial Arts"},
                {nome: "Brass Rod", tipo: "Arma", level: "22", vocacao: "Mago", preco: "~410 gp", mana: "7", dano: [["Físico", "1-66"]], defesa: [], npc: "Nivial Arts"},
                {nome: "Ice Discus", tipo: "Arma", level: "24", vocacao: "Mago", preco: "~430 gp", mana: "7", dano: [["Gelo", "1-72"]], defesa: [], npc: "Nivial Arts"},
                {nome: "Fire Rod", tipo: "Arma", level: "28", vocacao: "Mago", preco: "~470 gp", mana: "8", dano: [["Fogo", "1-82"]], defesa: [], npc: "Nivial Arts"},
                {nome: "Energy Discus", tipo: "Arma", level: "31", vocacao: "Mago", preco: "~510 gp", mana: "9", dano: [["Raio", "1-90"]], defesa: [], npc: "Nivial Arts"}
            ]
        },
        {
            nome: "St. Nivalis - Sizzling Things / Harold's", ilha: "St. Nivalis", cidade: "St. Nivalis", npc: "Sizzling Things / Harold's",
            itensVenda: "Armas fisicas e elementais de Warrior (nivel 19-30). Precos com ~ sao medias aproximadas.",
            itens: [
                {nome: "Fire Sword", tipo: "Arma", level: "19", vocacao: "Guerreiro", preco: "~350 gp", mana: "", dano: [["Fogo", "1-40"]], defesa: [], npc: "Sizzling Things / Harold's"},
                {nome: "Ice Cleaver", tipo: "Arma", level: "20", vocacao: "Guerreiro", preco: "~370 gp", mana: "", dano: [["Gelo", "1-41"]], defesa: [], npc: "Sizzling Things / Harold's"},
                {nome: "Bommelsword", tipo: "Arma", level: "22", vocacao: "Guerreiro", preco: "~400 gp", mana: "", dano: [["Fogo", "5-43"]], defesa: [], npc: "Sizzling Things / Harold's"},
                {nome: "Battle Axe", tipo: "Arma", level: "23", vocacao: "Guerreiro", preco: "~410 gp", mana: "", dano: [["Físico", "1-45"]], defesa: [], npc: "Sizzling Things / Harold's"},
                {nome: "Energy Blade", tipo: "Arma", level: "30", vocacao: "Guerreiro", preco: "~440 gp", mana: "", dano: [["Raio", "1-62"]], defesa: [], npc: "Sizzling Things / Harold's"},
                {nome: "Sanchaku", tipo: "Arma", level: "26", vocacao: "Guerreiro", preco: "~450 gp", mana: "", dano: [["Físico", "1-58"]], defesa: [], npc: "Sizzling Things / Harold's"},
                {nome: "Curved Reaver", tipo: "Arma", level: "30", vocacao: "Guerreiro", preco: "~490 gp", mana: "", dano: [["Físico", "1-70"]], defesa: [], npc: "Sizzling Things / Harold's"}
            ]
        },
        {
            nome: "St. Nivalis - Knolt's Armor", ilha: "St. Nivalis", cidade: "St. Nivalis", npc: "Knolt's Armor",
            itensVenda: "Armaduras e protecoes contra frio/fogo para Warrior e Wizard (nivel 14-25). Precos com ~ sao medias aproximadas.",
            itens: [
                {nome: "Fur-lined Helmet", tipo: "Elmo", level: "14", vocacao: "Guerreiro", preco: "~240 gp", mana: "", dano: [], defesa: [["Fogo", "6"], ["Gelo", "6"]], npc: "Knolt's Armor"},
                {nome: "Fur-lined Shirt", tipo: "Armadura", level: "14", vocacao: "Mago", preco: "~240 gp", mana: "", dano: [], defesa: [["Fogo", "8"], ["Gelo", "8"]], npc: "Knolt's Armor"},
                {nome: "Freezer Shield", tipo: "Escudo", level: "15", vocacao: "Guerreiro", preco: "~250 gp", mana: "", dano: [], defesa: [["Fogo", "5"], ["Gelo", "5"]], npc: "Knolt's Armor"},
                {nome: "Nivalian Ring", tipo: "Anel", level: "15", vocacao: "Guerreiro e Mago", preco: "~250 gp", mana: "", dano: [], defesa: [["Fogo", "5"], ["Gelo", "5"]], npc: "Knolt's Armor"},
                {nome: "Nivalian Necklace", tipo: "Amuleto", level: "16", vocacao: "Guerreiro e Mago", preco: "~260 gp", mana: "", dano: [], defesa: [["Fogo", "4"], ["Gelo", "4"]], npc: "Knolt's Armor"},
                {nome: "Fur-lined Armour", tipo: "Armadura", level: "17", vocacao: "Guerreiro", preco: "~320 gp", mana: "", dano: [], defesa: [["Fogo", "10"], ["Gelo", "10"]], npc: "Knolt's Armor"},
                {nome: "Freezer Planks", tipo: "A definir", level: "17", vocacao: "Mago", preco: "~280 gp", mana: "", dano: [], defesa: [["Fogo", "7"], ["Gelo", "7"]], npc: "Knolt's Armor"},
                {nome: "Governor Armour", tipo: "Armadura", level: "22", vocacao: "Guerreiro", preco: "800 gp", mana: "", dano: [], defesa: [["Físico", "5"], ["Gelo", "13"]], npc: "Knolt's Armor"},
                {nome: "Spellwielder Shirt", tipo: "Armadura", level: "24", vocacao: "Mago", preco: "430 gp", mana: "", dano: [], defesa: [["Físico", "16"], ["Raio", "5"]], npc: "Knolt's Armor"},
                {nome: "Brass Armour", tipo: "Armadura", level: "25", vocacao: "Guerreiro", preco: "450 gp", mana: "", dano: [], defesa: [["Físico", "14"], ["Raio", "5"]], npc: "Knolt's Armor"}
            ]
        },
        {
            nome: "Fabulara - Zwerghammer's", ilha: "Fabulara", cidade: "Fabulara", npc: "Zwerghammer's",
            itensVenda: "Armas intermediarias de Warrior, forja subterranea de Goldforge (nivel 23-39). Precos com ~ sao medias aproximadas.",
            itens: [
                {nome: "Battle Axe", tipo: "Arma", level: "23", vocacao: "Guerreiro", preco: "~410 gp", mana: "", dano: [["Físico", "1-45"]], defesa: [], npc: "Zwerghammer's"},
                {nome: "Sanchaku", tipo: "Arma", level: "26", vocacao: "Guerreiro", preco: "~450 gp", mana: "", dano: [["Físico", "1-58"]], defesa: [], npc: "Zwerghammer's"},
                {nome: "Curved Reaver", tipo: "Arma", level: "30", vocacao: "Guerreiro", preco: "~490 gp", mana: "", dano: [["Físico", "1-70"]], defesa: [], npc: "Zwerghammer's"},
                {nome: "Holy Lance", tipo: "Arma", level: "33", vocacao: "Guerreiro", preco: "~520 gp", mana: "", dano: [["Físico", "1-8"], ["Sagrado", "1-60"]], defesa: [], npc: "Zwerghammer's", obs: "Dano Físico 1-8 e Sagrado 1-60 segundo a TibiaME4All (a Hexat lista 1-10 e 1-66)."},
                {nome: "Broad Sword", tipo: "Arma", level: "36", vocacao: "Guerreiro", preco: "~540 gp", mana: "", dano: [["Físico", "1-80"]], defesa: [], npc: "Zwerghammer's"},
                {nome: "Jumbo Slayer", tipo: "Arma", level: "39", vocacao: "Guerreiro", preco: "~570 gp", mana: "", dano: [["Físico", "1-20"], ["Gelo", "1-80"]], defesa: [], npc: "Zwerghammer's"}
            ]
        },
        {
            nome: "Fabulara - Flashulara United", ilha: "Fabulara", cidade: "Fabulara", npc: "Flashulara United",
            itensVenda: "Cajados e runas de Wizard em Goldforge (nivel 22-38). Precos com ~ sao medias aproximadas.",
            itens: [
                {nome: "Brass Rod", tipo: "Arma", level: "22", vocacao: "Mago", preco: "~410 gp", mana: "7", dano: [["Físico", "1-66"]], defesa: [], npc: "Flashulara United"},
                {nome: "Fire Rod", tipo: "Arma", level: "28", vocacao: "Mago", preco: "~470 gp", mana: "8", dano: [["Fogo", "1-82"]], defesa: [], npc: "Flashulara United"},
                {nome: "Energy Discus", tipo: "Arma", level: "31", vocacao: "Mago", preco: "~510 gp", mana: "9", dano: [["Raio", "1-90"]], defesa: [], npc: "Flashulara United"},
                {nome: "Soul Discus", tipo: "Arma", level: "34", vocacao: "Mago", preco: "~530 gp", mana: "10", dano: [["Sagrado", "1-98"]], defesa: [], npc: "Flashulara United"},
                {nome: "Crystal Rod", tipo: "Arma", level: "36", vocacao: "Mago", preco: "~550 gp", mana: "10", dano: [["Gelo", "1-104"]], defesa: [], npc: "Flashulara United"},
                {nome: "Ceremonial Rod", tipo: "Arma", level: "38", vocacao: "Mago", preco: "~570 gp", mana: "11", dano: [["Físico", "1-105"], ["Sagrado", "1-15"]], defesa: [], npc: "Flashulara United"}
            ]
        },
        {
            nome: "Fabulara - Norvir's Armors", ilha: "Fabulara", cidade: "Fabulara", npc: "Norvir's Armors",
            itensVenda: "Armaduras de Goldforge para Warrior e Wizard (nivel 40-43). Precos com ~ sao medias aproximadas.",
            itens: [
                {nome: "Armoured Legs", tipo: "Calça", level: "40", vocacao: "Guerreiro", preco: "~480 gp", mana: "", dano: [], defesa: [["Físico", "15"]], npc: "Norvir's Armors"},
                {nome: "Enlighted Shirt", tipo: "Armadura", level: "40", vocacao: "Mago", preco: "~530 gp", mana: "", dano: [], defesa: [["Físico", "19"]], npc: "Norvir's Armors"},
                {nome: "Armoured Mail", tipo: "Armadura", level: "42", vocacao: "Guerreiro", preco: "548 gp", mana: "", dano: [], defesa: [["Físico", "21"]], npc: "Norvir's Armors"},
                {nome: "Armoured Helmet", tipo: "Elmo", level: "41", vocacao: "Guerreiro", preco: "~460 gp", mana: "", dano: [], defesa: [["Físico", "12"]], npc: "Norvir's Armors"},
                {nome: "Armoured Shield", tipo: "Escudo", level: "43", vocacao: "Guerreiro", preco: "~490 gp", mana: "", dano: [], defesa: [["Físico", "12"]], npc: "Norvir's Armors"}
            ]
        },
        {
            nome: "Banuna - Friday's Weapons", ilha: "Banuna", cidade: "Banuna", npc: "Friday's Weapons",
            itensVenda: "Armas de nivel 30-36 para Warrior e Wizard (praia de Banuna). Precos com ~ sao medias aproximadas.",
            itens: [
                {nome: "Curved Reaver", tipo: "Arma", level: "30", vocacao: "Guerreiro", preco: "~490 gp", mana: "", dano: [["Físico", "1-70"]], defesa: [], npc: "Friday's Weapons"},
                {nome: "Holy Lance", tipo: "Arma", level: "33", vocacao: "Guerreiro", preco: "~520 gp", mana: "", dano: [["Físico", "1-8"], ["Sagrado", "1-60"]], defesa: [], npc: "Friday's Weapons", obs: "Dano Físico 1-8 e Sagrado 1-60 segundo a TibiaME4All (a Hexat lista 1-10 e 1-66)."},
                {nome: "Broad Sword", tipo: "Arma", level: "36", vocacao: "Guerreiro", preco: "~540 gp", mana: "", dano: [["Físico", "1-80"]], defesa: [], npc: "Friday's Weapons"},
                {nome: "Energy Discus", tipo: "Arma", level: "31", vocacao: "Mago", preco: "~510 gp", mana: "9", dano: [["Raio", "1-90"]], defesa: [], npc: "Friday's Weapons"},
                {nome: "Soul Discus", tipo: "Arma", level: "34", vocacao: "Mago", preco: "~530 gp", mana: "10", dano: [["Sagrado", "1-98"]], defesa: [], npc: "Friday's Weapons"},
                {nome: "Crystal Rod", tipo: "Arma", level: "36", vocacao: "Mago", preco: "~550 gp", mana: "10", dano: [["Gelo", "1-104"]], defesa: [], npc: "Friday's Weapons"}
            ]
        },
        {
            nome: "Banuna - Crocos Leather", ilha: "Banuna", cidade: "Banuna", npc: "Crocos Leather",
            itensVenda: "Armaduras da selva para Warrior e Wizard (nivel 28-37). Precos com ~ sao medias aproximadas.",
            itens: [
                {nome: "Hunter Helmet", tipo: "Elmo", level: "28", vocacao: "Guerreiro", preco: "~360 gp", mana: "", dano: [], defesa: [["Físico", "8"]], npc: "Crocos Leather"},
                {nome: "Magus Hood", tipo: "Elmo", level: "28", vocacao: "Mago", preco: "~360 gp", mana: "", dano: [], defesa: [["Físico", "9"]], npc: "Crocos Leather"},
                {nome: "Hunter Shield", tipo: "Escudo", level: "30", vocacao: "Guerreiro", preco: "~380 gp", mana: "", dano: [], defesa: [["Físico", "8"]], npc: "Crocos Leather"},
                {nome: "Magus Shield", tipo: "Escudo", level: "30", vocacao: "Mago", preco: "~380 gp", mana: "", dano: [], defesa: [["Físico", "9"]], npc: "Crocos Leather"},
                {nome: "Chain Legs", tipo: "Calça", level: "34", vocacao: "Guerreiro", preco: "~430 gp", mana: "", dano: [], defesa: [["Físico", "12"]], npc: "Crocos Leather"},
                {nome: "Chain Armour", tipo: "Armadura", level: "37", vocacao: "Guerreiro", preco: "~480 gp", mana: "", dano: [], defesa: [["Físico", "18"]], npc: "Crocos Leather"},
                {nome: "Robe of Wisdom", tipo: "Armadura", level: "37", vocacao: "Mago", preco: "~480 gp", mana: "", dano: [], defesa: [["Físico", "18"]], npc: "Crocos Leather"}
            ]
        },
        {
            nome: "Solahmar - Salmars' Emporium e The Cauldron", ilha: "Solahmar", cidade: "Solahmar", npc: "Salmars' Emporium e The Cauldron",
            itensVenda: "Equipamentos intermediarios/avancados (nivel 42-54) e resistencias elementais do deserto. Precos com ~ sao medias aproximadas.",
            itens: [
                {nome: "Desert Blade", tipo: "Arma", level: "42", vocacao: "Guerreiro", preco: "~620 gp", mana: "", dano: [["Físico", "1-92"]], defesa: [], npc: "Salmars' Emporium e The Cauldron"},
                {nome: "Sun Staff / Rod", tipo: "Arma", level: "42", vocacao: "Mago", preco: "~620 gp", mana: "12", dano: [["Fogo", "1-118"]], defesa: [], obs: "Nome exato a confirmar (a fonte lista duas opcoes).", npc: "Salmars' Emporium e The Cauldron"},
                {nome: "Sandstorm Shield", tipo: "Escudo", level: "45", vocacao: "Guerreiro e Mago", preco: "A definir", mana: "", dano: [], defesa: [["Físico", "11"], ["Raio", "8"]], obs: "Preco nao informado na fonte (coluna deslocada na tabela).", npc: "Salmars' Emporium e The Cauldron"},
                {nome: "Nomad Armour", tipo: "Armadura", level: "48", vocacao: "Guerreiro", preco: "A definir", mana: "", dano: [], defesa: [["Físico", "23"], ["Fogo", "10"]], obs: "Preco nao informado na fonte (coluna deslocada na tabela).", npc: "Salmars' Emporium e The Cauldron"},
                {nome: "Nomad Robe", tipo: "Armadura", level: "48", vocacao: "Mago", preco: "A definir", mana: "", dano: [], defesa: [["Físico", "22"], ["Fogo", "12"]], obs: "Preco nao informado na fonte (coluna deslocada na tabela).", npc: "Salmars' Emporium e The Cauldron"},
                {nome: "Pharaoh's Guard", tipo: "A definir", level: "54", vocacao: "Guerreiro", preco: "A definir", mana: "", dano: [], defesa: [["Físico", "26"], ["Sagrado", "8"]], obs: "Preco nao informado na fonte (coluna deslocada na tabela).", npc: "Salmars' Emporium e The Cauldron"}
            ]
        },
        {
            nome: "Yabutu - Hattori's Forge", ilha: "Yabutu", cidade: "Yabutu", npc: "Hattori's Forge",
            itensVenda: "Katanas, armas orientais e cajados (nivel 24-47). Precos com ~ sao medias aproximadas.",
            itens: [
                {nome: "Wakizashi", tipo: "Arma", level: "24", vocacao: "Guerreiro", preco: "~430 gp", mana: "", dano: [["Físico", "1-50"]], defesa: [], npc: "Hattori's Forge"},
                {nome: "Katana", tipo: "Arma", level: "47", vocacao: "Guerreiro", preco: "~500 gp", mana: "", dano: [["Físico", "10-100"]], defesa: [], npc: "Hattori's Forge"},
                {nome: "Naginata", tipo: "Arma", level: "38", vocacao: "Guerreiro", preco: "~560 gp", mana: "", dano: [["Raio", "1-78"]], defesa: [], npc: "Hattori's Forge"},
                {nome: "Bamboo Staff", tipo: "Arma", level: "26", vocacao: "Mago", preco: "~450 gp", mana: "8", dano: [["Físico", "1-76"]], defesa: [], npc: "Hattori's Forge"},
                {nome: "Dragon Rod", tipo: "Arma", level: "35", vocacao: "Mago", preco: "~540 gp", mana: "10", dano: [["Fogo", "1-100"]], defesa: [], npc: "Hattori's Forge"},
                {nome: "Spirit Orb / Discus", tipo: "Arma", level: "40", vocacao: "Mago", preco: "~590 gp", mana: "11", dano: [["Sagrado", "1-114"]], defesa: [], obs: "Nome exato a confirmar (a fonte lista duas opcoes).", npc: "Hattori's Forge"}
            ]
        },
        {
            nome: "Yabutu - Kesuke's Yorois e Rei's Bambus Wards", ilha: "Yabutu", cidade: "Yabutu", npc: "Kesuke's Yorois e Rei's Bambus Wards",
            itensVenda: "Armaduras orientais (Yorois) e escudos de bambu (nivel 20-39). Precos com ~ sao medias aproximadas.",
            itens: [
                {nome: "Bamboo Shield", tipo: "Escudo", level: "20", vocacao: "Guerreiro e Mago", preco: "~280 gp", mana: "", dano: [], defesa: [["Físico", "6"]], npc: "Kesuke's Yorois e Rei's Bambus Wards"},
                {nome: "Ashigaru Helmet", tipo: "Elmo", level: "25", vocacao: "Guerreiro", preco: "~330 gp", mana: "", dano: [], defesa: [["Físico", "7"]], npc: "Kesuke's Yorois e Rei's Bambus Wards"},
                {nome: "Shinobi Hood", tipo: "Elmo", level: "25", vocacao: "Mago", preco: "~330 gp", mana: "", dano: [], defesa: [["Físico", "8"]], npc: "Kesuke's Yorois e Rei's Bambus Wards"},
                {nome: "Ashigaru Yoroi", tipo: "Armadura", level: "29", vocacao: "Guerreiro", preco: "~410 gp", mana: "", dano: [], defesa: [["Físico", "15"]], npc: "Kesuke's Yorois e Rei's Bambus Wards"},
                {nome: "Shinobi Garb", tipo: "Armadura", level: "29", vocacao: "Mago", preco: "~410 gp", mana: "", dano: [], defesa: [["Físico", "15"]], npc: "Kesuke's Yorois e Rei's Bambus Wards"},
                {nome: "Samurai Yoroi", tipo: "Armadura", level: "39", vocacao: "Guerreiro", preco: "A definir", mana: "", dano: [], defesa: [["Físico", "19"], ["Fogo", "6"]], obs: "Preco nao informado na fonte (coluna deslocada na tabela).", npc: "Kesuke's Yorois e Rei's Bambus Wards"},
                {nome: "Onmyoji Robe", tipo: "Armadura", level: "39", vocacao: "Mago", preco: "A definir", mana: "", dano: [], defesa: [["Físico", "19"], ["Raio", "6"]], obs: "Preco nao informado na fonte (coluna deslocada na tabela).", npc: "Kesuke's Yorois e Rei's Bambus Wards"}
            ]
        },
        {
            nome: "Starrfish Island - Orek's Not-Stolen, Borek's Not-Stolen e Nurla's Voodoo", ilha: "Starrfish Island", cidade: "Starrfish Island", npc: "Orek's Not-Stolen, Borek's Not-Stolen e Nurla's Voodoo",
            itensVenda: "Armas fisicas, vestes piratas e itens misticos/voodoo (nivel 27-37). Precos com ~ sao medias aproximadas.",
            itens: [
                {nome: "Cutlass", tipo: "Arma", level: "27", vocacao: "Guerreiro", preco: "~460 gp", mana: "", dano: [["Físico", "1-60"]], defesa: [], npc: "Orek's Not-Stolen, Borek's Not-Stolen e Nurla's Voodoo"},
                {nome: "Pirate Sabre", tipo: "Arma", level: "35", vocacao: "Guerreiro", preco: "~530 gp", mana: "", dano: [["Físico", "1-77"]], defesa: [], npc: "Orek's Not-Stolen, Borek's Not-Stolen e Nurla's Voodoo"},
                {nome: "Voodoo Doll / Wand", tipo: "Arma", level: "29", vocacao: "Mago", preco: "~480 gp", mana: "9", dano: [["Trevas / Sagrado", "1-85"]], defesa: [], obs: "Nome exato a confirmar (a fonte lista duas opcoes). Elemento citado como Trevas (Dark) / Sagrado.", npc: "Orek's Not-Stolen, Borek's Not-Stolen e Nurla's Voodoo"},
                {nome: "Cursed Skull Rod", tipo: "Arma", level: "37", vocacao: "Mago", preco: "~560 gp", mana: "10", dano: [["Gelo", "1-106"]], defesa: [], npc: "Orek's Not-Stolen, Borek's Not-Stolen e Nurla's Voodoo"},
                {nome: "Pirate Coat", tipo: "Armadura", level: "31", vocacao: "Guerreiro", preco: "A definir", mana: "", dano: [], defesa: [["Físico", "16"], ["Gelo", "5"]], obs: "Preco nao informado na fonte (coluna deslocada na tabela).", npc: "Orek's Not-Stolen, Borek's Not-Stolen e Nurla's Voodoo"},
                {nome: "Buccaneer Shirt", tipo: "Armadura", level: "31", vocacao: "Mago", preco: "A definir", mana: "", dano: [], defesa: [["Físico", "16"], ["Gelo", "6"]], obs: "Preco nao informado na fonte (coluna deslocada na tabela).", npc: "Orek's Not-Stolen, Borek's Not-Stolen e Nurla's Voodoo"},
                {nome: "Buckler of the Sea", tipo: "Escudo", level: "33", vocacao: "Guerreiro e Mago", preco: "A definir", mana: "", dano: [], defesa: [["Físico", "9"], ["Gelo", "7"]], obs: "Preco nao informado na fonte (coluna deslocada na tabela).", npc: "Orek's Not-Stolen, Borek's Not-Stolen e Nurla's Voodoo"}
            ]
        },
        {
            nome: "Doratia", ilha: "Doratia", cidade: "Doratia", npc: "NPCs da cidade",
            itensVenda: "Plate Armour (nivel 75) e equipamentos nivel 80-89 por troca de tokens",
            itens: [
                {nome: "Plate Armour", tipo: "Armadura", level: "75", vocacao: "Guerreiro", preco: "856 gp", mana: "", dano: [], defesa: [["Físico", "35"], ["Raio", "-9"]], obs: "Vendida pelo NPC da cidade.", npc: "NPCs da cidade"},
                {nome: "Conjuntos elementais (nivel 80-89)", tipo: "Conjuntos (armas e armaduras)", level: "80-89", vocacao: "A definir", preco: "A definir", materiais: "Tokens locais + Dragon Scales (boss Everdragon)", mana: "", dano: [], defesa: [], obs: "Conjuntos completos de Fogo, Gelo, Energia (Raio) e Sagrado, obtidos por troca de tokens e Dragon Scales.", npc: "NPCs da cidade"}
            ]
        },
        {
            nome: "Erebos", ilha: "Erebos", cidade: "Erebos", npc: "Ferreiro Wieland",
            itensVenda: "Aprimoramento de sets nivel 79 e forja de armas nivel 119",
            itens: [
                {nome: "Aprimoramento de sets (nivel 79)", tipo: "Aprimoramento (armadura)", level: "79", vocacao: "A definir", preco: "A definir", materiais: "Astral Seals (boss Biestig) + gold", mana: "", dano: [], defesa: [], obs: "Eleva armaduras de nivel 79, aumentando a protecao fisica/elemental.", npc: "Ferreiro Wieland"},
                {nome: "Forja de armas (nivel 119)", tipo: "Arma", level: "119", vocacao: "A definir", preco: "A definir", materiais: "Astral Seals, fragmentos de minerios de Erebos e gold", mana: "", dano: [], defesa: [], obs: "Armas de alto dano base e elemental (como Hellfire e Astral).", npc: "Ferreiro Wieland"}
            ]
        },
        {
            nome: "Ephialtis", ilha: "Ephialtis", cidade: "Ephialtis", npc: "Ferreiros Plinto e Alberich",
            itensVenda: "Sets nivel 79, armaduras nivel 99 e armas nivel 129",
            itens: [
                {nome: "Aprimoramento de conjuntos (nivel 79)", tipo: "Aprimoramento (armadura)", level: "79", vocacao: "A definir", preco: "A definir", materiais: "Materiais da ilha + gold", mana: "", dano: [], defesa: [], obs: "Alberich aprimora conjuntos de armaduras de nivel 79.", npc: "Alberich"},
                {nome: "Armaduras (nivel 99)", tipo: "Forja/aprimoramento (armadura)", level: "99", vocacao: "A definir", preco: "A definir", materiais: "Chaos Shreds (boss Mutabor), Blazing Ore e Etheric Ore", mana: "", dano: [], defesa: [], obs: "Plinto forja e aprimora armaduras de nivel 99.", npc: "Plinto"},
                {nome: "Armas (nivel 129)", tipo: "Arma", level: "129", vocacao: "A definir", preco: "A definir", materiais: "Chaos Shreds (boss Mutabor), Blazing Ore e Etheric Ore", mana: "", dano: [], defesa: [], obs: "Plinto forja e aprimora armas de nivel 129.", npc: "Plinto"}
            ]
        },
        {
            nome: "Gorgoros", ilha: "Gorgoros", cidade: "Solahmar (apos a quest de Gorgoros)", npc: "Ferreiro Eldar e NPCs de troca",
            itensVenda: "Conjunto fisico nivel 109/110 (troca de tokens) e armas nivel 149 forjadas por Eldar",
            itens: [
                {nome: "Conjunto fisico e acessorios (nivel 109/110)", tipo: "Conjunto (armadura e acessorios)", level: "109-110", vocacao: "Guerreiro e Mago", preco: "A definir", materiais: "Tokens das Boss Battles da ilha (Tauragor, Kyklopes e Medusa) e das quests locais", mana: "", dano: [], defesa: [], npc: "NPCs de troca", obs: "Alta resistencia Fisica (Hit) contra o dano bruto dos monstros da ilha. Inclui colares e aneis de nivel 109/110 (conjuntos Kalcin / Gorgoros). Liberado apos concluir a linha de quests de Gorgoros."},
                {nome: "Armas forjadas por Eldar (nivel 149)", tipo: "Arma", level: "149", vocacao: "Guerreiro e Mago", preco: "A definir", materiais: "Ouro, minerios raros e coracoes/itens dos chefes de Gorgoros", mana: "", dano: [], defesa: [], npc: "Eldar", obs: "Estao entre as armas mais fortes do jogo e duram 9.999 usos. Versoes de dano Fisico e Elemental (Fogo, Gelo, Energia e Sagrado) para as duas vocacoes.", elemento: "Físico, Fogo, Gelo, Raio e Sagrado"}
            ]
        },
        {
            nome: "Orthoma e Maleisla", ilha: "Orthoma e Maleisla", cidade: "Orthoma e Maleisla", npc: "Trocker (Orthoma) e Seelacor (Maleisla)",
            itensVenda: "Armaduras nivel 129 (troca de tokens) e acessorios nivel 139/140",
            itens: [
                {nome: "Conjuntos de armaduras (nivel 129)", tipo: "Conjunto (elmo, peitoral, calcas e escudo)", level: "129", vocacao: "Guerreiro e Mago", preco: "A definir", materiais: "Tokens de missoes diarias e recompensas dos baus de Trocker e Seelacor", mana: "", dano: [], defesa: [], npc: "NPCs locais", obs: "Alta defesa Fisica (Hit) e variacoes de protecao elemental (Fogo, Gelo, Energia e Sagrado). Tem opcao de aprimoramento (upgrade) para aumentar os status."},
                {nome: "Colares avancados (nivel 139)", tipo: "Amuleto", level: "139", vocacao: "Guerreiro e Mago", preco: "A definir", materiais: "Sistemas de troca e rituais avancados ligados as ilhas", mana: "", dano: [], defesa: [], npc: "NPCs locais", obs: "Bonus expressivos de resistencia elemental e atributos para conteudo endgame."},
                {nome: "Aneis avancados (nivel 140)", tipo: "Anel", level: "140", vocacao: "Guerreiro e Mago", preco: "A definir", materiais: "Sistemas de troca e rituais avancados ligados as ilhas", mana: "", dano: [], defesa: [], npc: "NPCs locais", obs: "Bonus expressivos de resistencia elemental e atributos para conteudo endgame."}
            ]
        }
    ]
};

// Faixa de nivel de cada ilha: "iniciante" (verde), "intermediario" (amarelo) ou "alto" (vermelho).
// Para mudar uma loja de faixa, troque o valor da ilha aqui.
var FAIXA_POR_ILHA = {
    "Lybera": "iniciante", "Aurea": "iniciante",
    "Ashmor": "intermediario", "St. Nivalis": "intermediario", "Fabulara": "intermediario",
    "Banuna": "intermediario", "Solahmar": "intermediario", "Yabutu": "intermediario",
    "Starrfish Island": "intermediario",
    "Doratia": "alto", "Erebos": "alto", "Ephialtis": "alto", "Gorgoros": "alto",
    "Orthoma e Maleisla": "alto"
};
var FAIXAS_LOJA = ["iniciante", "intermediario", "alto"];
var INFO_FAIXA_LOJA = {
    iniciante:     { titulo: "NÍVEL INICIANTE",     detalhe: "Lybera e Aurea",           cor: "#4ADE80" },
    intermediario: { titulo: "NÍVEL INTERMEDIÁRIO", detalhe: "nível 10 a 65+",           cor: "#FFD600" },
    alto:          { titulo: "NÍVEL ALTO",          detalhe: "nível 75 a 149, ferreiros e trocas", cor: "#FF4D4D" }
};

function CorFaixaLoja(faixa) {
    return INFO_FAIXA_LOJA[faixa] ? INFO_FAIXA_LOJA[faixa].cor : "";
}

// Liga cada item da loja ao nome da loja (usado na tela de detalhes e na busca).
(function() {
    // Faixa de cada loja e ordem (iniciante, intermediario, alto) mantendo a ordem original dentro de cada faixa.
    var grupos = { iniciante: [], intermediario: [], alto: [] };
    for (var g = 0; g < DB_TIBIAME.Lojas.length; g++) {
        var lj = DB_TIBIAME.Lojas[g];
        lj.faixa = FAIXA_POR_ILHA[lj.ilha] || "intermediario";
        grupos[lj.faixa].push(lj);
        for (var q = 0; q < lj.itens.length; q++) lj.itens[q].faixa = lj.faixa;
    }
    DB_TIBIAME.Lojas = grupos.iniciante.concat(grupos.intermediario, grupos.alto);

    for (var i = 0; i < DB_TIBIAME.Lojas.length; i++) {
        var l = DB_TIBIAME.Lojas[i];
        for (var j = 0; j < l.itens.length; j++) {
            var itm = l.itens[j];
            itm.loja = l.nome;
            if (itm.dano && itm.dano.length) {   // elemento = lista de elementos do dano (usada na busca)
                var els = [];
                for (var d = 0; d < itm.dano.length; d++) els.push(itm.dano[d][0]);
                itm.elemento = els.join(", ");
            }
        }
    }
})();


// ==========================================
// ITENS (aba Itens e "Itens uteis"): gerados a partir das lojas + itens manuais
// ==========================================
// Itens que NAO estao em loja (drops, quests...) entram aqui. Formato:
// { nome: "Nome", tipo: "Arma" | "Armadura" | "Elmo" | "Calça" | "Escudo" | "Anel" | "Amuleto",
//   level: "30", vocacao: "Guerreiro" | "Mago" | "Guerreiro e Mago",
//   dano: [["Fogo","1-20"]], mana: "5", defesa: [["Físico","10"]], obs: "texto",
//   lojas: [ { loja: "Nome da loja", npc: "NPC", preco: "100 gp" } ] }   // lojas e opcional
// Os mobs/bosses que dropam o item sao encontrados sozinhos pelo nome, lendo o campo "drops" deles.
var ITENS_MANUAIS = [
    // Armas de Mago (fonte: TibiaME4All, conferida com outras fansites). Armas ja existentes no banco foram ignoradas.
    // --- Gelo ---
    {nome: "Fan", tipo: "Arma", level: "21", vocacao: "Mago", dano: [["Gelo", "1-61"]], mana: "6", defesa: []},
    {nome: "(+) Shiver Rune", tipo: "Arma", level: "24", vocacao: "Mago", dano: [["Físico", "1-17"], ["Gelo", "1-72"]], mana: "7", defesa: [], obs: "Versão \"+\" da Shiver Rune."},
    {nome: "Shiver Rune", tipo: "Arma", level: "24", vocacao: "Mago", dano: [["Gelo", "1-72"]], mana: "7", defesa: []},
    {nome: "Freezer Rune", tipo: "Arma", level: "29", vocacao: "Mago", dano: [["Gelo", "1-84"]], mana: "9", defesa: []},
    {nome: "Rune of Winter", tipo: "Arma", level: "34", vocacao: "Mago", dano: [["Gelo", "1-98"]], mana: "9", defesa: []},
    {nome: "Mad Mage's Rod", tipo: "Arma", level: "42", vocacao: "Mago", dano: [["Físico", "1-30"], ["Gelo", "1-125"]], mana: "12", defesa: []},
    {nome: "Tide Evoker", tipo: "Arma", level: "49", vocacao: "Mago", dano: [["Gelo", "1-120"], ["Raio", "1-25"]], mana: "13", defesa: [], obs: "Drop do Aquata."},
    {nome: "Glove of Eternity", tipo: "Arma", level: "69", vocacao: "Mago", dano: [["Gelo", "1-130"]], mana: "17", defesa: [], obs: "Possui mais dois danos (1-25 e 1-40) cujos elementos ainda precisam ser confirmados. Elemento Gelo do dano 1-130 inferido pela categoria da arma."},
    {nome: "Gift of Nivalis", tipo: "Arma", level: "74", vocacao: "Mago", dano: [["Gelo", "18-175"]], mana: "18", defesa: [], obs: "Item de loja premium (mtx)."},
    {nome: "Rod of Eternal Ice", tipo: "Arma", level: "79", vocacao: "Mago", dano: [["Gelo", "19-185"]], mana: "19", defesa: []},
    {nome: "Onset of Winter", tipo: "Arma", level: "99", vocacao: "Mago", dano: [["Gelo", "60-233"]], mana: "23", defesa: []},
    {nome: "Ice Age", tipo: "Arma", level: "119", vocacao: "Mago", dano: [["Gelo", "70-281"]], mana: "28", defesa: []},
    // --- Sagrado ---
    {nome: "Great Soul Rune", tipo: "Arma", level: "19", vocacao: "Mago", dano: [["Sagrado", "1-58"]], mana: "6", defesa: []},
    {nome: "Sacred Discus", tipo: "Arma", level: "23", vocacao: "Mago", dano: [["Sagrado", "1-70"]], mana: "7", defesa: []},
    {nome: "Focus Staff", tipo: "Arma", level: "27", vocacao: "Mago", dano: [["Sagrado", "1-83"]], mana: "8", defesa: []},
    {nome: "Soul Rod", tipo: "Arma", level: "31", vocacao: "Mago", dano: [["Sagrado", "1-90"]], mana: "9", defesa: [], obs: "Drop do Banthera."},
    {nome: "(+) Holy Discus", tipo: "Arma", level: "34", vocacao: "Mago", dano: [["Sagrado", "1-106"]], mana: "8", defesa: [], obs: "Versão \"+\" da Holy Discus."},
    {nome: "Holy Discus", tipo: "Arma", level: "37", vocacao: "Mago", dano: [["Sagrado", "1-106"]], mana: "10", defesa: [], obs: "Pode ser a mesma arma da Soul Discus (nome diferente entre fontes); conferir."},
    {nome: "Blessed Greatstaff", tipo: "Arma", level: "48", vocacao: "Mago", dano: [["Sagrado", "142"]], mana: "14", defesa: []},
    {nome: "Elder Staff", tipo: "Arma", level: "50", vocacao: "Mago", dano: [["Sagrado", "25-126"]], mana: "13", defesa: []},
    {nome: "(+) Spirit Wand", tipo: "Arma", level: "52", vocacao: "Mago", dano: [["Físico", "1-5"], ["Sagrado", "1-150"]], mana: "12", defesa: [], obs: "Versão \"+\" da Spirit Wand."},
    {nome: "Spirit Wand", tipo: "Arma", level: "54", vocacao: "Mago", dano: [["Físico", "1-5"], ["Sagrado", "1-150"]], mana: "14", defesa: []},
    {nome: "Curse of Ashmor", tipo: "Arma", level: "74", vocacao: "Mago", dano: [["Sagrado", "18-175"]], mana: "18", defesa: [], obs: "Item de loja premium (mtx)."},
    {nome: "Divine Twinstaff", tipo: "Arma", level: "79", vocacao: "Mago", dano: [["Sagrado", "19-185"]], mana: "19", defesa: []},
    {nome: "Soulkeeper", tipo: "Arma", level: "99", vocacao: "Mago", dano: [["Sagrado", "60-233"]], mana: "23", defesa: []},
    {nome: "Scepter of Damn", tipo: "Arma", level: "111", vocacao: "Mago", dano: [["Sagrado", "75-215"]], mana: "25", defesa: [], obs: "Possui um segundo dano de 4-34 cujo elemento ainda precisa ser confirmado."},
    {nome: "Bonecaster", tipo: "Arma", level: "119", vocacao: "Mago", dano: [["Sagrado", "70-281"]], mana: "28", defesa: []},
    // --- Físico ---
    {nome: "Battle Rune", tipo: "Arma", level: "0", vocacao: "Mago", dano: [["Físico", "1-10"]], mana: "1", defesa: []},
    {nome: "Shuriken", tipo: "Arma", level: "14", vocacao: "Mago", dano: [["Físico", "1-28"], ["Raio", "1-20"]], mana: "5", defesa: []},
    {nome: "Rhythm Stick", tipo: "Arma", level: "24", vocacao: "Mago", dano: [["Físico", "1-72"]], mana: "6", defesa: []},
    {nome: "Sai", tipo: "Arma", level: "26", vocacao: "Mago", dano: [["Físico", "1-80"]], mana: "8", defesa: []},
    {nome: "Ornate Battle Stick", tipo: "Arma", level: "30", vocacao: "Mago", dano: [["Físico", "1-92"]], mana: "9", defesa: []},
    {nome: "Thiarakatana", tipo: "Arma", level: "33", vocacao: "Mago", dano: [["Físico", "7-97"]], mana: "9", defesa: []},
    {nome: "(+) Ceremonial Rod", tipo: "Arma", level: "38", vocacao: "Mago", dano: [["Físico", "1-105"], ["Sagrado", "1-25"]], mana: "10", defesa: [], obs: "Versão \"+\" da Ceremonial Rod."},
    {nome: "Branch of Oakvine", tipo: "Arma", level: "44", vocacao: "Mago", dano: [["Físico", "1-133"]], mana: "13", defesa: []},
    {nome: "Crushing Staff", tipo: "Arma", level: "48", vocacao: "Mago", dano: [["Físico", "17-128"]], mana: "12", defesa: []},
    {nome: "Archmage Staff", tipo: "Arma", level: "51", vocacao: "Mago", dano: [["Físico", "16-152"]], mana: "12", defesa: []},
    {nome: "Voodoo Doll", tipo: "Arma", level: "57", vocacao: "Mago", dano: [["Físico", "1-150"]], mana: "16", defesa: [], obs: "Possui um segundo dano de 1-25 cujo elemento ainda precisa ser confirmado. Nivel 57 segundo a TibiaME4All; nao confundir com o item \"Voodoo Doll / Wand\" (nivel 29) ja cadastrado."},
    {nome: "Staff of Fury", tipo: "Arma", level: "74", vocacao: "Mago", dano: [["Físico", "18-175"]], mana: "18", defesa: [], obs: "Item de loja premium (mtx)."},
    {nome: "Leveller", tipo: "Arma", level: "79", vocacao: "Mago", dano: [["Físico", "19-185"]], mana: "19", defesa: []},
    {nome: "Staff of Pain", tipo: "Arma", level: "99", vocacao: "Mago", dano: [["Físico", "60-233"]], mana: "23", defesa: []},
    {nome: "Claw of Doom", tipo: "Arma", level: "119", vocacao: "Mago", dano: [["Físico", "70-281"]], mana: "28", defesa: []},
    // --- Fogo ---
    {nome: "Branding Stamp", tipo: "Arma", level: "12", vocacao: "Mago", dano: [["Físico", "1-20"], ["Fogo", "1-20"]], mana: "3", defesa: [], obs: "Drop do Restless."},
    {nome: "(+) Fire Discus", tipo: "Arma", level: "25", vocacao: "Mago", dano: [["Fogo", "1-77"]], mana: "8", defesa: [], obs: "Versão \"+\" da Fire Discus."},
    {nome: "Ember Rune", tipo: "Arma", level: "36", vocacao: "Mago", dano: [["Fogo", "1-100"]], mana: "9", defesa: [], obs: "Drop do Sheriff."},
    {nome: "Splatter Stick", tipo: "Arma", level: "43", vocacao: "Mago", dano: [["Fogo", "1-127"]], mana: "12", defesa: []},
    {nome: "Fire Bo", tipo: "Arma", level: "47", vocacao: "Mago", dano: [["Fogo", "10-105"]], mana: "14", defesa: [], obs: "Possui um segundo dano de 1-40 cujo elemento ainda precisa ser confirmado."},
    {nome: "Scepter of Fire", tipo: "Arma", level: "74", vocacao: "Mago", dano: [["Fogo", "35-135"]], mana: "18", defesa: [], obs: "Possui um segundo dano de 10-25 cujo elemento ainda precisa ser confirmado."},
    {nome: "Ruby Staff", tipo: "Arma", level: "74", vocacao: "Mago", dano: [["Fogo", "18-175"]], mana: "18", defesa: []},
    {nome: "Demonic Essence", tipo: "Arma", level: "79", vocacao: "Mago", dano: [["Fogo", "19-185"]], mana: "19", defesa: []},
    {nome: "Shagdurn", tipo: "Arma", level: "79", vocacao: "Mago", dano: [["Fogo", "19-185"]], mana: "19", defesa: []},
    {nome: "(+) Shagdurn", tipo: "Arma", level: "79", vocacao: "Mago", dano: [["Fogo", "22-202"]], mana: "19", defesa: [], obs: "Versão \"+\" da Shagdurn."},
    {nome: "Conflagrator", tipo: "Arma", level: "99", vocacao: "Mago", dano: [["Fogo", "60-233"]], mana: "23", defesa: []},
    {nome: "Solar Flare", tipo: "Arma", level: "119", vocacao: "Mago", dano: [["Fogo", "70-281"]], mana: "28", defesa: []},
    // --- Raio ---
    {nome: "(+) Spark Stick", tipo: "Arma", level: "9", vocacao: "Mago", dano: [["Raio", "1-32"]], mana: "3", defesa: [], obs: "Versão \"+\" da Spark Stick."},
    {nome: "Lightning Rune", tipo: "Arma", level: "25", vocacao: "Mago", dano: [["Raio", "1-74"]], mana: "7", defesa: []},
    {nome: "Sparking Plug", tipo: "Arma", level: "29", vocacao: "Mago", dano: [["Raio", "1-89"]], mana: "9", defesa: []},
    {nome: "Tempest Rod", tipo: "Arma", level: "44", vocacao: "Mago", dano: [["Físico", "1-5"], ["Raio", "1-150"]], mana: "14", defesa: []},
    {nome: "Eye of Cyclone", tipo: "Arma", level: "50", vocacao: "Mago", dano: [["Raio", "1-148"]], mana: "14", defesa: []},
    {nome: "Lightbringer", tipo: "Arma", level: "59", vocacao: "Mago", dano: [["Raio", "1-130"], ["Fogo", "1-30"], ["Sagrado", "1-20"]], mana: "16", defesa: []},
    {nome: "Storm Singer", tipo: "Arma", level: "74", vocacao: "Mago", dano: [["Raio", "18-175"]], mana: "18", defesa: [], obs: "Item de loja premium (mtx)."},
    {nome: "Earthshaker", tipo: "Arma", level: "79", vocacao: "Mago", dano: [["Raio", "19-185"]], mana: "19", defesa: []},
    {nome: "Lightning Conductor", tipo: "Arma", level: "99", vocacao: "Mago", dano: [["Raio", "60-233"]], mana: "23", defesa: []},
    {nome: "Raging Thunder", tipo: "Arma", level: "119", vocacao: "Mago", dano: [["Raio", "70-281"]], mana: "28", defesa: []},
    // --- Nivel 149 (Eldar) ---
    {nome: "Agonizer", tipo: "Arma", level: "149", vocacao: "Mago", dano: [["Físico", "131-596"]], mana: "42", defesa: [], obs: "Forjada pelo ferreiro Eldar (Solahmar) apos a quest de Gorgoros. Dura 9.999 usos. Dano 131-596 segundo a maioria das fontes (uma fonte lista 436-727). Receita: 5 Stone Idol, 5 Celestial Fire, 3 Medusa's Heart e 7 Heavy Ore.", lojas: [{"loja": "Gorgoros", "npc": "Eldar", "preco": "A definir"}]},
    {nome: "Eternal Flame", tipo: "Arma", level: "149", vocacao: "Mago", dano: [["Fogo", "131-596"]], mana: "42", defesa: [], obs: "Forjada pelo ferreiro Eldar (Solahmar) apos a quest de Gorgoros. Dura 9.999 usos. Dano 131-596 segundo a maioria das fontes (uma fonte lista 436-727). Receita: 5 Stone Idol, 5 Celestial Fire, 3 Medusa's Heart e 7 Blazing Ore.", lojas: [{"loja": "Gorgoros", "npc": "Eldar", "preco": "A definir"}]},
    {nome: "Elmsfire", tipo: "Arma", level: "149", vocacao: "Mago", dano: [["Raio", "131-596"]], mana: "42", defesa: [], obs: "Forjada pelo ferreiro Eldar (Solahmar) apos a quest de Gorgoros. Dura 9.999 usos. Dano 131-596 segundo a maioria das fontes (uma fonte lista 436-727). Receita: 5 Stone Idol, 5 Celestial Fire, 3 Medusa's Heart e 7 Storming Ore.", lojas: [{"loja": "Gorgoros", "npc": "Eldar", "preco": "A definir"}]},
    {nome: "Everfrost", tipo: "Arma", level: "149", vocacao: "Mago", dano: [["Gelo", "131-596"]], mana: "42", defesa: [], obs: "Forjada pelo ferreiro Eldar (Solahmar) apos a quest de Gorgoros. Dura 9.999 usos. Dano 131-596 segundo a maioria das fontes (uma fonte lista 436-727). Receita a confirmar.", lojas: [{"loja": "Gorgoros", "npc": "Eldar", "preco": "A definir"}]},
    {nome: "Interceptor", tipo: "Arma", level: "149", vocacao: "Mago", dano: [["Sagrado", "131-596"]], mana: "42", defesa: [], obs: "Forjada pelo ferreiro Eldar (Solahmar) apos a quest de Gorgoros. Dura 9.999 usos. Dano 131-596 segundo a maioria das fontes (uma fonte lista 436-727). Receita a confirmar.", lojas: [{"loja": "Gorgoros", "npc": "Eldar", "preco": "A definir"}]},
    // Armas de Guerreiro (fonte: TibiaME4All; as que ela nao lista vieram da fansite Hexat). Armas ja existentes no banco foram ignoradas.
    // --- Físico ---
    {nome: "Nunchaku", tipo: "Arma", level: "14", vocacao: "Guerreiro", dano: [["Físico", "2-23"], ["Gelo", "1-10"]], mana: "", defesa: []},
    {nome: "Tiharakatana", tipo: "Arma", level: "33", vocacao: "Guerreiro", dano: [["Físico", "4-76"]], mana: "", defesa: []},
    {nome: "(+) Hallowed Sword", tipo: "Arma", level: "38", vocacao: "Guerreiro", dano: [["Físico", "1-80"], ["Sagrado", "1-17"]], mana: "", defesa: [], obs: "Versão \"+\" da Hallowed Sword."},
    {nome: "Hallowed Sword", tipo: "Arma", level: "38", vocacao: "Guerreiro", dano: [["Físico", "1-70"], ["Sagrado", "1-15"]], mana: "", defesa: []},
    {nome: "Sabre", tipo: "Arma", level: "42", vocacao: "Guerreiro", dano: [["Físico", "1-85"], ["Fogo", "1-10"]], mana: "", defesa: []},
    {nome: "Desert Fire", tipo: "Arma", level: "48", vocacao: "Guerreiro", dano: [["Físico", "11-61"], ["Fogo", "11-33"]], mana: "", defesa: []},
    {nome: "Voodoo Needle", tipo: "Arma", level: "57", vocacao: "Guerreiro", dano: [["Físico", "1-120"], ["Sagrado", "1-14"]], mana: "", defesa: []},
    {nome: "Tomahawk", tipo: "Arma", level: "61", vocacao: "Guerreiro", dano: [["Físico", "10-131"]], mana: "", defesa: []},
    {nome: "Destroyer", tipo: "Arma", level: "74", vocacao: "Guerreiro", dano: [["Físico", "14-161"]], mana: "", defesa: [], obs: "Item de loja premium (mtx)."},
    {nome: "Malmer", tipo: "Arma", level: "79", vocacao: "Guerreiro", dano: [["Físico", "35-120"], ["Raio", "5-20"], ["Sagrado", "1-5"]], mana: "", defesa: []},
    {nome: "Brute Force", tipo: "Arma", level: "79", vocacao: "Guerreiro", dano: [["Físico", "15-170"]], mana: "", defesa: []},
    {nome: "Twinaxe", tipo: "Arma", level: "94", vocacao: "Guerreiro", dano: [["Físico", "19-195"]], mana: "", defesa: []},
    {nome: "Mutilator", tipo: "Arma", level: "99", vocacao: "Guerreiro", dano: [["Físico", "20-205"]], mana: "", defesa: []},
    {nome: "Reapers Claw", tipo: "Arma", level: "119", vocacao: "Guerreiro", dano: [["Físico", "45-225"]], mana: "", defesa: []},
    // --- Fogo ---
    {nome: "(+) Fire Sword", tipo: "Arma", level: "25", vocacao: "Guerreiro", dano: [["Fogo", "1-59"]], mana: "", defesa: [], obs: "Versão \"+\" da Fire Sword."},
    {nome: "Troll Cleaver", tipo: "Arma", level: "29", vocacao: "Guerreiro", dano: [["Físico", "1-15"], ["Fogo", "1-50"]], mana: "", defesa: []},
    {nome: "Burning Blade", tipo: "Arma", level: "33", vocacao: "Guerreiro", dano: [["Fogo", "4-74"]], mana: "", defesa: []},
    {nome: "Volcanic Axe", tipo: "Arma", level: "37", vocacao: "Guerreiro", dano: [["Físico", "1-20"], ["Fogo", "1-65"]], mana: "", defesa: []},
    {nome: "Fugazor", tipo: "Arma", level: "42", vocacao: "Guerreiro", dano: [["Fogo", "1-97"]], mana: "", defesa: []},
    {nome: "Magma Mace", tipo: "Arma", level: "49", vocacao: "Guerreiro", dano: [["Físico", "1-25"], ["Fogo", "1-85"]], mana: "", defesa: []},
    {nome: "Magma Axe", tipo: "Arma", level: "74", vocacao: "Guerreiro", dano: [["Físico", "1-35"], ["Fogo", "25-100"]], mana: "", defesa: [], obs: "Dano Físico 1-35 segundo a TibiaME4All (a Hexat lista 10-35)."},
    {nome: "Meteor Mace", tipo: "Arma", level: "74", vocacao: "Guerreiro", dano: [["Fogo", "14-161"]], mana: "", defesa: [], obs: "Item de loja premium (mtx)."},
    {nome: "Hammer of Kha'zur", tipo: "Arma", level: "79", vocacao: "Guerreiro", dano: [["Fogo", "15-170"]], mana: "", defesa: []},
    {nome: "Dul'mar", tipo: "Arma", level: "79", vocacao: "Guerreiro", dano: [["Fogo", "15-170"]], mana: "", defesa: []},
    {nome: "(+) Dul'mar", tipo: "Arma", level: "79", vocacao: "Guerreiro", dano: [["Fogo", "20-184"]], mana: "", defesa: [], obs: "Versão \"+\" da Dul'mar. Bônus de +5% de EP."},
    {nome: "Blaze Hammer", tipo: "Arma", level: "94", vocacao: "Guerreiro", dano: [["Fogo", "19-195"]], mana: "", defesa: []},
    {nome: "Fiery Nexus", tipo: "Arma", level: "99", vocacao: "Guerreiro", dano: [["Fogo", "20-199"]], mana: "", defesa: [], obs: "Dano 20-199 segundo a TibiaME4All (a Hexat lista 20-205)."},
    {nome: "Searing Inferno", tipo: "Arma", level: "119", vocacao: "Guerreiro", dano: [["Fogo", "45-225"]], mana: "", defesa: []},
    // --- Gelo ---
    {nome: "Frozarium", tipo: "Arma", level: "20", vocacao: "Guerreiro", dano: [["Gelo", "1-36"]], mana: "", defesa: []},
    {nome: "Arctic Spike", tipo: "Arma", level: "24", vocacao: "Guerreiro", dano: [["Físico", "1-5"], ["Gelo", "1-50"]], mana: "", defesa: []},
    {nome: "(+) Arctic Spike", tipo: "Arma", level: "24", vocacao: "Guerreiro", dano: [["Físico", "1-15"], ["Gelo", "1-50"]], mana: "", defesa: [], obs: "Versão \"+\" da Arctic Spike."},
    {nome: "Ice Spiked Mace", tipo: "Arma", level: "30", vocacao: "Guerreiro", dano: [["Gelo", "1-66"]], mana: "", defesa: [], obs: "Level 30 segundo a TibiaME4All (a Hexat lista 28)."},
    {nome: "Frostbringer", tipo: "Arma", level: "31", vocacao: "Guerreiro", dano: [["Gelo", "1-65"]], mana: "", defesa: []},
    {nome: "Dragon Slayer", tipo: "Arma", level: "35", vocacao: "Guerreiro", dano: [["Gelo", "1-75"]], mana: "", defesa: []},
    {nome: "Frost Smasher", tipo: "Arma", level: "47", vocacao: "Guerreiro", dano: [["Gelo", "1-108"]], mana: "", defesa: []},
    {nome: "Hammer of Nivalis", tipo: "Arma", level: "51", vocacao: "Guerreiro", dano: [["Gelo", "11-111"]], mana: "", defesa: []},
    {nome: "Sword of Legend", tipo: "Arma", level: "69", vocacao: "Guerreiro", dano: [["Físico", "1-20"], ["Sagrado", "1-20"], ["Gelo", "15-100"]], mana: "", defesa: []},
    {nome: "Eternal Winter", tipo: "Arma", level: "74", vocacao: "Guerreiro", dano: [["Gelo", "14-161"]], mana: "", defesa: [], obs: "Item de loja premium (mtx)."},
    {nome: "Subzero", tipo: "Arma", level: "79", vocacao: "Guerreiro", dano: [["Gelo", "15-170"]], mana: "", defesa: []},
    {nome: "Frost Slicer", tipo: "Arma", level: "94", vocacao: "Guerreiro", dano: [["Gelo", "19-195"]], mana: "", defesa: []},
    {nome: "Crystal Cutter", tipo: "Arma", level: "99", vocacao: "Guerreiro", dano: [["Gelo", "20-205"]], mana: "", defesa: []},
    {nome: "Deep Freeze", tipo: "Arma", level: "119", vocacao: "Guerreiro", dano: [["Gelo", "45-225"]], mana: "", defesa: []},
    // --- Raio ---
    {nome: "(+) Flash Hacker", tipo: "Arma", level: "10", vocacao: "Guerreiro", dano: [["Físico", "1-13"], ["Raio", "1-17"]], mana: "", defesa: [], obs: "Versão \"+\" da Flash Hacker."},
    {nome: "Skylighter", tipo: "Arma", level: "15", vocacao: "Guerreiro", dano: [["Raio", "1-34"]], mana: "", defesa: []},
    {nome: "Shock Halberd", tipo: "Arma", level: "21", vocacao: "Guerreiro", dano: [["Físico", "1-10"], ["Raio", "1-38"]], mana: "", defesa: []},
    {nome: "Thunder Hammer", tipo: "Arma", level: "25", vocacao: "Guerreiro", dano: [["Raio", "1-50"]], mana: "", defesa: []},
    {nome: "Comet Sword", tipo: "Arma", level: "44", vocacao: "Guerreiro", dano: [["Físico", "1-20"], ["Raio", "1-80"]], mana: "", defesa: []},
    {nome: "Edge of Storm", tipo: "Arma", level: "49", vocacao: "Guerreiro", dano: [["Raio", "1-113"]], mana: "", defesa: []},
    {nome: "Thunder Hook", tipo: "Arma", level: "52", vocacao: "Guerreiro", dano: [["Físico", "5-40"], ["Raio", "1-75"]], mana: "", defesa: []},
    {nome: "Lightbender", tipo: "Arma", level: "59", vocacao: "Guerreiro", dano: [["Fogo", "1-30"], ["Sagrado", "1-15"], ["Raio", "1-95"]], mana: "", defesa: []},
    {nome: "Lightning Fang", tipo: "Arma", level: "74", vocacao: "Guerreiro", dano: [["Raio", "14-161"]], mana: "", defesa: [], obs: "Item de loja premium (mtx)."},
    {nome: "Claw of Chilong", tipo: "Arma", level: "79", vocacao: "Guerreiro", dano: [["Raio", "15-170"]], mana: "", defesa: []},
    {nome: "Demon Slayer", tipo: "Arma", level: "94", vocacao: "Guerreiro", dano: [["Raio", "19-195"]], mana: "", defesa: []},
    {nome: "Thunder Clap Mace", tipo: "Arma", level: "99", vocacao: "Guerreiro", dano: [["Raio", "20-205"]], mana: "", defesa: []},
    {nome: "Tempest Blade", tipo: "Arma", level: "119", vocacao: "Guerreiro", dano: [["Raio", "45-225"]], mana: "", defesa: []},
    {nome: "Archon Blade", tipo: "Arma", level: "139", vocacao: "Guerreiro", dano: [["Raio", "81-319"]], mana: "", defesa: []},
    {nome: "(+) Archon Blade", tipo: "Arma", level: "144", vocacao: "Guerreiro", dano: [["Raio", "81-339"]], mana: "", defesa: [], obs: "Versão \"+\" da Archon Blade. Bônus de +10% de EP e +10% de ouro."},
    {nome: "Trident of the Seas", tipo: "Arma", level: "159", vocacao: "Guerreiro", dano: [["Raio", "152-388"]], mana: "", defesa: []},
    // --- Sagrado ---
    {nome: "Truesilver Mace", tipo: "Arma", level: "19", vocacao: "Guerreiro", dano: [["Sagrado", "1-44"]], mana: "", defesa: []},
    {nome: "Blessed Hammer", tipo: "Arma", level: "20", vocacao: "Guerreiro", dano: [["Físico", "1-10"], ["Sagrado", "1-35"]], mana: "", defesa: []},
    {nome: "Gurumistick", tipo: "Arma", level: "20", vocacao: "Guerreiro", dano: [["Sagrado", "1-36"]], mana: "", defesa: []},
    {nome: "Club of Remorse", tipo: "Arma", level: "23", vocacao: "Guerreiro", dano: [["Sagrado", "1-50"]], mana: "", defesa: []},
    {nome: "(+) Holy Lance", tipo: "Arma", level: "24", vocacao: "Guerreiro", dano: [["Físico", "1-12"], ["Sagrado", "1-70"]], mana: "", defesa: [], obs: "Versão \"+\" da Holy Lance. Level 24 segundo a TibiaME4All (a Hexat lista 33)."},
    {nome: "Paladin's Axe", tipo: "Arma", level: "27", vocacao: "Guerreiro", dano: [["Físico", "1-12"], ["Sagrado", "1-50"]], mana: "", defesa: []},
    {nome: "Mind Crusher", tipo: "Arma", level: "30", vocacao: "Guerreiro", dano: [["Sagrado", "4-67"]], mana: "", defesa: []},
    {nome: "Cutting Leafes", tipo: "Arma", level: "44", vocacao: "Guerreiro", dano: [["Sagrado", "1-102"]], mana: "", defesa: []},
    {nome: "Soulcleaver", tipo: "Arma", level: "50", vocacao: "Guerreiro", dano: [["Físico", "12-26"], ["Sagrado", "10-70"]], mana: "", defesa: []},
    {nome: "Soul Eater", tipo: "Arma", level: "51", vocacao: "Guerreiro", dano: [["Sagrado", "11-122"]], mana: "", defesa: []},
    {nome: "Spirit Blade", tipo: "Arma", level: "54", vocacao: "Guerreiro", dano: [["Físico", "1-35"], ["Sagrado", "1-85"]], mana: "", defesa: []},
    {nome: "(+) Spirit Blade", tipo: "Arma", level: "54", vocacao: "Guerreiro", dano: [["Físico", "1-35"], ["Sagrado", "1-100"]], mana: "", defesa: [], obs: "Versão \"+\" da Spirit Blade."},
    {nome: "Axe of Belief", tipo: "Arma", level: "64", vocacao: "Guerreiro", dano: [["Físico", "1-35"], ["Sagrado", "1-110"]], mana: "", defesa: []},
    {nome: "Voidcutter", tipo: "Arma", level: "74", vocacao: "Guerreiro", dano: [["Sagrado", "14-161"]], mana: "", defesa: [], obs: "Item de loja premium (mtx)."},
    {nome: "Divine Twinblade", tipo: "Arma", level: "79", vocacao: "Guerreiro", dano: [["Sagrado", "15-170"]], mana: "", defesa: []},
    {nome: "Dragonbone Spear", tipo: "Arma", level: "94", vocacao: "Guerreiro", dano: [["Sagrado", "19-195"]], mana: "", defesa: []},
    {nome: "Spiritbane", tipo: "Arma", level: "99", vocacao: "Guerreiro", dano: [["Sagrado", "20-205"]], mana: "", defesa: []},
    {nome: "Claymore of Doom", tipo: "Arma", level: "111", vocacao: "Guerreiro", dano: [["Físico", "2-20"], ["Sagrado", "70-160"]], mana: "", defesa: []},
    {nome: "Devourer of Souls", tipo: "Arma", level: "119", vocacao: "Guerreiro", dano: [["Sagrado", "45-225"]], mana: "", defesa: []},
    // --- Mistas (nível 129) ---
    {nome: "Purificator", tipo: "Arma", level: "129", vocacao: "Guerreiro", dano: [["Raio", "25-223"], ["Sagrado", "25-223"]], mana: "", defesa: []},
    {nome: "Reaper of Worlds", tipo: "Arma", level: "129", vocacao: "Guerreiro", dano: [["Fogo", "25-223"], ["Gelo", "25-223"]], mana: "", defesa: []},
    {nome: "(+) Reaper of Worlds", tipo: "Arma", level: "129", vocacao: "Guerreiro", dano: [["Fogo", "25-223"], ["Gelo", "25-223"]], mana: "", defesa: [], obs: "Versão \"+\" da Reaper of Worlds. Bônus de +5% de EP."},
    {nome: "Skull Crusher", tipo: "Arma", level: "129", vocacao: "Guerreiro", dano: [["Físico", "25-211"], ["Fogo", "5-125"], ["Gelo", "5-125"]], mana: "", defesa: []},
    {nome: "(+) Skull Crusher", tipo: "Arma", level: "129", vocacao: "Guerreiro", dano: [["Físico", "25-211"], ["Fogo", "5-125"], ["Gelo", "5-125"]], mana: "", defesa: [], obs: "Versão \"+\" da Skull Crusher. Bônus de +5% de EP."},
    // --- Nivel 149 (Eldar) ---
    {nome: "Skullcleaver", tipo: "Arma", level: "149", vocacao: "Guerreiro", dano: [["Físico", "101-469"]], mana: "", defesa: [], obs: "Forjada pelo ferreiro Eldar (Solahmar) apos a quest de Gorgoros. Dura 9.999 usos.", lojas: [{"loja": "Gorgoros", "npc": "Eldar", "preco": "A definir"}]},
    {nome: "Hellblade", tipo: "Arma", level: "149", vocacao: "Guerreiro", dano: [["Fogo", "101-469"]], mana: "", defesa: [], obs: "Forjada pelo ferreiro Eldar (Solahmar) apos a quest de Gorgoros. Dura 9.999 usos.", lojas: [{"loja": "Gorgoros", "npc": "Eldar", "preco": "A definir"}]},
    {nome: "Glaciator", tipo: "Arma", level: "149", vocacao: "Guerreiro", dano: [["Gelo", "101-469"]], mana: "", defesa: [], obs: "Forjada pelo ferreiro Eldar (Solahmar) apos a quest de Gorgoros. Dura 9.999 usos.", lojas: [{"loja": "Gorgoros", "npc": "Eldar", "preco": "A definir"}]},
    {nome: "Thunderstorm", tipo: "Arma", level: "149", vocacao: "Guerreiro", dano: [["Raio", "101-469"]], mana: "", defesa: [], obs: "Forjada pelo ferreiro Eldar (Solahmar) apos a quest de Gorgoros. Dura 9.999 usos.", lojas: [{"loja": "Gorgoros", "npc": "Eldar", "preco": "A definir"}]},
    {nome: "Spiritslayer", tipo: "Arma", level: "149", vocacao: "Guerreiro", dano: [["Sagrado", "101-469"]], mana: "", defesa: [], obs: "Forjada pelo ferreiro Eldar (Solahmar) apos a quest de Gorgoros. Dura 9.999 usos.", lojas: [{"loja": "Gorgoros", "npc": "Eldar", "preco": "A definir"}]},
    // --- Armas adicionais de Guerreiro (fonte: tibiame.ru). O dano abaixo segue a faixa exibida no tibiame.ru, que usa outro formato de faixa que o TibiaME4All;
    //     onde conseguir cada arma ainda precisa ser confirmado. ---
    // --- Reliquias (niveis 39, 49 e 89) e variante (+) ---
    {nome: "Powerless Relic", tipo: "Arma", level: "39", vocacao: "Guerreiro", dano: [["Físico", "38-64"]], mana: "", defesa: [], obs: "Relíquia de guerreiro. Dano conforme tibiame.ru. Onde obter: a confirmar."},
    {nome: "(+) Battle Axe", tipo: "Arma", level: "30", vocacao: "Guerreiro", dano: [["Físico", "43-71"]], mana: "", defesa: [], obs: "Versão \"+\" da Battle Axe. Dano conforme tibiame.ru. Onde obter: a confirmar."},
    {nome: "Ancient Relic", tipo: "Arma", level: "49", vocacao: "Guerreiro", dano: [["Físico", "68-114"]], mana: "", defesa: [], obs: "Relíquia de guerreiro. Dano conforme tibiame.ru. Onde obter: a confirmar."},
    {nome: "Awakend Relic", tipo: "Arma", level: "89", vocacao: "Guerreiro", dano: [["Gelo", "122-203"]], mana: "", defesa: [], obs: "Relíquia de guerreiro (nome grafado como no tibiame.ru). Dano conforme tibiame.ru. Onde obter: a confirmar."},
    // --- Linha -tar (nivel 109) ---
    {nome: "Fa'run'tar", tipo: "Arma", level: "109", vocacao: "Guerreiro", dano: [["Físico", "149-248"]], mana: "", defesa: [], obs: "Arma de guerreiro nível 109 da linha \"-tar\". Dano conforme tibiame.ru. Onde obter: a confirmar."},
    {nome: "Sol'fi'tar", tipo: "Arma", level: "109", vocacao: "Guerreiro", dano: [["Fogo", "149-248"]], mana: "", defesa: [], obs: "Arma de guerreiro nível 109 da linha \"-tar\". Dano conforme tibiame.ru. Onde obter: a confirmar."},
    {nome: "Nil'fan'tar", tipo: "Arma", level: "109", vocacao: "Guerreiro", dano: [["Gelo", "149-248"]], mana: "", defesa: [], obs: "Arma de guerreiro nível 109 da linha \"-tar\". Dano conforme tibiame.ru. Onde obter: a confirmar."},
    {nome: "Sum'ato'tar", tipo: "Arma", level: "109", vocacao: "Guerreiro", dano: [["Raio", "149-248"]], mana: "", defesa: [], obs: "Arma de guerreiro nível 109 da linha \"-tar\". Dano conforme tibiame.ru. Onde obter: a confirmar."},
    {nome: "Xel'no'tar", tipo: "Arma", level: "109", vocacao: "Guerreiro", dano: [["Sagrado", "149-248"]], mana: "", defesa: [], obs: "Arma de guerreiro nível 109 da linha \"-tar\". Dano conforme tibiame.ru. Onde obter: a confirmar."},
    // --- Linha -tar, versao (+) (nivel 139) ---
    {nome: "(+) Fa'run'tar", tipo: "Arma", level: "139", vocacao: "Guerreiro", dano: [["Físico", "189-315"]], mana: "", defesa: [], obs: "Versão \"+\" da Fa'run'tar (nível 139). Dano conforme tibiame.ru. Onde obter: a confirmar."},
    {nome: "(+) Sol'fi'tar", tipo: "Arma", level: "139", vocacao: "Guerreiro", dano: [["Fogo", "189-315"]], mana: "", defesa: [], obs: "Versão \"+\" da Sol'fi'tar (nível 139). Dano conforme tibiame.ru. Onde obter: a confirmar."},
    {nome: "(+) Nil'fan'tar", tipo: "Arma", level: "139", vocacao: "Guerreiro", dano: [["Gelo", "189-315"]], mana: "", defesa: [], obs: "Versão \"+\" da Nil'fan'tar (nível 139). Dano conforme tibiame.ru. Onde obter: a confirmar."},
    {nome: "(+) Sum'ato'tar", tipo: "Arma", level: "139", vocacao: "Guerreiro", dano: [["Raio", "189-315"]], mana: "", defesa: [], obs: "Versão \"+\" da Sum'ato'tar (nível 139). Dano conforme tibiame.ru. Onde obter: a confirmar."},
    {nome: "(+) Xel'no'tar", tipo: "Arma", level: "139", vocacao: "Guerreiro", dano: [["Sagrado", "189-315"]], mana: "", defesa: [], obs: "Versão \"+\" da Xel'no'tar (nível 139). Dano conforme tibiame.ru. Onde obter: a confirmar."},
    // --- Topo da linha (nivel 199) ---
    {nome: "Fa'run", tipo: "Arma", level: "199", vocacao: "Guerreiro", dano: [["Físico", "310-517"]], mana: "", defesa: [], obs: "Arma de guerreiro nível 199. Dano conforme tibiame.ru. Onde obter: a confirmar."},
    {nome: "Sol'fi", tipo: "Arma", level: "199", vocacao: "Guerreiro", dano: [["Fogo", "310-517"]], mana: "", defesa: [], obs: "Arma de guerreiro nível 199. Dano conforme tibiame.ru. Um vídeo de forja indica que ela é feita a partir da Sol'fi'tar, com fragmentos e Union Stone (a confirmar). Onde obter: a confirmar."},
    {nome: "Nil'fan", tipo: "Arma", level: "199", vocacao: "Guerreiro", dano: [["Gelo", "310-517"]], mana: "", defesa: [], obs: "Arma de guerreiro nível 199. Dano conforme tibiame.ru. Onde obter: a confirmar."},
    {nome: "Sum'ato", tipo: "Arma", level: "199", vocacao: "Guerreiro", dano: [["Raio", "310-517"]], mana: "", defesa: [], obs: "Arma de guerreiro nível 199. Dano conforme tibiame.ru. Onde obter: a confirmar."},
    {nome: "Xel'no", tipo: "Arma", level: "199", vocacao: "Guerreiro", dano: [["Sagrado", "310-517"]], mana: "", defesa: [], obs: "Arma de guerreiro nível 199. Dano conforme tibiame.ru. Onde obter: a confirmar."},
    // Armaduras de Mago (fonte: TibiaME4All). Amuletos e aneis valem para Guerreiro e Mago. Pecas ja existentes no banco foram ignoradas.
    // --- Cabeça (Elmo) ---
    {nome: "Light Cap", tipo: "Elmo", level: "1", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "2"]]},
    {nome: "Apprentice Bonnet", tipo: "Elmo", level: "5", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "3"]]},
    {nome: "Night Cap", tipo: "Elmo", level: "13", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "7"]]},
    {nome: "Basting Hood", tipo: "Elmo", level: "19", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "8"]]},
    {nome: "Spellwielder Hat", tipo: "Elmo", level: "25", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "10"]]},
    {nome: "Enlighted Cap", tipo: "Elmo", level: "32", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "12"]]},
    {nome: "Winter Hood", tipo: "Elmo", level: "37", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "13"]]},
    {nome: "Armoured Cap", tipo: "Elmo", level: "44", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "15"]]},
    {nome: "Battlemage Helmet", tipo: "Elmo", level: "50", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "17"]]},
    {nome: "Monter Hood", tipo: "Elmo", level: "54", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "18"]]},
    {nome: "Spellmaster Hood", tipo: "Elmo", level: "59", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "20"]]},
    {nome: "Forcedeflect Dulban", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "27"], ["Sagrado", "13"]]},
    {nome: "(+) Forcedeflect Dulban", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "36"], ["Sagrado", "17"]], obs: "Versão \"+\" de Forcedeflect Dulban."},
    {nome: "(+ fire) Forcedeflect Dulban", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "27"], ["Fogo", "13"], ["Sagrado", "13"]], obs: "Variação \"+ fire\" de Forcedeflect Dulban (troca parte da defesa por Fogo)."},
    {nome: "(+ ice) Forcedeflect Dulban", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "27"], ["Sagrado", "13"], ["Gelo", "13"]], obs: "Variação \"+ ice\" de Forcedeflect Dulban (troca parte da defesa por Gelo)."},
    {nome: "Magma Headpiece", tipo: "Elmo", level: "50", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "7"], ["Fogo", "17"]]},
    {nome: "King's Hood", tipo: "Elmo", level: "71", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "10"], ["Fogo", "25"]]},
    {nome: "Demonic Hood", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Fogo", "27"], ["Sagrado", "13"]]},
    {nome: "(+) Demonic Hood", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Fogo", "36"], ["Sagrado", "17"]], obs: "Versão \"+\" de Demonic Hood."},
    {nome: "(+ hit) Demonic Hood", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "13"], ["Fogo", "27"], ["Sagrado", "13"]], obs: "Variação \"+ hit\" de Demonic Hood (troca parte da defesa por Físico)."},
    {nome: "(+ light) Demonic Hood", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "13"], ["Fogo", "27"], ["Sagrado", "13"]], obs: "Variação \"+ light\" de Demonic Hood (troca parte da defesa por Raio)."},
    {nome: "Fur-lined Cap", tipo: "Elmo", level: "13", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "7"], ["Gelo", "7"]]},
    {nome: "Hood", tipo: "Elmo", level: "25", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "5"], ["Gelo", "10"]]},
    {nome: "Bobble Hat", tipo: "Elmo", level: "44", vocacao: "Mago", dano: [], mana: "", defesa: [["Gelo", "15"]]},
    {nome: "Sailor Cap", tipo: "Elmo", level: "44", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "-10"], ["Sagrado", "15"], ["Gelo", "15"]]},
    {nome: "Coldshadow Hood", tipo: "Elmo", level: "47", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "4"], ["Gelo", "12"]]},
    {nome: "Frost Hood", tipo: "Elmo", level: "62", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "5"], ["Gelo", "22"]]},
    {nome: "Deepfrozen Hood", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "13"], ["Gelo", "27"]]},
    {nome: "(+) Deepfrozen Hood", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "17"], ["Gelo", "36"]], obs: "Versão \"+\" de Deepfrozen Hood."},
    {nome: "(+ light) Deepfrozen Hood", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "13"], ["Raio", "13"], ["Gelo", "27"]], obs: "Variação \"+ light\" de Deepfrozen Hood (troca parte da defesa por Raio)."},
    {nome: "(+ soul) Deepfrozen Hood", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "13"], ["Sagrado", "13"], ["Gelo", "27"]], obs: "Variação \"+ soul\" de Deepfrozen Hood (troca parte da defesa por Sagrado)."},
    {nome: "Faraday Hood", tipo: "Elmo", level: "28", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "9"], ["Raio", "11"]]},
    {nome: "Pirate Headband", tipo: "Elmo", level: "44", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "15"], ["Fogo", "-10"], ["Gelo", "15"]]},
    {nome: "Shaolin Headbelt", tipo: "Elmo", level: "44", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "10"], ["Raio", "15"]]},
    {nome: "Wizard's Hat", tipo: "Elmo", level: "59", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "20"]]},
    {nome: "Plasma Hood", tipo: "Elmo", level: "66", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "23"], ["Fogo", "-5"]]},
    {nome: "To-Maga Hood", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "27"], ["Gelo", "13"]]},
    {nome: "(+) To-maga Hood", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "36"], ["Gelo", "17"]], obs: "Versão \"+\" de To-maga Hood."},
    {nome: "(+ hit) To-maga Hood", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "13"], ["Raio", "27"], ["Gelo", "13"]], obs: "Variação \"+ hit\" de To-maga Hood (troca parte da defesa por Físico)."},
    {nome: "(+ soul) To-maga Hood", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "27"], ["Sagrado", "13"], ["Gelo", "13"]], obs: "Variação \"+ soul\" de To-maga Hood (troca parte da defesa por Sagrado)."},
    {nome: "Splatter Hood", tipo: "Elmo", level: "40", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "5"], ["Sagrado", "14"]]},
    {nome: "Holy Hat", tipo: "Elmo", level: "44", vocacao: "Mago", dano: [], mana: "", defesa: [["Sagrado", "15"]]},
    {nome: "Sanctification Hood", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "13"], ["Sagrado", "27"]]},
    {nome: "(+) Sanctification Hood", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "17"], ["Sagrado", "36"]], obs: "Versão \"+\" de Sanctification Hood."},
    {nome: "(+ fire) Sanctification Hood", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "13"], ["Fogo", "13"], ["Sagrado", "27"]], obs: "Variação \"+ fire\" de Sanctification Hood (troca parte da defesa por Fogo)."},
    {nome: "(+ ice) Sanctification Hood", tipo: "Elmo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "13"], ["Sagrado", "27"], ["Gelo", "13"]], obs: "Variação \"+ ice\" de Sanctification Hood (troca parte da defesa por Gelo)."},
    // --- Torso (Armadura) ---
    {nome: "Basting Shirt", tipo: "Armadura", level: "18", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "13"]]},
    {nome: "(+) Winter Armour", tipo: "Armadura", level: "35", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "25"], ["Gelo", "10"]], obs: "Versão \"+\" de Winter Armour."},
    {nome: "Winter Armour", tipo: "Armadura", level: "35", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "21"], ["Gelo", "8"]]},
    {nome: "Armoured Shirt", tipo: "Armadura", level: "41", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "24"]]},
    {nome: "Battlemage Armour", tipo: "Armadura", level: "47", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "27"]]},
    {nome: "Monter Mantle", tipo: "Armadura", level: "52", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "29"]]},
    {nome: "Spellmaster Robe", tipo: "Armadura", level: "57", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "32"]]},
    {nome: "Forcedeflect Coat", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "43"], ["Sagrado", "21"]]},
    {nome: "(+) Forcedeflect Coat", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "57"], ["Sagrado", "28"]], obs: "Versão \"+\" de Forcedeflect Coat."},
    {nome: "(+ fire) Forcedeflect Coat", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "43"], ["Fogo", "21"], ["Sagrado", "21"]], obs: "Variação \"+ fire\" de Forcedeflect Coat (troca parte da defesa por Fogo)."},
    {nome: "(+ ice) Forcedeflect Coat", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "43"], ["Sagrado", "21"], ["Gelo", "21"]], obs: "Variação \"+ ice\" de Forcedeflect Coat (troca parte da defesa por Gelo)."},
    {nome: "Gown", tipo: "Armadura", level: "22", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "5"], ["Fogo", "15"]]},
    {nome: "Magma Robe", tipo: "Armadura", level: "50", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "11"], ["Fogo", "28"]]},
    {nome: "King's Cloak", tipo: "Armadura", level: "51", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "10"], ["Fogo", "30"]]},
    {nome: "Demonic Cloak", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Fogo", "43"], ["Sagrado", "21"]]},
    {nome: "(+) Demonic Cloak", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Fogo", "57"], ["Sagrado", "28"]], obs: "Versão \"+\" de Demonic Cloak."},
    {nome: "(+ hit) Demonic Cloak", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "21"], ["Fogo", "43"], ["Sagrado", "21"]], obs: "Variação \"+ hit\" de Demonic Cloak (troca parte da defesa por Físico)."},
    {nome: "(+ light) Demonic Cloak", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "21"], ["Fogo", "43"], ["Sagrado", "21"]], obs: "Variação \"+ light\" de Demonic Cloak (troca parte da defesa por Raio)."},
    {nome: "Cloak", tipo: "Armadura", level: "22", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "5"], ["Gelo", "15"]]},
    {nome: "Sailor Jacket", tipo: "Armadura", level: "33", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "-15"], ["Sagrado", "19"], ["Gelo", "19"]]},
    {nome: "Robes", tipo: "Armadura", level: "41", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "5"], ["Gelo", "24"]]},
    {nome: "Coldshadow Robes", tipo: "Armadura", level: "48", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "7"], ["Gelo", "20"]]},
    {nome: "Frost Mantle", tipo: "Armadura", level: "51", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "30"], ["Gelo", "17"]]},
    {nome: "Deepfrozen Robe", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "21"], ["Gelo", "43"]]},
    {nome: "(+) Deepfrozen Robe", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "28"], ["Gelo", "57"]], obs: "Versão \"+\" de Deepfrozen Robe."},
    {nome: "(+ light) Deepfrozen Robe", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "21"], ["Raio", "21"], ["Gelo", "43"]], obs: "Variação \"+ light\" de Deepfrozen Robe (troca parte da defesa por Raio)."},
    {nome: "(+ soul) Deepfrozen Robe", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "21"], ["Sagrado", "21"], ["Gelo", "43"]], obs: "Variação \"+ soul\" de Deepfrozen Robe (troca parte da defesa por Sagrado)."},
    {nome: "Dress", tipo: "Armadura", level: "22", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "5"], ["Raio", "15"]]},
    {nome: "Faraday Robe", tipo: "Armadura", level: "29", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "16"], ["Raio", "18"]]},
    {nome: "Pirate Shirt", tipo: "Armadura", level: "30", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "18"], ["Fogo", "-15"], ["Gelo", "18"]]},
    {nome: "Shaolin Robe", tipo: "Armadura", level: "34", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "20"], ["Raio", "10"]]},
    {nome: "Plasma Cape", tipo: "Armadura", level: "46", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "28"], ["Fogo", "-5"]]},
    {nome: "To-Maga Cape", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "43"], ["Gelo", "21"]]},
    {nome: "(+) To-maga Cape", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "57"], ["Gelo", "28"]], obs: "Versão \"+\" de To-maga Cape."},
    {nome: "(+ hit) To-maga Cape", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "21"], ["Raio", "43"], ["Gelo", "21"]], obs: "Variação \"+ hit\" de To-maga Cape (troca parte da defesa por Físico)."},
    {nome: "(+ soul) To-maga Cape", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "43"], ["Sagrado", "21"], ["Gelo", "21"]], obs: "Variação \"+ soul\" de To-maga Cape (troca parte da defesa por Sagrado)."},
    {nome: "Holy Robe", tipo: "Armadura", level: "13", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "-6"], ["Sagrado", "10"]]},
    {nome: "Angelic Mantle", tipo: "Armadura", level: "34", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "-11"], ["Sagrado", "20"]]},
    {nome: "Covering Mantle", tipo: "Armadura", level: "37", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "16"], ["Sagrado", "22"]]},
    {nome: "Sanctification Cloak", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "21"], ["Sagrado", "43"]]},
    {nome: "(+) Sanctification Cloak", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "28"], ["Sagrado", "57"]], obs: "Versão \"+\" de Sanctification Cloak."},
    {nome: "(+ fire) Sanctification Cloak", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "21"], ["Fogo", "21"], ["Sagrado", "43"]], obs: "Variação \"+ fire\" de Sanctification Cloak (troca parte da defesa por Fogo)."},
    {nome: "(+ ice) Sanctification Cloak", tipo: "Armadura", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "21"], ["Sagrado", "43"], ["Gelo", "21"]], obs: "Variação \"+ ice\" de Sanctification Cloak (troca parte da defesa por Gelo)."},
    // --- Pernas (Calça) ---
    {nome: "Light Legs", tipo: "Calça", level: "0", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "2"]]},
    {nome: "Apprentice legs", tipo: "Calça", level: "4", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "4"]]},
    {nome: "Spell Student Legs", tipo: "Calça", level: "9", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "6"]]},
    {nome: "Night Pants", tipo: "Calça", level: "17", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "8"]]},
    {nome: "Basting Legs", tipo: "Calça", level: "22", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "10"]]},
    {nome: "Spellwielder Legs", tipo: "Calça", level: "26", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "12"]]},
    {nome: "Armoured Trousers", tipo: "Calça", level: "40", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "18"]]},
    {nome: "Battlemage Legs", tipo: "Calça", level: "46", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "20"]]},
    {nome: "Monter Legs", tipo: "Calça", level: "51", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "22"]]},
    {nome: "Monter Pants", tipo: "Calça", level: "51", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "22"]]},
    {nome: "Winter Legs", tipo: "Calça", level: "57", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "16"], ["Gelo", "5"]]},
    {nome: "Spellmaster Legs", tipo: "Calça", level: "58", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "24"]]},
    {nome: "Forcedeflect Pants", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "32"], ["Sagrado", "16"]]},
    {nome: "(+) Forcedeflect Pants", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "43"], ["Sagrado", "21"]], obs: "Versão \"+\" de Forcedeflect Pants."},
    {nome: "(+ fire) Forcedeflect Pants", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "32"], ["Fogo", "16"], ["Sagrado", "16"]], obs: "Variação \"+ fire\" de Forcedeflect Pants (troca parte da defesa por Fogo)."},
    {nome: "(+ ice) Forcedeflect Pants", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "32"], ["Sagrado", "16"], ["Gelo", "16"]], obs: "Variação \"+ ice\" de Forcedeflect Pants (troca parte da defesa por Gelo)."},
    {nome: "(+) Robe Legs", tipo: "Calça", level: "35", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "10"], ["Fogo", "15"]], obs: "Versão \"+\" de Robe Legs."},
    {nome: "Robe Legs", tipo: "Calça", level: "35", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "5"], ["Fogo", "15"]]},
    {nome: "Magma Pants", tipo: "Calça", level: "47", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "8"], ["Fogo", "20"]]},
    {nome: "King's Trousers", tipo: "Calça", level: "57", vocacao: "Mago", dano: [], mana: "", defesa: [["Fogo", "25"], ["Sagrado", "-7"]]},
    {nome: "Demonic Trousers", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Fogo", "32"], ["Sagrado", "16"]]},
    {nome: "(+) Demonic Trousers", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Fogo", "43"], ["Sagrado", "21"]], obs: "Versão \"+\" de Demonic Trousers."},
    {nome: "(+ hit) Demonic Trousers", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "16"], ["Fogo", "32"], ["Sagrado", "16"]], obs: "Variação \"+ hit\" de Demonic Trousers (troca parte da defesa por Físico)."},
    {nome: "(+ light) Demonic Trousers", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "16"], ["Fogo", "32"], ["Sagrado", "16"]], obs: "Variação \"+ light\" de Demonic Trousers (troca parte da defesa por Raio)."},
    {nome: "Fur-lined Trousers", tipo: "Calça", level: "17", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "8"], ["Gelo", "8"]]},
    {nome: "Sailor Pants", tipo: "Calça", level: "26", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "-6"], ["Sagrado", "12"], ["Gelo", "12"]]},
    {nome: "Lined Cloth Pants", tipo: "Calça", level: "26", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "5"], ["Gelo", "12"]]},
    {nome: "Blue Belt", tipo: "Calça", level: "30", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "13"], ["Raio", "13"]]},
    {nome: "Coldshadow Pants", tipo: "Calça", level: "46", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "6"], ["Gelo", "14"]]},
    {nome: "Deepfrozen Pants", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "16"], ["Gelo", "32"]]},
    {nome: "(+) Deepfrozen Pants", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "21"], ["Gelo", "43"]], obs: "Versão \"+\" de Deepfrozen Pants."},
    {nome: "(+ light) Deepfrozen Pants", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "16"], ["Raio", "16"], ["Gelo", "32"]], obs: "Variação \"+ light\" de Deepfrozen Pants (troca parte da defesa por Raio)."},
    {nome: "(+ soul) Deepfrozen Pants", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "16"], ["Sagrado", "16"], ["Gelo", "32"]], obs: "Variação \"+ soul\" de Deepfrozen Pants (troca parte da defesa por Sagrado)."},
    {nome: "Orange Belt", tipo: "Calça", level: "22", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "7"], ["Raio", "10"]]},
    {nome: "Pirate Pants", tipo: "Calça", level: "26", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "12"], ["Fogo", "-6"], ["Gelo", "12"]]},
    {nome: "Faraday Skirt", tipo: "Calça", level: "27", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "10"], ["Raio", "12"]]},
    {nome: "Green Belt", tipo: "Calça", level: "32", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "13"], ["Raio", "13"]]},
    {nome: "Shaolin Pants", tipo: "Calça", level: "35", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "15"], ["Raio", "10"]]},
    {nome: "Plasma Trousers", tipo: "Calça", level: "40", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "19"]]},
    {nome: "To-Maga Trousers", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "32"], ["Gelo", "16"]]},
    {nome: "(+) To-maga Trousers", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "43"], ["Gelo", "21"]], obs: "Versão \"+\" de To-maga Trousers."},
    {nome: "(+ hit) To-maga Trousers", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "16"], ["Raio", "32"], ["Gelo", "16"]], obs: "Variação \"+ hit\" de To-maga Trousers (troca parte da defesa por Físico)."},
    {nome: "(+ soul) To-maga Trousers", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "32"], ["Sagrado", "16"], ["Gelo", "16"]], obs: "Variação \"+ soul\" de To-maga Trousers (troca parte da defesa por Sagrado)."},
    {nome: "Chastity Pants", tipo: "Calça", level: "22", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "8"], ["Sagrado", "10"]]},
    {nome: "Black Belt", tipo: "Calça", level: "34", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "5"], ["Raio", "5"], ["Sagrado", "14"]]},
    {nome: "Holy Legs", tipo: "Calça", level: "34", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "14"], ["Sagrado", "5"]]},
    {nome: "Sanctification Legs", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "16"], ["Sagrado", "32"]]},
    {nome: "(+) Sanctification Legs", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "21"], ["Sagrado", "43"]], obs: "Versão \"+\" de Sanctification Legs."},
    {nome: "(+ fire) Sanctification Legs", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "16"], ["Fogo", "16"], ["Sagrado", "32"]], obs: "Variação \"+ fire\" de Sanctification Legs (troca parte da defesa por Fogo)."},
    {nome: "(+ ice) Sanctification Legs", tipo: "Calça", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "16"], ["Sagrado", "32"], ["Gelo", "16"]], obs: "Variação \"+ ice\" de Sanctification Legs (troca parte da defesa por Gelo)."},
    // --- Escudo ---
    {nome: "Light Magic Shield", tipo: "Escudo", level: "3", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "2"]]},
    {nome: "Basting Shield", tipo: "Escudo", level: "20", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "8"]]},
    {nome: "Enlighted Shield", tipo: "Escudo", level: "29", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "12"]]},
    {nome: "Armoured Shield (Wiz)", tipo: "Escudo", level: "42", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "15"]]},
    {nome: "Monter Shield", tipo: "Escudo", level: "55", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "18"]]},
    {nome: "Magic shield", tipo: "Escudo", level: "63", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "22"]]},
    {nome: "(+) Magic shield", tipo: "Escudo", level: "66", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "25"]], obs: "Versão \"+\" de Magic shield."},
    {nome: "Forcedeflect Glove", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "27"], ["Sagrado", "13"]]},
    {nome: "(+) Forcedeflect Glove", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "36"], ["Sagrado", "17"]], obs: "Versão \"+\" de Forcedeflect Glove."},
    {nome: "(+ fire) Forcedeflect Glove", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "27"], ["Fogo", "13"], ["Sagrado", "13"]], obs: "Variação \"+ fire\" de Forcedeflect Glove (troca parte da defesa por Fogo)."},
    {nome: "(+ ice) Forcedeflect Glove", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "27"], ["Sagrado", "13"], ["Gelo", "13"]], obs: "Variação \"+ ice\" de Forcedeflect Glove (troca parte da defesa por Gelo)."},
    {nome: "Griffin Axe Shield", tipo: "Escudo", level: "33", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "13"]]},
    {nome: "Magma Aegis", tipo: "Escudo", level: "48", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "6"], ["Fogo", "16"]]},
    {nome: "Demonic Shield", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Fogo", "27"], ["Sagrado", "13"]]},
    {nome: "(+) Demonic Shield", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Fogo", "36"], ["Sagrado", "17"]], obs: "Versão \"+\" de Demonic Shield."},
    {nome: "(+ hit) Demonic Shield", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "13"], ["Fogo", "27"], ["Sagrado", "13"]], obs: "Variação \"+ hit\" de Demonic Shield (troca parte da defesa por Físico)."},
    {nome: "(+ light) Demonic Shield", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "13"], ["Fogo", "27"], ["Sagrado", "13"]], obs: "Variação \"+ light\" de Demonic Shield (troca parte da defesa por Raio)."},
    {nome: "Shaoshield Mill", tipo: "Escudo", level: "24", vocacao: "Mago", dano: [], mana: "", defesa: [["Sagrado", "5"], ["Gelo", "10"]]},
    {nome: "Coldshadow Guard", tipo: "Escudo", level: "49", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "5"], ["Gelo", "11"]]},
    {nome: "Deepfrozen Shield", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "13"], ["Gelo", "27"]]},
    {nome: "(+) Deepfrozen Shield", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "17"], ["Gelo", "36"]], obs: "Versão \"+\" de Deepfrozen Shield."},
    {nome: "(+ light) Deepfrozen Shield", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "13"], ["Raio", "13"], ["Gelo", "27"]], obs: "Variação \"+ light\" de Deepfrozen Shield (troca parte da defesa por Raio)."},
    {nome: "(+ soul) Deepfrozen Shield", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "13"], ["Sagrado", "13"], ["Gelo", "27"]], obs: "Variação \"+ soul\" de Deepfrozen Shield (troca parte da defesa por Sagrado)."},
    {nome: "Faraday Shield", tipo: "Escudo", level: "31", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "12"], ["Raio", "12"]]},
    {nome: "Static Shield", tipo: "Escudo", level: "42", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "10"], ["Raio", "15"]]},
    {nome: "To-Maga Aegis", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "27"], ["Gelo", "13"]]},
    {nome: "(+) To-maga Aegis", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "36"], ["Gelo", "17"]], obs: "Versão \"+\" de To-maga Aegis."},
    {nome: "(+ hit) To-maga Aegis", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "13"], ["Raio", "27"], ["Gelo", "13"]], obs: "Variação \"+ hit\" de To-maga Aegis (troca parte da defesa por Físico)."},
    {nome: "(+ soul) To-maga Aegis", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "27"], ["Sagrado", "13"], ["Gelo", "13"]], obs: "Variação \"+ soul\" de To-maga Aegis (troca parte da defesa por Sagrado)."},
    {nome: "Hex Shield", tipo: "Escudo", level: "42", vocacao: "Mago", dano: [], mana: "", defesa: [["Físico", "5"], ["Sagrado", "15"]]},
    {nome: "Sanctification Ward", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "13"], ["Sagrado", "27"]]},
    {nome: "(+) Sanctification Ward", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "17"], ["Sagrado", "36"]], obs: "Versão \"+\" de Sanctification Ward."},
    {nome: "(+ fire) Sanctification Ward", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "13"], ["Fogo", "13"], ["Sagrado", "27"]], obs: "Variação \"+ fire\" de Sanctification Ward (troca parte da defesa por Fogo)."},
    {nome: "(+ ice) Sanctification Ward", tipo: "Escudo", level: "79", vocacao: "Mago", dano: [], mana: "", defesa: [["Raio", "13"], ["Sagrado", "27"], ["Gelo", "13"]], obs: "Variação \"+ ice\" de Sanctification Ward (troca parte da defesa por Gelo)."},
    // --- Amuleto ---
    {nome: "Student Necklace", tipo: "Amuleto", level: "7", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "3"]]},
    {nome: "Field Amulet", tipo: "Amuleto", level: "23", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "5"]]},
    {nome: "Wielder Amulet", tipo: "Amuleto", level: "28", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "6"]]},
    {nome: "Enlighted Necklace", tipo: "Amuleto", level: "31", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "7"]]},
    {nome: "Mithril Amulet", tipo: "Amuleto", level: "32", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "6"], ["Raio", "7"]]},
    {nome: "Holy Amulet", tipo: "Amuleto", level: "39", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "8"]]},
    {nome: "Armoured amulet", tipo: "Amuleto", level: "45", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "9"]]},
    {nome: "Necklace Of Crush", tipo: "Amuleto", level: "47", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "3"], ["Fogo", "9"]]},
    {nome: "Battle Amulet", tipo: "Amuleto", level: "49", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "10"]]},
    {nome: "Spark Chain", tipo: "Amuleto", level: "49", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Raio", "10"], ["Fogo", "10"]]},
    {nome: "Crystal Chain", tipo: "Amuleto", level: "49", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Raio", "10"], ["Gelo", "10"]]},
    {nome: "Glacier Chain", tipo: "Amuleto", level: "49", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "5"], ["Gelo", "10"]]},
    {nome: "Blessed Brooch", tipo: "Amuleto", level: "49", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "10"], ["Sagrado", "10"]]},
    {nome: "Spiritual Amulet", tipo: "Amuleto", level: "49", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Sagrado", "10"]]},
    {nome: "Sphinx Eye Talisman", tipo: "Amuleto", level: "51", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Sagrado", "10"]]},
    {nome: "Monter Amulet", tipo: "Amuleto", level: "53", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "11"]]},
    {nome: "Master Amulet", tipo: "Amuleto", level: "61", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "12"]]},
    {nome: "Eye Patch", tipo: "Amuleto", level: "78", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "15"], ["Raio", "5"], ["Gelo", "5"]]},
    {nome: "Power Amulet", tipo: "Amuleto", level: "79", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "20"]]},
    {nome: "Steel Chain", tipo: "Amuleto", level: "79", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "25"]]},
    {nome: "Chain of Force", tipo: "Amuleto", level: "79", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "20"]]},
    {nome: "Royal Neck Cooler", tipo: "Amuleto", level: "79", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "5"], ["Fogo", "25"]]},
    {nome: "Talisman", tipo: "Amuleto", level: "79", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Fogo", "20"]]},
    {nome: "Soul Vessel", tipo: "Amuleto", level: "79", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Fogo", "20"]]},
    {nome: "Loaded Soul Vessel", tipo: "Amuleto", level: "79", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Fogo", "20"]]},
    {nome: "Amulet of Snow", tipo: "Amuleto", level: "79", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Gelo", "20"]]},
    {nome: "Amulet of Earth", tipo: "Amuleto", level: "79", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Raio", "20"]]},
    {nome: "Divine Amulet", tipo: "Amuleto", level: "79", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Sagrado", "20"]]},
    // --- Anel ---
    {nome: "Student Ring", tipo: "Anel", level: "8", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "4"]]},
    {nome: "Field Ring", tipo: "Anel", level: "21", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "7"]]},
    {nome: "Wielder Ring", tipo: "Anel", level: "27", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "8"]]},
    {nome: "Enlighted Ring", tipo: "Anel", level: "30", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "9"]]},
    {nome: "Faraday Ring", tipo: "Anel", level: "30", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "8"], ["Raio", "9"]]},
    {nome: "Fur Gloves", tipo: "Anel", level: "34", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Gelo", "10"]]},
    {nome: "Skull Ring", tipo: "Anel", level: "34", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "10"], ["Raio", "10"], ["Fogo", "-10"], ["Gelo", "10"]]},
    {nome: "Jade Ring", tipo: "Anel", level: "34", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "5"], ["Sagrado", "10"]]},
    {nome: "Soulfire Ring", tipo: "Anel", level: "34", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Fogo", "10"], ["Sagrado", "10"]]},
    {nome: "Holy Ring", tipo: "Anel", level: "38", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "11"]]},
    {nome: "Armoured Ring", tipo: "Anel", level: "43", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "12"]]},
    {nome: "Battle Ring", tipo: "Anel", level: "48", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "13"]]},
    {nome: "Broodmother Ring", tipo: "Anel", level: "49", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "4"], ["Fogo", "13"]]},
    {nome: "Crystal Shard Ring", tipo: "Anel", level: "50", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Gelo", "13"]]},
    {nome: "Monter Ring", tipo: "Anel", level: "56", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "15"]]},
    {nome: "Ruby Ring", tipo: "Anel", level: "56", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Fogo", "15"]]},
    {nome: "Cozy Warmring", tipo: "Anel", level: "56", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "15"], ["Raio", "10"]]},
    {nome: "Crystal Ring", tipo: "Anel", level: "56", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Gelo", "15"]]},
    {nome: "Ninja Ring", tipo: "Anel", level: "56", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "5"], ["Gelo", "15"]]},
    {nome: "Master Ring", tipo: "Anel", level: "60", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "16"]]},
    {nome: "Shield Ring", tipo: "Anel", level: "76", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "20"]]},
    {nome: "Fire Ring", tipo: "Anel", level: "76", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Fogo", "20"]]},
    {nome: "Hardwater Ring", tipo: "Anel", level: "76", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Gelo", "20"]]},
    {nome: "Gold Ring", tipo: "Anel", level: "76", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Raio", "20"]]},
    {nome: "Chastity Ring", tipo: "Anel", level: "76", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Sagrado", "20"]]},
    {nome: "Energy Ring", tipo: "Anel", level: "78", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Raio", "25"]]},
    {nome: "Forcebender Ring", tipo: "Anel", level: "79", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Físico", "25"]]},
    {nome: "Sanctification Ring", tipo: "Anel", level: "79", vocacao: "Guerreiro e Mago", dano: [], mana: "", defesa: [["Sagrado", "20"]]}
];

// Nomes escritos de forma diferente entre lojas e drops de mobs.
var ALIAS_NOME_ITEM = { "meelee mallet": ["melee mallet"] };
var ORDEM_TIPO_ITEM = ["Arma", "Armadura", "Elmo", "Calça", "Escudo", "Anel", "Amuleto"];

function OrdemTipoItem(tipo) {
    var i = ORDEM_TIPO_ITEM.indexOf(tipo);
    return i === -1 ? 99 : i;
}

function TextoStatsItem(it) {
    var t = [], i;
    for (i = 0; it.dano && i < it.dano.length; i++) t.push(it.dano[i][0] + " " + it.dano[i][1]);
    if (it.mana) t.push("Mana " + it.mana);
    for (i = 0; it.defesa && i < it.defesa.length; i++) t.push("Def " + it.defesa[i][0] + " " + it.defesa[i][1] + "%");
    return t.length ? t.join(" | ") : "A definir";
}

function GerarItensDaBase() {
    // --- indice: nome do item (normalizado) -> mobs/bosses que o dropam ---
    var indice = {};
    function indexar(nomeFonte, locais, drops, ehBoss) {
        if (!drops) return;
        var toks = String(drops).replace(/\([^)]*\)/g, "").split(",");
        for (var t = 0; t < toks.length; t++) {
            var chave = NormalizarTexto(toks[t]);
            if (!chave) continue;
            if (!indice[chave]) indice[chave] = [];
            var ja = false;
            for (var k = 0; k < indice[chave].length; k++) if (indice[chave][k].nome === nomeFonte) ja = true;
            if (!ja) indice[chave].push({ nome: nomeFonte, locais: locais || "", boss: !!ehBoss });
        }
    }
    var mobs = DB_TIBIAME.Mobs || [], bosses = DB_TIBIAME.Bosses || [], i, j;
    for (i = 0; i < mobs.length; i++) indexar(mobs[i].nome, mobs[i].locais, mobs[i].drops, false);
    for (i = 0; i < bosses.length; i++) {
        indexar(bosses[i].nome, bosses[i].ilha || bosses[i].local, bosses[i].drops, true);
        var sub = Array.isArray(bosses[i].mobs) ? bosses[i].mobs : [];
        for (j = 0; j < sub.length; j++) indexar(sub[j].nome, sub[j].ilha || bosses[i].ilha, sub[j].drops, true);
    }

    // --- junta os itens das lojas (mesmo nome + tipo = um item so, com varias lojas) ---
    var mapa = {}, lista = [];
    function copiar(arr) { var r = []; for (var x = 0; arr && x < arr.length; x++) r.push(arr[x].slice()); return r; }
    function adicionar(it, loja) {
        var chave = NormalizarTexto(it.nome) + "|" + NormalizarTexto(it.tipo);
        var reg = mapa[chave];
        if (!reg) {
            reg = { nome: it.nome, tipo: it.tipo, level: it.level || "A definir", vocacao: it.vocacao || "A definir",
                    dano: copiar(it.dano), mana: it.mana || "", defesa: copiar(it.defesa), obs: "", lojas: [] };
            mapa[chave] = reg;
            lista.push(reg);
        } else {
            if (reg.vocacao === "A definir" && it.vocacao && it.vocacao !== "A definir") reg.vocacao = it.vocacao;
            if (/[-\u2013]/.test(reg.level) && it.level && !/[-\u2013]/.test(it.level) && it.level !== "A definir") reg.level = it.level;
            if (!reg.dano.length && it.dano && it.dano.length) reg.dano = copiar(it.dano);
            if (!reg.defesa.length && it.defesa && it.defesa.length) reg.defesa = copiar(it.defesa);
            if (!reg.mana && it.mana) reg.mana = it.mana;
        }
        if (loja) reg.lojas.push({ loja: loja.nome, npc: it.npc || loja.npc, preco: it.preco || "A definir" });
        if (it.obs && reg.obs.indexOf(it.obs) === -1) reg.obs += (reg.obs ? " " : "") + it.obs;
    }
    var lojas = DB_TIBIAME.Lojas || [];
    for (i = 0; i < lojas.length; i++) {
        for (j = 0; j < lojas[i].itens.length; j++) {
            if (lojas[i].itens[j].materiais) continue;   // linhas genericas de ferreiro/troca ficam so na aba Lojas
            adicionar(lojas[i].itens[j], lojas[i]);
        }
    }
    for (i = 0; i < ITENS_MANUAIS.length; i++) {
        var man = ITENS_MANUAIS[i];
        var primeira = true;
        var ls = man.lojas || [];
        if (!ls.length) adicionar(man, null);
        for (j = 0; j < ls.length; j++) adicionar({ nome: man.nome, tipo: man.tipo, level: man.level, vocacao: man.vocacao,
            dano: man.dano, mana: man.mana, defesa: man.defesa, obs: primeira ? man.obs : "", npc: ls[j].npc, preco: ls[j].preco },
            { nome: ls[j].loja, npc: ls[j].npc }), primeira = false;
    }

    // --- campos finais: elemento, drops de mobs, texto de "onde achar" ---
    for (i = 0; i < lista.length; i++) {
        var r = lista[i];
        if (r.dano.length) {
            var els = [];
            for (j = 0; j < r.dano.length; j++) els.push(r.dano[j][0]);
            r.elemento = els.join(", ");
        } else { r.elemento = ""; }
        r.reqLevel = r.level;
        r.stats = TextoStatsItem(r);
        r.precoRef = r.lojas.length ? r.lojas[0].preco : "A definir";

        var chaves = [NormalizarTexto(r.nome)];
        var al = ALIAS_NOME_ITEM[chaves[0]] || [];
        for (j = 0; j < al.length; j++) chaves.push(NormalizarTexto(al[j]));
        r.dropsMobs = [];
        var locais = [];
        for (var c = 0; c < chaves.length; c++) {
            var fontes = indice[chaves[c]] || [];
            for (j = 0; j < fontes.length; j++) {
                var rot = fontes[j].nome + (fontes[j].boss ? " (boss)" : "");
                if (r.dropsMobs.indexOf(rot) === -1) r.dropsMobs.push(rot);
                var ps = String(fontes[j].locais).split(",");
                for (var p = 0; p < ps.length; p++) {
                    var lc = ps[p].replace(/^\s+|\s+$/g, "");
                    if (lc && locais.indexOf(lc) === -1) locais.push(lc);
                }
            }
        }
        r.locaisDrop = locais;

        var partes = [];
        if (r.lojas.length) {
            var ll = [];
            for (j = 0; j < r.lojas.length; j++) ll.push(r.lojas[j].loja + " (" + r.lojas[j].preco + ")");
            partes.push("Comprar em: " + ll.join("; "));
        }
        if (r.dropsMobs.length) {
            partes.push("Drop de: " + r.dropsMobs.slice(0, 8).join(", ") + (r.dropsMobs.length > 8 ? " e mais " + (r.dropsMobs.length - 8) : "") +
                        (locais.length ? " (locais: " + locais.join(", ") + ")" : ""));
        }
        r.ondeAchar = partes.length ? partes.join(" | ") : "A definir";
    }

    lista.sort(function(x, y) {
        var d = OrdemTipoItem(x.tipo) - OrdemTipoItem(y.tipo);
        if (d !== 0) return d;
        var lx = ExtrairLevelMinimo(x.level), ly = ExtrairLevelMinimo(y.level);
        if (isNaN(lx)) lx = 999;
        if (isNaN(ly)) ly = 999;
        if (lx !== ly) return lx - ly;
        return x.nome < y.nome ? -1 : (x.nome > y.nome ? 1 : 0);
    });
    DB_TIBIAME.Itens = lista;
}
GerarItensDaBase();

var abaAtual = "Tutor";
var paginaMob = 0;
var paginaBoss = 0;
var paginaItem = 0;
var catPaginada = "Mobs";   // lista paginada em exibicao (usada pelos botoes Anterior/Proxima)
var toqueIniX = 0, toqueIniY = 0, toqueIniT = 0, toqueArrastou = false;
var paginaTutorLista = 0;
var itensPorPagina = 10;
var itensPorPaginaTutor = 7;

var edtBusca = null;
var txtInfo = null;
var webInfoBoss = null;
var boxStats = null;
var bordaStatsTopo = null;
var bordaStatsBase = null;
var scrLista = null;
var layLista = null;
var botoesLista = [];
var botoesAbas = [];
var itemSelecionado = null;
var catSelecionada = null;
var bossAbertoAtual = null;
var bloqueioCliqueItem = 0;
var wikiCtx = null;   // busca da wiki em andamento (null = nenhuma ou ja descartada)

// ==========================================
// SISTEMA DE PERFIS DE PERSONAGENS (ATÉ 5)
// ==========================================
var MAX_PERFIS = 5;
var perfisSalvos = [];
var perfilAtivoIndex = -1;

// Estado do formulário e visualização da aba Tutor
// Modos: "auto", "criar", "editar", "perfis", "painel", "mobs", "armas", "bosses"
var tutorModo = "auto";
var formClasse = "";
var formNome = "";
var formLevel = "";
var formXp = "";
var subListaAtual = [];
var subCatAtual = "";

// Referencias GLOBAIS do formulario de personagem (handlers nao dependem de closure).
var formEdtNome = null;
var formEdtLv = null;
var formEdtXp = null;
var formEhEdicao = false;
// Indice do perfil aguardando confirmacao de exclusao.
var perfilParaApagar = -1;

function CarregarPerfisStorage() {
    try {
        var raw = app.LoadText("tibiame_tutor_perfis", "[]", "TibiaME_Tutor");
        var arr = JSON.parse(raw);
        if (Array.isArray(arr)) {
            perfisSalvos = arr.slice(0, MAX_PERFIS);
        } else {
            perfisSalvos = [];
        }
    } catch (e) {
        perfisSalvos = [];
    }

    try {
        var idxStr = app.LoadText("tibiame_tutor_ativo", "-1", "TibiaME_Tutor");
        var idxNum = parseInt(idxStr, 10);
        if (!isNaN(idxNum) && idxNum >= 0 && idxNum < perfisSalvos.length) {
            perfilAtivoIndex = idxNum;
        } else {
            perfilAtivoIndex = perfisSalvos.length > 0 ? 0 : -1;
        }
    } catch (e) {
        perfilAtivoIndex = perfisSalvos.length > 0 ? 0 : -1;
    }
}

function SalvarPerfisStorage() {
    try {
        app.SaveText("tibiame_tutor_perfis", JSON.stringify(perfisSalvos), "TibiaME_Tutor");
        app.SaveText("tibiame_tutor_ativo", String(perfilAtivoIndex), "TibiaME_Tutor");
    } catch (e) {}
}

function ObterPerfilAtivo() {
    if (perfilAtivoIndex >= 0 && perfilAtivoIndex < perfisSalvos.length) {
        return perfisSalvos[perfilAtivoIndex];
    }
    return null;
}

function ExtrairNumero(valor) {
    if (valor === null || valor === undefined) return NaN;
    var limpo = String(valor).replace(/[^0-9]/g, "");
    if (!limpo) return NaN;
    return parseInt(limpo, 10);
}

// Level MINIMO de um texto como "120/140+", "100+", "+80" ou "10-15": usa o PRIMEIRO numero.
// (ExtrairNumero junta todos os digitos: "120/140+" virava 120140.)
function ExtrairLevelMinimo(valor) {
    if (valor === null || valor === undefined) return NaN;
    var m = String(valor).match(/\d+/);
    return m ? parseInt(m[0], 10) : NaN;
}

// ---- BUG 4: valor "definido" (ignora vazio e "A definir") ----
function ValorDefinido(v) {
    if (v === null || v === undefined) return false;
    var t = String(v).trim();
    return t !== "" && NormalizarTexto(t) !== "a definir";
}

// Recompensa do boss: usa a do proprio item; se for "A definir" (mobs do boss), usa a do boss aberto.
function ObterRecompensaBoss(item) {
    if (item && ValorDefinido(item.recompensasBoss)) return item.recompensasBoss;
    if (bossAbertoAtual && ValorDefinido(bossAbertoAtual.recompensasBoss)) return bossAbertoAtual.recompensasBoss;
    return "A definir";
}

// Usa o campo level do mob quando preenchido; caso contrário estima com base em HP e XP
function EstimarNivelMob(mob) {
    var lvInformado = ExtrairLevelMinimo(mob.level);
    if (!isNaN(lvInformado) && lvInformado > 0) {
        return lvInformado;
    }

    var hp = ExtrairNumero(mob.hp);
    var xp = ExtrairNumero(mob.xp);
    if (isNaN(hp)) hp = 100;
    if (isNaN(xp)) xp = 10;

    var lvPorHp = Math.max(1, Math.round(hp / 22));
    var lvPorXp = Math.max(1, Math.round(xp / 4.2));
    return Math.max(1, Math.round((lvPorHp + lvPorXp) / 2));
}

function CalcularMobsParaUpar(xpFaltante, xpMobStr) {
    var xpMob = ExtrairNumero(xpMobStr);
    var xpRest = ExtrairNumero(xpFaltante);
    if (isNaN(xpRest) || xpRest <= 0) return null;
    if (isNaN(xpMob) || xpMob <= 0) return null;
    return Math.ceil(xpRest / xpMob);
}

function ObterMobsParaNivel(perfil) {
    var lv = perfil.level;
    var margemMin = Math.max(1, lv - 8);
    var margemMax = lv + 10;
    var todos = DB_TIBIAME.Mobs || [];
    var recomendados = [];

    for (var i = 0; i < todos.length; i++) {
        var m = todos[i];
        var lvEst = EstimarNivelMob(m);
        if (lvEst >= margemMin && lvEst <= margemMax) {
            recomendados.push({
                mob: m,
                lvEst: lvEst,
                diff: Math.abs(lvEst - lv)
            });
        }
    }

    recomendados.sort(function(a, b) {
        return a.diff - b.diff;
    });

    if (recomendados.length === 0) {
        for (var j = 0; j < todos.length; j++) {
            var m2 = todos[j];
            var lvEst2 = EstimarNivelMob(m2);
            recomendados.push({
                mob: m2,
                lvEst: lvEst2,
                diff: Math.abs(lvEst2 - lv)
            });
        }
        recomendados.sort(function(a, b) {
            return a.diff - b.diff;
        });
        recomendados = recomendados.slice(0, 15);
    }

    var resultado = [];
    for (var k = 0; k < recomendados.length; k++) {
        resultado.push(recomendados[k].mob);
    }
    return resultado;
}

// A classe do perfil (Warrior/Wizard) serve para a vocacao do item (Guerreiro/Mago/Guerreiro e Mago/Ambos).
function VocacaoServeClasse(vocacao, classe) {
    var v = NormalizarTexto(vocacao);
    var c = NormalizarTexto(classe);
    if (v === "" || v.indexOf("ambos") !== -1 || v.indexOf("todas") !== -1 || v === "all" || v.indexOf("definir") !== -1) return true;
    var ehGuerreiro = (c.indexOf("warrior") !== -1 || c.indexOf("guerreiro") !== -1);
    var ehMago = (c.indexOf("wizard") !== -1 || c.indexOf("mago") !== -1);
    if (ehGuerreiro && (v.indexOf("guerreiro") !== -1 || v.indexOf("warrior") !== -1)) return true;
    if (ehMago && (v.indexOf("mago") !== -1 || v.indexOf("wizard") !== -1)) return true;
    return false;
}

// Itens uteis: armas, armaduras e acessorios (lojas e outros) que o perfil ja pode usar,
// do melhor (maior level) para o mais fraco.
function ObterItensUteisParaPerfil(perfil) {
    var itens = DB_TIBIAME.Itens || [];
    var lv = Number(perfil.level);
    var lista = [];
    for (var i = 0; i < itens.length; i++) {
        var it = itens[i];
        var req = ExtrairLevelMinimo(it.reqLevel || it.level);
        var serveLevel = isNaN(req) || isNaN(lv) || (req <= lv);
        if (serveLevel && VocacaoServeClasse(it.vocacao, perfil.classe)) lista.push(it);
    }
    lista.sort(function(x, y) {
        var lx = ExtrairLevelMinimo(x.reqLevel || x.level), ly = ExtrairLevelMinimo(y.reqLevel || y.level);
        if (isNaN(lx)) lx = -1;
        if (isNaN(ly)) ly = -1;
        if (lx !== ly) return ly - lx;
        return OrdemTipoItem(x.tipo) - OrdemTipoItem(y.tipo);
    });
    return lista;
}

// ============================================================
// CALENDARIO DOS EVENTOS (bosses de evento so aparecem em "Bosses que consigo enfrentar"
// quando o evento esta ativo). Os horarios sao os da CipSoft (Europa: CET/CEST).
// - "datas": janelas exatas ja confirmadas em anuncios oficiais (mes/dia, inclusive o ultimo dia).
// - "padrao": janela ESTIMADA usada em anos sem data confirmada; a CipSoft muda as datas
//   todo ano. Com "padrao: null" e sem linha em "datas", o evento fica sempre inativo
//   (bosses nunca aparecem como possiveis). Quando sair o anuncio do ano, e so acrescentar
//   uma linha em "datas".
// ============================================================
var CALENDARIO_EVENTOS = {
    aniversario: {
        nome: "Evento de Aniversario",
        datas: [],
        padrao: null   // datas nao confirmadas (so se sabe que comeca perto de 12/05): boss fica na lista dos que nao da pra enfrentar
    },
    carneiro: {
        nome: "The Fall of Carneiro",
        datas: [
            { ano: 2017, ini: [2, 24], fim: [3, 5] },
            { ano: 2020, ini: [2, 19], fim: [2, 26] },
            { ano: 2021, ini: [2, 17], fim: [2, 24] }
        ],
        padrao: { ini: [2, 17], fim: [3, 5] }    // estimado (final de fevereiro / inicio de marco)
    },
    dragonrutting: {
        nome: "Dragon Rutting",
        datas: [
            { ano: 2017, ini: [4, 13], fim: [4, 23] }
        ],
        padrao: { ini: [4, 13], fim: [4, 23] }   // estimado (abril)
    }
};

// Ultimo domingo do mes (dia do mes) para calcular o horario de verao europeu.
function UltimoDomingoDoMes(ano, mes) {
    var d = new Date(Date.UTC(ano, mes, 0));            // ultimo dia do mes (mes 1-12)
    return d.getUTCDate() - d.getUTCDay();
}

// Data/hora atual no fuso da CipSoft (CET = UTC+1, CEST = UTC+2).
function ObterDataEuropa() {
    var agora = Date.now ? Date.now() : (new Date()).getTime();
    var u = new Date(agora);
    var ano = u.getUTCFullYear(), mes = u.getUTCMonth() + 1, dia = u.getUTCDate();
    var verao = false;
    if (mes > 3 && mes < 10) {
        verao = true;
    } else if (mes === 3) {
        var dm = UltimoDomingoDoMes(ano, 3);
        verao = (dia > dm) || (dia === dm && u.getUTCHours() >= 1);
    } else if (mes === 10) {
        var dO = UltimoDomingoDoMes(ano, 10);
        verao = (dia < dO) || (dia === dO && u.getUTCHours() < 1);
    }
    var e = new Date(agora + (verao ? 2 : 1) * 3600000);
    return { ano: e.getUTCFullYear(), mes: e.getUTCMonth() + 1, dia: e.getUTCDate() };
}

function EventoEstaAtivo(chave) {
    var ev = CALENDARIO_EVENTOS[chave];
    if (!ev) return true;                    // evento desconhecido: nao esconde o boss
    try {
        var h = ObterDataEuropa();
        var hoje = h.mes * 100 + h.dia;
        var janela = ev.padrao;
        for (var i = 0; i < ev.datas.length; i++) {
            if (ev.datas[i].ano === h.ano) { janela = ev.datas[i]; break; }
        }
        if (!janela) return false;
        var ini = janela.ini[0] * 100 + janela.ini[1];
        var fim = janela.fim[0] * 100 + janela.fim[1];
        return hoje >= ini && hoje <= fim;
    } catch (e) {
        return true;                         // se a data falhar, nao esconde nada
    }
}

// ---- Status do boss para o perfil ativo ----
// Retorna: "verde"   = pode enfrentar (inclusive sozinho)
//          "amarelo" = tem level, mas so com grupo
//          "vermelho"= nao pode (level baixo ou evento fora do periodo)
//          ""        = sem perfil/level valido (cor padrao)
// Entende textos como "120+ (em grupo) / 140+ (solo, bem equipado)", "140+ (em grupo)",
// "Qualquer nivel (em grupo)", "100/120+ (em grupo)" e "70+".
function StatusBossPerfil(item, perfil, ignorarEvento) {
    if (!item || !perfil) return "";
    var lv = Number(perfil.level);
    if (isNaN(lv)) return "";
    if (!ignorarEvento && item.evento && !EventoEstaAtivo(item.evento)) return "vermelho";

    var texto = String(item.level || item.reqLevel || item.nivel || "");
    var temGrupo = NormalizarTexto(texto).indexOf("grupo") !== -1;
    var primeiro = ExtrairLevelMinimo(texto);
    if (isNaN(primeiro)) primeiro = 0;               // "Qualquer nivel"

    var grupoMin = primeiro;
    var soloMin = primeiro;
    if (temGrupo) {
        soloMin = Infinity;                            // so com grupo
        // "120+ (em grupo) / 140+ (solo...)": o segundo numero e o level para ir sozinho
        var m = texto.match(/(\d+)\+?\s*\(\s*em grupo\s*\)\s*\/\s*(\d+)/i);
        if (m) { grupoMin = parseInt(m[1], 10); soloMin = parseInt(m[2], 10); }
    }

    if (lv < grupoMin) return "vermelho";
    if (lv >= soloMin) return "verde";
    return temGrupo ? "amarelo" : "verde";
}

function CorStatusBoss(status) {
    if (status === "verde") return "#4ADE80";
    if (status === "amarelo") return "#FFD600";
    if (status === "vermelho") return "#FF4D4D";
    return "";
}

// Sub boss herda a cor do boss que esta aberto (so se enfrenta entrando na batalha do boss).
function ObterBossParaCor(item) {
    var lista = DB_TIBIAME.Bosses || [];
    if (lista.indexOf(item) !== -1) return item;
    return bossAbertoAtual || item;
}

function ObterBossesParaPerfil(perfil) {
    var bosses = DB_TIBIAME.Bosses || [];
    var disponiveis = [];

    for (var i = 0; i < bosses.length; i++) {
        var b = bosses[i];
        var st = StatusBossPerfil(b, perfil);
        // verde e amarelo (so com grupo) continuam na lista dos que da pra enfrentar
        if (st === "verde" || st === "amarelo" || st === "") disponiveis.push(b);
    }
    return disponiveis;
}

function MontarHtmlGifBoss() {
    return "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width,initial-scale=1.0,user-scalable=no'>" +
           "<style>*{margin:0;padding:0;box-sizing:border-box;}html,body{width:100%;height:100%;background:transparent;display:flex;align-items:center;justify-content:center;overflow:hidden;}" +
           "img{width:100%;height:100%;object-fit:contain;}</style></head>" +
           "<body><img src='file:///android_asset/img/icones/gifboss.gif' onerror=\"this.src='img/icones/gifboss.gif';\"></body></html>";
}

function EscaparHtml(str) {
    if (str === null || str === undefined) return "";
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

// Nome exibido da categoria (a chave interna continua "Mobs").
function RotuloCat(cat) { return (cat === "Mobs") ? "Monstros" : cat; }

// Texto do painel com HTML simples (parte colorida). Se o Text nao aceitar HTML, cai para texto puro.
function ExibirTextoStatsHtml(html, textoPuro) {
    if (webInfoBoss) webInfoBoss.SetVisibility("Gone");
    if (txtInfo) {
        txtInfo.SetVisibility("Show");
        try { txtInfo.SetHtml(html); } catch (e) { txtInfo.SetText(textoPuro); }
    }
}

function ExibirTextoStats(texto, htmlBoss) {
    if (htmlBoss) {
        if (txtInfo) txtInfo.SetVisibility("Gone");
        if (webInfoBoss) {
            webInfoBoss.SetVisibility("Show");
            webInfoBoss.LoadHtml(htmlBoss);
        }
    } else {
        if (webInfoBoss) webInfoBoss.SetVisibility("Gone");
        if (txtInfo) {
            txtInfo.SetVisibility("Show");
            txtInfo.SetText(texto);
        }
    }
}

// Escapa o texto e pinta de amarelo os "??" (dado ainda desconhecido, como na wiki).
function DestacarInterrogacao(valor) {
    return EscaparHtml(valor).split("??").join("<span style='color:#FFD700;font-weight:bold;'>??</span>");
}


// ---------- Icones de elementos (Fisico, Fogo, Gelo, Raio, Sagrado) ----------
var ICONES_ELEMENTO = {
    "fisico": "hit.png",
    "fogo": "fire.png",
    "gelo": "ice.png",
    "raio": "light.png",
    "sagrado": "soul.png"
};

function ChaveElemento(txt) {
    return String(txt).replace(/^\s+|\s+$/g, "").toLowerCase()
        .replace(/[áàâã]/g, "a").replace(/[éê]/g, "e").replace(/í/g, "i")
        .replace(/[óô]/g, "o").replace(/ú/g, "u");
}

// Converte "Físico, Fogo e Gelo" em icone + nome de cada elemento.
// Se algum pedaco nao for um elemento (ex.: "A definir", "Varia por forma"), mostra o texto normal.
function MontarHtmlElementos(valor) {
    if (valor === null || valor === undefined || valor === "") return "";
    var partes = String(valor).split(/\s*,\s*|\s+e\s+/);
    var out = [];
    var todosElementos = true;
    for (var i = 0; i < partes.length; i++) {
        var arq = ICONES_ELEMENTO[ChaveElemento(partes[i])];
        if (!arq) { todosElementos = false; break; }
        out.push("<span class='el'><img data-n='" + arq + "' src='file:///android_asset/" + IMG_ELEMENTOS + arq +
                 "' onerror='EF(this)'>" + EscaparHtml(partes[i].replace(/^\s+|\s+$/g, "")) + "</span>");
    }
    if (!todosElementos) return EscaparHtml(valor);
    return out.join(" ");
}

// CSS + script (fallback de caminhos das imagens) usados no WebView de bosses e mobs.
function EstiloScriptElementos() {
    var base = IMG_ELEMENTOS;
    var alt = base.toUpperCase();
    return "<style>.el{display:inline-block;margin-right:7px;white-space:nowrap;}" +
           ".el img{width:15px;height:15px;vertical-align:middle;margin-right:2px;image-rendering:pixelated;}</style>" +
           "<script>var P=['file:///android_asset/" + base + "','" + base + "','file:///android_asset/" + alt + "','" + alt + "'];" +
           "function EF(i){var k=(+i.getAttribute('data-k')||0)+1;i.setAttribute('data-k',k);" +
           "if(k<P.length){i.src=P[k]+i.getAttribute('data-n');}else{i.style.display='none';}}</script>";
}

function MontarHtmlMobDetalhe(item, perfilAtivo) {
    var lvValor = item.level || "a definir";
    var atk = item["tipo de atk"] || "";
    var linhas = [
        "<div><b>" + EscaparHtml(item.nome) + " (Monstros)</b></div>",
        "<div>Level: " + EscaparHtml(lvValor) + " | HP: " + EscaparHtml(item.hp) + "</div>",
        "<div>XP: " + EscaparHtml(item.xp) + " | Gold: " + EscaparHtml(item.gold) + "</div>"
    ];
    if (atk) linhas.push("<div>Atk: " + MontarHtmlElementos(atk) + "</div>");
    linhas.push("<div>Fraqueza: " + MontarHtmlElementos(item.fraqueza) + "</div>");
    linhas.push("<div>Locais: " + EscaparHtml(item.locais) + "</div>");
    linhas.push("<div>Drops: " + EscaparHtml(item.drops) + "</div>");
    if (perfilAtivo) {
        var qtdMatar = CalcularMobsParaUpar(perfilAtivo.xpRestante, item.xp);
        if (qtdMatar !== null) {
            linhas.push("<div>Para upar (" + EscaparHtml(perfilAtivo.xpRestante) + " XP): matar " + qtdMatar + "x " + EscaparHtml(item.nome) + "</div>");
        }
    }
    return "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width,initial-scale=1.0,user-scalable=no'>" +
           "<style>*{margin:0;padding:0;box-sizing:border-box;}" +
           "html,body{width:100%;height:100%;background:transparent;color:#FFFFFF;" +
           "font-family:sans-serif;font-size:11.5px;line-height:1.32;overflow-y:auto;padding:2px 4px;}" +
           "div{word-wrap:break-word;}</style>" + EstiloScriptElementos() + "</head>" +
           "<body>" + linhas.join("") + "</body></html>";
}

function MontarHtmlBossDetalhe(item, perfilAtivo) {
    var recompBoss = ObterRecompensaBoss(item);
    var lvBossValor = item.level || "a definir";
    var reqNum = ExtrairLevelMinimo(lvBossValor);
    var corLv = "#FFFFFF";
    var avisoLv = "";

    var stDet = StatusBossPerfil(item, perfilAtivo, true);
    if (stDet === "vermelho") {
        corLv = CorStatusBoss(stDet);
        avisoLv = " (Level baixo para enfrentar)";
    } else if (stDet === "amarelo") {
        corLv = CorStatusBoss(stDet);
        avisoLv = " (Apenas em grupo)";
    } else if (stDet === "verde") {
        corLv = CorStatusBoss(stDet);
    }

    var linhas = [
        "<div><b>" + EscaparHtml(item.nome) + " (Bosses)</b></div>",
        "<div>Level: <span style='color:" + corLv + ";font-weight:bold;'>" + EscaparHtml(lvBossValor) + EscaparHtml(avisoLv) + "</span></div>",
        "<div>HP: " + DestacarInterrogacao(item.hp || "A definir") + "</div>",
        "<div>XP: " + EscaparHtml(item.xp || "A definir") + "</div>",
        "<div>Gold: " + EscaparHtml(item.gold !== undefined ? item.gold : "0") + "</div>",
        "<div>Ilha: " + EscaparHtml(item.ilha || item.local || "A definir") + "</div>",
        "<div>Itens dropados aleatoriamente: " + EscaparHtml(item.drops || "A definir") + "</div>",
        "<div>Recompensas do Boss: " + EscaparHtml(recompBoss) + "</div>"
    ];

    var extras = [];
    if (item.ataques) extras.push("<div>Ataques: " + MontarHtmlElementos(item.ataques) + "</div>");
    if (item.fraqueza) extras.push("<div>Fraqueza: " + MontarHtmlElementos(item.fraqueza) + "</div>");
    if (extras.length) linhas.splice.apply(linhas, [6, 0].concat(extras));   // logo depois da Ilha

    return "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width,initial-scale=1.0,user-scalable=no'>" +
           "<style>*{margin:0;padding:0;box-sizing:border-box;}" +
           "html,body{width:100%;height:100%;background:transparent;color:#FFFFFF;" +
           "font-family:sans-serif;font-size:11.5px;line-height:1.32;overflow-y:auto;padding:2px 4px;}" +
           "div{word-wrap:break-word;}</style>" + EstiloScriptElementos() + "</head>" +
           "<body>" + linhas.join("") + "</body></html>";
}

function OnStart() {
    CarregarPerfisStorage();

    var layRoot = app.CreateLayout("Frame", "FillXY");

    var layFundo = app.CreateLayout("Linear", "FillXY");
    layFundo.SetBackColor("#000000");
    try { layFundo.SetTouchable(false); } catch (e) {}
    layRoot.AddChild(layFundo);

    var layWall = app.CreateLayout("Linear", "FillXY,VCenter,HCenter");
    try { layWall.SetTouchable(false); } catch (e) {}
    var imgWall = app.CreateImage("Wallpaper/wallpaper.png", 0.75, -1);
    if (imgWall) {
        imgWall.SetAlpha(0.85);
        try { imgWall.SetTouchable(false); } catch (e) {}
        layWall.AddChild(imgWall);
    }
    layRoot.AddChild(layWall);

    var lay = app.CreateLayout("Linear", "Vertical,FillXY");
    lay.SetPadding(0.02, 0.02, 0.02, 0.015);

    var layTopo = app.CreateLayout("Linear", "Horizontal,FillX,VCenter");
    // Titulo estilizado (fonte serifada em italico/negrito, ouro com degrade e sombra)
    var webTitulo = app.CreateWebView(0.96, 0.075, "IgnoreErrors,NoScrollBars");
    webTitulo.SetBackColor("#00000000");
    try { webTitulo.SetTouchable(false); } catch (e) {}
    webTitulo.LoadHtml(
        "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width,initial-scale=1.0,user-scalable=no'>" +
        "<style>*{margin:0;padding:0;}" +
        "html,body{width:100%;height:100%;background:transparent;overflow:hidden;}" +
        "body{display:flex;align-items:center;}" +
        "h1{font-family:'Cinzel Decorative','Cinzel','Palatino Linotype',Palatino,Georgia,'Times New Roman',serif;" +
        "font-size:30px;font-weight:bold;font-style:italic;letter-spacing:2px;white-space:nowrap;" +
        "color:#FFD700;" +
        "background:linear-gradient(180deg,#FFF3A0 0%,#FFD700 45%,#B8860B 100%);" +
        "-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;" +
        "text-shadow:0 0 6px rgba(212,175,55,0.45);" +
        "filter:drop-shadow(1px 2px 1px rgba(0,0,0,0.9));}" +
        "</style></head><body><h1>TibiaME Tutor</h1></body></html>"
    );
    layTopo.AddChild(webTitulo);
    lay.AddChild(layTopo);

    var layAbas = app.CreateLayout("Linear", "Horizontal,FillX");
    layAbas.SetBackColor("#000000");

    var abasConfig = [
        { nome: "Tutor",  icone: "img/icones/tutor.png" },
        { nome: "Bosses", icone: "img/icones/bosses.png", gifAtivo: "img/icones/gifboss.gif" },
        { nome: "Mobs",   rotulo: "Monstros", icone: "img/icones/mobs.png" },
        { nome: "Itens",  icone: "img/icones/itens.png" },
        { nome: "Lojas",  icone: "img/icones/lojas.png" }
    ];

    botoesAbas = [];
    for (var i = 0; i < abasConfig.length; i++) {
        var cfg = abasConfig[i];

        var boxAba = app.CreateLayout("Linear", "Vertical,VCenter,HCenter");
        boxAba.SetSize(0.192, -1);
        boxAba.SetBackColor("#000000");
        boxAba.SetPadding(0.002, 0.006, 0.002, 0.006);
        boxAba.aba = cfg.nome;

        var barraBrilho = app.CreateText("", 0.16, 0.006);
        barraBrilho.SetBackColor("#000000");
        barraBrilho.SetMargins(0, 0.004, 0, 0);

        var aoTocar = function() {
            TrocarAba(this.aba);
        };
        boxAba.SetOnTouch(aoTocar);
        barraBrilho.aba = cfg.nome;
        barraBrilho.SetOnTouch(aoTocar);

        if (cfg.icone) {
            var imgAba = app.CreateImage(cfg.icone, 0.061, -1);
            imgAba.aba = cfg.nome;
            imgAba.SetOnTouch(aoTocar);
            boxAba.AddChild(imgAba);
            boxAba.imgAba = imgAba;
        }

        if (cfg.gifAtivo) {
            try {
                var webGifBoss = app.CreateWebView(0.083, 0.061, "IgnoreErrors,NoScrollBars");
                webGifBoss.SetBackColor("#00000000");
                webGifBoss.LoadHtml(MontarHtmlGifBoss());
                webGifBoss.SetVisibility("Gone");
                boxAba.AddChild(webGifBoss);
                boxAba.webGifBoss = webGifBoss;
            } catch (e) {
                boxAba.webGifBoss = null;
            }
        }

        var lblAba = app.CreateText(cfg.rotulo || cfg.nome, -1, -1);
        lblAba.SetTextSize(9.5);
        lblAba.SetTextColor("#FFD700");
        lblAba.aba = cfg.nome;
        lblAba.SetOnTouch(aoTocar);
        boxAba.AddChild(lblAba);

        boxAba.AddChild(barraBrilho);
        boxAba.barraBrilho = barraBrilho;

        layAbas.AddChild(boxAba);
        botoesAbas.push(boxAba);
    }
    lay.AddChild(layAbas);

    var layBusca = app.CreateLayout("Linear", "Horizontal,FillX,VCenter");
    edtBusca = app.CreateTextEdit("", 0.56, -1);
    edtBusca.SetHint("Pesquisar...");
    layBusca.AddChild(edtBusca);

    var boxBuscar = app.CreateLayout("Linear", "Horizontal,VCenter,HCenter");
    boxBuscar.SetSize(0.18, -1);
    boxBuscar.SetPadding(0.008, 0.006, 0.008, 0.006);
    boxBuscar.SetOnTouch(RodarBusca);
    var imgBuscar = app.CreateImage("img/icones/buscar.png", 0.065, -1);
    imgBuscar.SetOnTouch(RodarBusca);
    boxBuscar.AddChild(imgBuscar);
    layBusca.AddChild(boxBuscar);

    var boxLimpar = app.CreateLayout("Linear", "Horizontal,VCenter,HCenter");
    boxLimpar.SetSize(0.18, -1);
    boxLimpar.SetPadding(0.008, 0.006, 0.008, 0.006);
    boxLimpar.SetOnTouch(LimparBusca);
    var imgLimpar = app.CreateImage("img/icones/deletar.png", 0.065, -1);
    imgLimpar.SetOnTouch(LimparBusca);
    boxLimpar.AddChild(imgLimpar);
    layBusca.AddChild(boxLimpar);
    lay.AddChild(layBusca);

    boxStats = app.CreateLayout("Linear", "Vertical,FillX");
    boxStats.SetSize(0.94, -1);
    boxStats.SetMargins(0.01, 0.006, 0.01, 0.006);
    boxStats.SetBackColor("#120E04");
    boxStats.SetPadding(0.004, 0.004, 0.004, 0.004);
    try { boxStats.SetCornerRadius(6); } catch (e) {}
    try { boxStats.SetBackGradient("#1B1406", "#0D0A03"); } catch (e) {}

    bordaStatsTopo = app.CreateText("", 0.92, 0.004);
    bordaStatsTopo.SetBackColor("#D4AF37");
    bordaStatsTopo.SetMargins(0, 0, 0, 0.004);
    boxStats.AddChild(bordaStatsTopo);

    txtInfo = app.CreateText("Pronto. Escolha uma aba ou digite para buscar.", 0.90, -1, "Multiline,Left");
    txtInfo.SetTextColor("#FFFFFF");
    txtInfo.SetTextSize(13);
    txtInfo.SetPadding(0.01, 0.004, 0.01, 0.004);
    boxStats.AddChild(txtInfo);

    try {
        webInfoBoss = app.CreateWebView(0.90, 0.19, "IgnoreErrors,NoScrollBars");
        webInfoBoss.SetBackColor("#00000000");
        webInfoBoss.SetVisibility("Gone");
        boxStats.AddChild(webInfoBoss);
    } catch (e) {
        webInfoBoss = null;
    }

    bordaStatsBase = app.CreateText("", 0.92, 0.004);
    bordaStatsBase.SetBackColor("#D4AF37");
    bordaStatsBase.SetMargins(0, 0.004, 0, 0);
    boxStats.AddChild(bordaStatsBase);

    lay.AddChild(boxStats);

    scrLista = app.CreateScroller(0.96, 0.42);
    layLista = app.CreateLayout("Linear", "Vertical,FillX");
    layLista.SetPadding(0, 0, 0, 0.08);   // folga no fim: o ultimo item rola ate ficar livre do rodape
    scrLista.AddChild(layLista);
    lay.AddChild(scrLista);

    // Rodape ancorado no fim da tela: @DexterBCL (canto inferior esquerdo) e Sair (canto inferior direito)
    var layRodape = app.CreateLayout("Linear", "Horizontal,VCenter");
    layRodape.SetSize(1, 0.05);
    layRodape.SetMargins(0, 0.935, 0, 0);   // empurra so esta faixa para o fim da tela (nao cobre o resto)

    // --- Esquerda: @DexterBCL ---
    var boxCred = app.CreateLayout("Linear", "Horizontal,VCenter,Left");
    boxCred.SetSize(0.34, 0.05);
    boxCred.SetPadding(0.03, 0, 0, 0);
    var lblCreditos = app.CreateText("@DexterBCL", -1, -1);
    lblCreditos.SetTextSize(11);
    lblCreditos.SetTextColor("#9A9A9A");
    try { lblCreditos.SetFontFile("monospace"); } catch (e) {}
    lblCreditos.SetOnTouch(function(ev) {
        if (ev && ev.action === "Down") {
            this.SetTextColor("#FFD700");
        } else if (ev && ev.action === "Up") {
            this.SetTextColor("#9A9A9A");
            try {
                app.OpenUrl("https://discord.gg/5erpaxgRCq");
            } catch (e) {
                app.ShowPopup("Nao foi possivel abrir o link.");
            }
        } else if (ev && ev.action === "Cancel") {
            this.SetTextColor("#9A9A9A");
        }
    });
    boxCred.AddChild(lblCreditos);
    layRodape.AddChild(boxCred);

    // --- Espacador (empurra o Sair para a direita) ---
    var espRodape = app.CreateText("", 0.38, 0.05);
    try { espRodape.SetTouchable(false); } catch (e) {}
    layRodape.AddChild(espRodape);

    // --- Direita: Sair ---
    var boxSair = app.CreateLayout("Linear", "Horizontal,VCenter,Right");
    boxSair.SetSize(0.28, 0.05);
    boxSair.SetPadding(0, 0, 0.03, 0);
    var acaoSair = function() { app.Exit(); };
    boxSair.SetOnTouch(acaoSair);

    var imgSair = app.CreateImage("img/icones/sair.png", 0.045, -1);
    imgSair.SetMargins(0, 0, 0.012, 0);
    imgSair.SetOnTouch(acaoSair);
    boxSair.AddChild(imgSair);

    var lblSair = app.CreateText("Sair", -1, -1);
    lblSair.SetTextColor("#FF6B6B");
    lblSair.SetTextSize(12);
    lblSair.SetOnTouch(acaoSair);
    boxSair.AddChild(lblSair);
    layRodape.AddChild(boxSair);

    // Aviso "Carregando..." com sprite animada (4 quadros lado a lado em img/icones/carregando.png)
    lblCarregando = app.CreateLayout("Linear", "Vertical,VCenter,HCenter");
    lblCarregando.SetSize(1, 0.14);
    lblCarregando.SetMargins(0, 0.55, 0, 0);   // centro da area da lista
    var webCarregando = app.CreateWebView(1, 0.14, "IgnoreErrors,NoScrollBars");
    webCarregandoRef = webCarregando;
    webCarregando.SetBackColor("#00000000");
    try { webCarregando.SetTouchable(false); } catch (e) {}
    lblCarregando.AddChild(webCarregando);
    webCarregando.LoadHtml(
        "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width,initial-scale=1.0,user-scalable=no'>" +
        "<style>*{margin:0;padding:0;}html,body{width:100%;height:100%;background:transparent;overflow:hidden;}" +
        "body{display:flex;flex-direction:column;align-items:center;justify-content:center;}" +
        "canvas{width:74px;height:74px;image-rendering:pixelated;image-rendering:crisp-edges;}" +
        "#t{margin-top:4px;font-family:'Palatino Linotype',Palatino,Georgia,serif;font-weight:bold;font-size:18px;" +
        "color:#FFD700;text-shadow:1px 2px 2px #000;white-space:nowrap;}</style></head><body>" +
        "<canvas id='c' width='37' height='37'></canvas>" +
        "<div id='t'>Carregando<span id='d'></span></div>" +
        "<script>" +
        "var P=['file:///android_asset/img/icones/carregando.png','img/icones/carregando.png'," +
        "'file:///android_asset/IMG/icones/carregando.png','IMG/icones/carregando.png'];" +
        "var c=document.getElementById('c'),x=c.getContext('2d'),img=new Image(),k=0,f=0,n=4;" +
        "x.imageSmoothingEnabled=false;" +
        "function tenta(){if(k>=P.length){c.style.display='none';return;}img.src=P[k++];}" +
        "img.onerror=tenta;" +
        "img.onload=function(){var h=img.height||37;n=Math.max(1,Math.round(img.width/h));c.width=h;c.height=h;" +
        "x.imageSmoothingEnabled=false;" +
        "var ok=true;setInterval(function(){x.clearRect(0,0,h,h);x.drawImage(img,f*h,0,h,h,0,0,h,h);" +
        "if(ok){try{var D=x.getImageData(0,0,h,h),A=D.data;for(var i=0;i<A.length;i+=4){" +
        "if(Math.abs(A[i]-18)<9&&Math.abs(A[i+1]-27)<9&&Math.abs(A[i+2]-25)<9)A[i+3]=0;}x.putImageData(D,0,0);}catch(e){ok=false;}}" +
        "f=(f+1)%n;},140);};" +
        "tenta();" +
        "var d=document.getElementById('d'),q=0;setInterval(function(){q=(q+1)%4;d.textContent='...'.substring(0,q);},350);" +
        "</script></body></html>"
    );
    lblCarregando.SetVisibility("Gone");

    layRoot.AddChild(lay);
    layRoot.AddChild(lblCarregando);
    layRoot.AddChild(layRodape);
    app.AddLayout(layRoot);
    TrocarAba("Tutor");
}

function AtualizarDestaqueAbas(abaAtiva) {
    for (var i = 0; i < botoesAbas.length; i++) {
        var itemAba = botoesAbas[i];
        var selecionada = (itemAba.aba === abaAtiva);

        itemAba.SetBackColor(selecionada ? "#4A3700" : "#000000");

        if (itemAba.barraBrilho) {
            itemAba.barraBrilho.SetBackColor(selecionada ? "#FFF08A" : "#000000");
        }

        if (itemAba.webGifBoss) {
            if (selecionada) {
                if (itemAba.imgAba) itemAba.imgAba.SetVisibility("Gone");
                itemAba.webGifBoss.SetVisibility("Show");
            } else {
                itemAba.webGifBoss.SetVisibility("Gone");
                if (itemAba.imgAba) itemAba.imgAba.SetVisibility("Show");
            }
        }
    }
}

// Evita o "carregamento linha por linha": a lista fica oculta enquanto os botoes sao
// recriados e so aparece pronta, de uma vez (o show roda logo apos a montagem terminar).
var lblCarregando = null;
var webCarregandoRef = null;
var carregandoVisivel = false;

// O WebView da sprite deixa um "fantasma" na tela quando vira Gone (aparece nas frestas entre os botoes).
// Por isso o conteudo e apagado primeiro e so depois o WebView e escondido.
function MostrarCarregando() {
    carregandoVisivel = true;
    try { if (webCarregandoRef) webCarregandoRef.Execute("document.body.style.visibility='visible'"); } catch (e) {}
    try { if (lblCarregando) lblCarregando.SetVisibility("Show"); } catch (e) {}
}
function OcultarCarregando() {
    carregandoVisivel = false;
    try { if (webCarregandoRef) webCarregandoRef.Execute("document.body.style.visibility='hidden'"); } catch (e) {}
    setTimeout(OcultarCarregandoFinal, 120);
}
function OcultarCarregandoFinal() {
    if (carregandoVisivel) return;   // voltou a carregar nesse meio tempo
    try { if (lblCarregando) lblCarregando.SetVisibility("Gone"); } catch (e) {}
}

// Controle do "Carregando": a sprite so some quando TODAS as imagens da lista terminaram de carregar
// e a lista ja foi exibida e desenhada por um instante (evita o visual "bugado" da transicao).
var pendImgLista = 0;          // imagens de botoes ainda carregando
var aguardaMostrar = false;    // ja existe uma espera em andamento
var tokenMostrarAtual = 0;
var inicioEsperaLista = 0;
var LIMITE_IMG_MS = 1500;      // seguranca: nunca prende a tela de carregamento para sempre
var ASSENTA_LISTA_MS = 200;    // lista visivel por tras da sprite antes de a sprite sumir

// Handler GLOBAL (sem closure): chamado por cada imagem de botao quando termina de carregar.
function ImgListaCarregou() {
    if (pendImgLista > 0) pendImgLista--;
}

function MostrarScrLista() {
    if (filaLista && filaLista.token === tokenLista) return;   // ainda montando: o ultimo lote chama de novo
    if (aguardaMostrar) return;
    aguardaMostrar = true;
    tokenMostrarAtual = tokenLista;
    inicioEsperaLista = Date.now();
    setTimeout(VerificarListaPronta, 30);
}

function VerificarListaPronta() {
    if (tokenMostrarAtual !== tokenLista) return;               // troca de tela: descarta esta espera
    if (filaLista && filaLista.token === tokenLista) { setTimeout(VerificarListaPronta, 30); return; }
    if (pendImgLista > 0 && (Date.now() - inicioEsperaLista) < LIMITE_IMG_MS) {
        setTimeout(VerificarListaPronta, 30);                   // ainda ha imagens carregando
        return;
    }
    // tudo carregado: mostra a lista por baixo e so depois remove a sprite
    try { if (scrLista) scrLista.SetVisibility("Show"); } catch (e) {}
    setTimeout(EsconderCarregando, ASSENTA_LISTA_MS);
}

function EsconderCarregando() {
    if (tokenMostrarAtual !== tokenLista) return;
    aguardaMostrar = false;
    OcultarCarregando();
}

function LimparBotoes() {
    wikiCtx = null;   // qualquer troca de tela descarta resposta pendente da wiki
    tokenLista++;     // cancela montagem em lotes que ainda esteja pendente
    filaLista = null;
    pendImgLista = 0;
    aguardaMostrar = false;
    try { if (scrLista) scrLista.SetVisibility("Hide"); } catch (e) {}
    MostrarCarregando();
    setTimeout(MostrarScrLista, 0);
    for (var i = 0; i < botoesLista.length; i++) {
        try { layLista.RemoveChild(botoesLista[i]); } catch (e) {}
    }
    botoesLista = [];
    try {
        if (scrLista) scrLista.ScrollTo(0, 0);
    } catch (e) {}
}

function LimparBusca() {
    if (edtBusca) edtBusca.SetText("");
    paginaMob = 0;
    paginaBoss = 0;
    paginaItem = 0;
    paginaTutorLista = 0;
    itemSelecionado = null;
    catSelecionada = null;
    bossAbertoAtual = null;
    if (abaAtual === "Tutor") {
        tutorModo = "auto";
    }
    TrocarAba(abaAtual);
}

function TrocarAba(nome) {
    abaAtual = nome;
    AtualizarDestaqueAbas(nome);
    paginaMob = 0;
    paginaBoss = 0;
    paginaItem = 0;
    paginaTutorLista = 0;
    itemSelecionado = null;
    catSelecionada = null;
    bossAbertoAtual = null;
    LimparBotoes();

    var termo = edtBusca ? edtBusca.GetText().trim() : "";

    if (nome == "Tutor") {
        if (termo) {
            PesquisarTutor(termo);
        } else {
            AbrirMenuTutor();
        }
        return;
    }

    var lista = DB_TIBIAME[nome] || [];
    var filtrada = Filtrar(lista, termo);
    MostrarLista(nome, filtrada, termo);
}

// ==========================================
// INTERFACE E FLUXO DO MENU TUTOR
// ==========================================
// IMPORTANTE (DroidScript): handlers de toque NAO podem depender de variaveis do closure.
// Funcoes anonimas com o mesmo codigo-fonte sao reaproveitadas pelo DroidScript, entao todos os
// botoes acabavam executando a acao do ULTIMO botao criado. Por isso os handlers abaixo sao
// globais/nomeados e leem os dados do proprio botao tocado (this).
function ObterAlvoToque(ctx, ev, prop) {
    if (ctx && ctx[prop] !== undefined) return ctx;
    if (ev && ev.source && ev.source[prop] !== undefined) return ev.source;
    return ctx;
}

// Aceita so o "Down" (ou evento sem action) e aplica debounce, para o botao nao disparar
// duas vezes (Down + Up) e pular paginas ou repetir acoes.
function ToqueDeBotaoValido(ev) {
    if (ev && ev.action && ev.action !== "Down") return false;
    var agora = Date.now ? Date.now() : (new Date()).getTime();
    if (agora - bloqueioCliqueItem < 160) return false;
    bloqueioCliqueItem = agora;
    return true;
}

function CliqueAcaoTutor(ev) {
    if (ev && ev.action && ev.action !== "Down") return;
    var agora = Date.now ? Date.now() : (new Date()).getTime();
    if (agora - bloqueioCliqueItem < 160) return;
    bloqueioCliqueItem = agora;
    var alvo = ObterAlvoToque(this, ev, "acaoTutor");
    if (alvo && alvo.acaoTutor) alvo.acaoTutor.call(alvo, ev);
}

function CriarBotaoAcaoTutor(texto, corFundo, corTexto, corBorda, callback) {
    var box = app.CreateLayout("Linear", "Vertical,VCenter,HCenter");
    box.SetSize(0.92, -1);
    box.SetMargins(0, 0.003, 0, 0.003);
    box.SetBackColor(corFundo || "#161A1E");
    box.SetPadding(0.008, 0.007, 0.008, 0.005);

    var lbl = app.CreateText(texto, 0.90, -1, "Center");
    lbl.SetTextSize(10.5);
    lbl.SetTextColor(corTexto || "#FFFFFF");

    var filete = app.CreateText("", 0.80, 0.003);
    filete.SetBackColor(corBorda || corFundo || "#161A1E");
    filete.SetMargins(0, 0.003, 0, 0);

    box.acaoTutor = callback;
    lbl.acaoTutor = callback;
    filete.acaoTutor = callback;
    box.SetOnTouch(CliqueAcaoTutor);
    lbl.SetOnTouch(CliqueAcaoTutor);
    filete.SetOnTouch(CliqueAcaoTutor);

    box.AddChild(lbl);
    box.AddChild(filete);
    return box;
}

function AbrirMenuTutor() {
    LimparBotoes();
    itemSelecionado = null;
    catSelecionada = null;

    var perfil = ObterPerfilAtivo();

    if (tutorModo === "auto") {
        if (!perfil) {
            IniciarFormularioPersonagem(false);
            return;
        } else {
            MostrarPainelTutor();
            return;
        }
    }

    if (tutorModo === "criar") {
        RenderizarFormularioPersonagem(false);
    } else if (tutorModo === "editar") {
        RenderizarFormularioPersonagem(true);
    } else if (tutorModo === "perfis") {
        MostrarGerenciadorPerfis();
    } else if (tutorModo === "mobs" || tutorModo === "armas" || tutorModo === "bosses") {
        MostrarSubListaTutor(tutorModo);
    } else {
        if (perfil) {
            MostrarPainelTutor();
        } else {
            IniciarFormularioPersonagem(false);
        }
    }
}

function IniciarFormularioPersonagem(ehEdicao) {
    if (!ehEdicao && perfisSalvos.length >= MAX_PERFIS) {
        tutorModo = "perfis";
        MostrarGerenciadorPerfis();
        app.ShowPopup("Limite de 5 personagens atingido! Apague um para criar novo.");
        return;
    }

    if (ehEdicao) {
        var atual = ObterPerfilAtivo();
        if (!atual) {
            IniciarFormularioPersonagem(false);
            return;
        }
        tutorModo = "editar";
        formClasse = atual.classe;
        formNome = atual.nome || ("Personagem " + (perfilAtivoIndex + 1));
        formLevel = String(atual.level);
        formXp = String(atual.xpRestante);
    } else {
        tutorModo = "criar";
        formClasse = "";
        formNome = "Personagem " + (perfisSalvos.length + 1);
        formLevel = "";
        formXp = "";
    }

    RenderizarFormularioPersonagem(ehEdicao);
}

function CapturarCamposFormulario() {
    try {
        if (formEdtLv) formLevel = formEdtLv.GetText().trim();
        if (formEdtXp) formXp = formEdtXp.GetText().trim();
        if (formEdtNome) formNome = formEdtNome.GetText().trim();
    } catch (e) {}
}

// ==========================================
// ICONES DE CLASSE (Warrior = Guerreiro.png | Wizard = Mago.png)
// ==========================================
function CaminhoIconeClasse(classe) {
    var c = NormalizarTexto(classe || "");
    if (c.indexOf("warrior") !== -1 || c.indexOf("guerreiro") !== -1) return "img/icones/Guerreiro.png";
    if (c.indexOf("wizard") !== -1 || c.indexOf("mago") !== -1) return "img/icones/Mago.png";
    return null;
}

// Retorna a imagem da classe (ou null se a classe/arquivo nao existir).
function CriarIconeClasse(classe, largura) {
    var caminho = CaminhoIconeClasse(classe);
    if (!caminho) return null;
    try {
        var img = app.CreateImage(caminho, largura, -1);
        try { img.SetTouchable(false); } catch (e) {}
        return img;
    } catch (e) {
        return null;
    }
}

// Botao de escolha de classe: icone + nome. Handlers globais leem classeValor do proprio objeto.
function CriarBotaoClasse(classe, selecionada) {
    var box = app.CreateLayout("Linear", "Horizontal,VCenter,HCenter");
    box.SetSize(0.44, -1);
    box.SetBackColor(selecionada ? "#4A3700" : "#1B2228");
    box.SetPadding(0.01, 0.008, 0.01, 0.008);
    box.classeValor = classe;
    box.SetOnTouch(ClasseClick);

    var objs = [];
    var icone = CriarIconeClasse(classe, 0.1);
    if (icone) {
        icone.SetMargins(0, 0, 0.015, 0);
        icone.classeValor = classe;
        icone.SetOnTouch(ClasseClick);
        box.AddChild(icone);
    }

    var lbl = app.CreateText(classe, -1, -1);
    lbl.SetTextSize(12);
    lbl.SetTextColor(selecionada ? "#FFD700" : "#FFFFFF");
    lbl.classeValor = classe;
    lbl.SetOnTouch(ClasseClick);
    box.AddChild(lbl);
    return box;
}

// Cartao do perfil ativo no menu Tutor: icone grande + classe e level.
function CriarCartaoClasse(perfil) {
    var box = app.CreateLayout("Linear", "Horizontal,VCenter,Left");
    box.SetSize(0.92, -1);
    box.SetMargins(0, 0.003, 0, 0.003);
    box.SetBackColor("#1B1606");
    box.SetPadding(0.015, 0.008, 0.015, 0.008);

    var icone = CriarIconeClasse(perfil.classe, 0.14);
    if (icone) {
        icone.SetMargins(0, 0, 0.025, 0);
        box.AddChild(icone);
    }

    var col = app.CreateLayout("Linear", "Vertical,VCenter,Left");
    var lc = app.CreateText(perfil.classe, -1, -1, "Left");
    lc.SetTextSize(16);
    lc.SetTextColor("#FFD700");
    col.AddChild(lc);
    var ll = app.CreateText("Level " + perfil.level, -1, -1, "Left");
    ll.SetTextSize(12);
    ll.SetTextColor("#E6EEF3");
    col.AddChild(ll);
    box.AddChild(col);
    return box;
}

// Handler GLOBAL dos botoes Warrior/Wizard: le a classe do proprio botao e os campos das globais.
function ClasseClick(ev) {
    if (!ToqueDeBotaoValido(ev)) return;
    var alvo = ObterAlvoToque(this, ev, "classeValor");
    var classe = alvo ? alvo.classeValor : undefined;
    if (!classe) return;
    CapturarCamposFormulario();
    formClasse = classe;
    RenderizarFormularioPersonagem(formEhEdicao);
}

function RenderizarFormularioPersonagem(ehEdicao) {
    LimparBotoes();
    AjustarEscalaEFonteStats("", "");

    var tituloCab = ehEdicao ? "ATUALIZAR PERSONAGEM" : "NOVO PERSONAGEM (" + (perfisSalvos.length + 1) + "/" + MAX_PERFIS + ")";
    var resumoForm = tituloCab + "\n";
    resumoForm += "1. Classe: " + (formClasse ? formClasse : "[Escolha abaixo]") + "\n";
    resumoForm += "2. Level: " + (formLevel ? formLevel : "[Aguardando]") + " | XP p/ upar: " + (formXp ? formXp : "[Aguardando]");
    ExibirTextoStats(resumoForm, null);

    var lblClasse = app.CreateText("Escolha sua classe:", 0.92, -1, "Left");
    lblClasse.SetTextColor("#FFD700");
    lblClasse.SetTextSize(11);
    lblClasse.SetMargins(0, 0.002, 0, 0.002);
    layLista.AddChild(lblClasse);
    botoesLista.push(lblClasse);

    var layClasses = app.CreateLayout("Linear", "Horizontal,FillX,HCenter");
    layClasses.SetMargins(0, 0.002, 0, 0.004);

    formEhEdicao = ehEdicao;
    formEdtNome = null;
    formEdtLv = null;
    formEdtXp = null;

    layClasses.AddChild(CriarBotaoClasse("Warrior", formClasse === "Warrior"));

    var espaco = app.CreateText("", 0.04, -1);
    layClasses.AddChild(espaco);

    layClasses.AddChild(CriarBotaoClasse("Wizard", formClasse === "Wizard"));

    layLista.AddChild(layClasses);
    botoesLista.push(layClasses);

    if (formClasse === "Warrior" || formClasse === "Wizard") {
        var layNome = app.CreateLayout("Linear", "Horizontal,FillX,VCenter");
        var lblNome = app.CreateText("Nome do perfil:", 0.36, -1, "Left");
        lblNome.SetTextColor("#CCCCCC");
        lblNome.SetTextSize(10);
        layNome.AddChild(lblNome);

        formEdtNome = app.CreateTextEdit(formNome, 0.56, -1, "SingleLine");
        formEdtNome.SetTextSize(10.5);
        formEdtNome.SetHint("Ex: Meu " + formClasse);
        layNome.AddChild(formEdtNome);
        layLista.AddChild(layNome);
        botoesLista.push(layNome);

        var lblLv = app.CreateText("Qual seu level?", 0.92, -1, "Left");
        lblLv.SetTextColor("#FFD700");
        lblLv.SetTextSize(11);
        lblLv.SetMargins(0, 0.003, 0, 0.001);
        layLista.AddChild(lblLv);
        botoesLista.push(lblLv);

        formEdtLv = app.CreateTextEdit(formLevel, 0.92, -1, "Number,SingleLine");
        formEdtLv.SetTextSize(11);
        formEdtLv.SetHint("Digite seu level atual (ex: 25)");
        layLista.AddChild(formEdtLv);
        botoesLista.push(formEdtLv);

        var lblXp = app.CreateText("Xp para o próximo nível", 0.92, -1, "Left");
        lblXp.SetTextColor("#FFD700");
        lblXp.SetTextSize(11);
        lblXp.SetMargins(0, 0.003, 0, 0.001);
        layLista.AddChild(lblXp);
        botoesLista.push(lblXp);

        formEdtXp = app.CreateTextEdit(formXp, 0.92, -1, "Number,SingleLine");
        formEdtXp.SetTextSize(11);
        formEdtXp.SetHint("Digite quanto de XP falta (ex: 4500)");
        layLista.AddChild(formEdtXp);
        botoesLista.push(formEdtXp);

        var btnSalvar = CriarBotaoAcaoTutor(
            ehEdicao ? "SALVAR ALTERAÇÕES" : "SALVAR PERSONAGEM",
            "#1B4332",
            "#A8F5C8",
            "#52B788",
            function() {
                if (!formEdtLv || !formEdtXp || !formEdtNome) return;
                var ehEdicaoAtual = formEhEdicao;
                var lvVal = ExtrairNumero(formEdtLv.GetText());
                var xpVal = ExtrairNumero(formEdtXp.GetText());
                var nomeVal = formEdtNome.GetText().trim();

                if (!formClasse) {
                    app.ShowPopup("Escolha sua classe: Warrior ou Wizard.");
                    return;
                }
                if (isNaN(lvVal) || lvVal < 1) {
                    app.ShowPopup("Informe um level válido (maior que 0).");
                    return;
                }
                if (isNaN(xpVal) || xpVal < 1) {
                    app.ShowPopup("Informe o XP para o próximo nível.");
                    return;
                }
                if (!nomeVal) {
                    nomeVal = formClasse + " Lv." + lvVal;
                }

                var objPerfil = {
                    nome: nomeVal,
                    classe: formClasse,
                    level: lvVal,
                    xpRestante: xpVal
                };

                if (ehEdicaoAtual && perfilAtivoIndex >= 0 && perfilAtivoIndex < perfisSalvos.length) {
                    perfisSalvos[perfilAtivoIndex] = objPerfil;
                } else {
                    if (perfisSalvos.length >= MAX_PERFIS) {
                        app.ShowPopup("Limite de 5 personagens atingido! Apague um primeiro.");
                        return;
                    }
                    perfisSalvos.push(objPerfil);
                    perfilAtivoIndex = perfisSalvos.length - 1;
                }

                SalvarPerfisStorage();
                tutorModo = "painel";
                app.ShowPopup("Personagem salvo com sucesso!");
                MostrarPainelTutor();
            }
        );
        layLista.AddChild(btnSalvar);
        botoesLista.push(btnSalvar);
    }

    if (perfisSalvos.length > 0) {
        var btnVoltar = CriarBotaoAcaoTutor(
            "Voltar ao Painel / Perfis",
            "#25282C",
            "#CCCCCC",
            "#555555",
            function() {
                tutorModo = ObterPerfilAtivo() ? "painel" : "perfis";
                AbrirMenuTutor();
            }
        );
        layLista.AddChild(btnVoltar);
        botoesLista.push(btnVoltar);
    }
}

function MostrarPainelTutor() {
    LimparBotoes();
    itemSelecionado = null;
    catSelecionada = null;
    tutorModo = "painel";

    var perfil = ObterPerfilAtivo();
    if (!perfil) {
        IniciarFormularioPersonagem(false);
        return;
    }

    var mobsRec = ObterMobsParaNivel(perfil);
    var armasRec = ObterItensUteisParaPerfil(perfil);
    var bossesRec = ObterBossesParaPerfil(perfil);

    AjustarEscalaEFonteStats("", "");
    var vCh = perfil.nome + " (" + (perfilAtivoIndex + 1) + "/" + MAX_PERFIS + ")";
    var vXp = perfil.xpRestante + " EP";
    var vRec = mobsRec.length + " Monstros | " + armasRec.length + " Itens | " + bossesRec.length + " Bosses";
    var infoPuro = "Char: " + vCh + "\nXP p/ próximo nível: " + vXp + "\nRecomendados: " + vRec;
    var cV = "#FFE082";   // amarelo claro dos valores
    var infoHtml = "Char: <font color='" + cV + "'>" + EscaparHtml(vCh) + "</font><br>" +
                   "XP p/ próximo nível: <font color='" + cV + "'>" + EscaparHtml(vXp) + "</font><br>" +
                   "Recomendados: <font color='" + cV + "'>" + EscaparHtml(vRec) + "</font>";
    ExibirTextoStatsHtml(infoHtml, infoPuro);

    var cartaoClasse = CriarCartaoClasse(perfil);
    layLista.AddChild(cartaoClasse);
    botoesLista.push(cartaoClasse);

    var btnMobs = CriarBotaoAcaoTutor(
        "Monstros para meu Level (" + mobsRec.length + ")",
        "#162635",
        "#A8F2FF",
        "#4CC9F0",
        function() {
            paginaTutorLista = 0;
            MostrarSubListaTutor("mobs");
        }
    );
    layLista.AddChild(btnMobs);
    botoesLista.push(btnMobs);

    var btnArmas = CriarBotaoAcaoTutor(
        "Itens úteis para " + perfil.classe + " Lv." + perfil.level + " (" + armasRec.length + ")",
        "#2A1F0D",
        "#FFE082",
        "#D4AF37",
        function() {
            paginaTutorLista = 0;
            MostrarSubListaTutor("armas");
        }
    );
    layLista.AddChild(btnArmas);
    botoesLista.push(btnArmas);

    var btnBosses = CriarBotaoAcaoTutor(
        "Bosses que consigo enfrentar (" + bossesRec.length + ")",
        "#2B1216",
        "#FF9AA2",
        "#E63946",
        function() {
            paginaTutorLista = 0;
            MostrarSubListaTutor("bosses");
        }
    );
    layLista.AddChild(btnBosses);
    botoesLista.push(btnBosses);

    var layGerenciar = app.CreateLayout("Linear", "Horizontal,FillX,HCenter");
    layGerenciar.SetMargins(0, 0.004, 0, 0.002);

    var btnEditar = app.CreateButton("Atualizar Dados", 0.45, -1);
    btnEditar.SetTextSize(10.5);
    btnEditar.SetBackColor("#1F3A2E");
    btnEditar.SetTextColor("#A8F5C8");
    btnEditar.SetOnTouch(function(ev) {
        if (!ToqueDeBotaoValido(ev)) return;
        IniciarFormularioPersonagem(true);
    });
    layGerenciar.AddChild(btnEditar);

    var esp = app.CreateText("", 0.02, -1);
    layGerenciar.AddChild(esp);

    var btnPerfis = app.CreateButton("Perfis (" + perfisSalvos.length + "/" + MAX_PERFIS + ")", 0.45, -1);
    btnPerfis.SetTextSize(10.5);
    btnPerfis.SetBackColor("#2B2410");
    btnPerfis.SetTextColor("#FFD700");
    btnPerfis.SetOnTouch(function(ev) {
        if (!ToqueDeBotaoValido(ev)) return;
        tutorModo = "perfis";
        MostrarGerenciadorPerfis();
    });
    layGerenciar.AddChild(btnPerfis);

    layLista.AddChild(layGerenciar);
    botoesLista.push(layGerenciar);
}

function SelecionarPerfilClick(ev) {
    if (!ToqueDeBotaoValido(ev)) return;
    var alvo = ObterAlvoToque(this, ev, "idxPerfil");
    var idx = alvo ? alvo.idxPerfil : undefined;
    if (idx === undefined || idx < 0 || idx >= perfisSalvos.length) return;
    perfilAtivoIndex = idx;
    SalvarPerfisStorage();
    tutorModo = "painel";
    app.ShowPopup("Perfil selecionado: " + perfisSalvos[idx].nome);
    MostrarPainelTutor();
}

function ApagarPerfilClick(ev) {
    if (!ToqueDeBotaoValido(ev)) return;
    var alvo = ObterAlvoToque(this, ev, "idxPerfil");
    var idx = alvo ? alvo.idxPerfil : undefined;
    if (idx === undefined || idx < 0 || idx >= perfisSalvos.length) return;

    // Pede confirmacao antes de apagar (handler global; o indice fica em perfilParaApagar).
    perfilParaApagar = idx;
    try {
        var dlg = app.CreateYesNoDialog(
            "Apagar o personagem \"" + perfisSalvos[idx].nome + "\"?\nEsta acao nao pode ser desfeita."
        );
        dlg.SetOnTouch(RespostaApagarPerfil);
        dlg.Show();
    } catch (e) {
        // Se o dialogo nao puder ser criado, mantem o comportamento antigo.
        perfilParaApagar = -1;
        ExecutarApagarPerfil(idx);
    }
}

function RespostaApagarPerfil(resposta) {
    var idx = perfilParaApagar;
    perfilParaApagar = -1;
    if (resposta === "Yes") ExecutarApagarPerfil(idx);
}

function ExecutarApagarPerfil(idx) {
    if (idx === undefined || idx < 0 || idx >= perfisSalvos.length) return;
    perfisSalvos.splice(idx, 1);
    if (perfisSalvos.length === 0) {
        perfilAtivoIndex = -1;
    } else if (idx < perfilAtivoIndex) {
        perfilAtivoIndex--;            // mantem o MESMO personagem ativo
    } else if (perfilAtivoIndex >= perfisSalvos.length) {
        perfilAtivoIndex = perfisSalvos.length - 1;
    }
    SalvarPerfisStorage();
    app.ShowPopup("Personagem removido.");
    if (perfisSalvos.length === 0) {
        IniciarFormularioPersonagem(false);
    } else {
        MostrarGerenciadorPerfis();
    }
}

function MostrarGerenciadorPerfis() {
    LimparBotoes();
    itemSelecionado = null;
    catSelecionada = null;
    tutorModo = "perfis";

    AjustarEscalaEFonteStats("", "");
    var avisoLimite = perfisSalvos.length >= MAX_PERFIS
        ? "\nLimite máximo de 5 perfis atingido! Apague um perfil para criar outro."
        : "\nToque em um perfil para selecionar ou crie um novo:";
    ExibirTextoStats("PERSONAGENS SALVOS (" + perfisSalvos.length + "/" + MAX_PERFIS + ")" + avisoLimite, null);

    for (var i = 0; i < perfisSalvos.length; i++) {
        (function(idx) {
            var p = perfisSalvos[idx];
            var ativo = (idx === perfilAtivoIndex);

            var layLinha = app.CreateLayout("Linear", "Horizontal,FillX,VCenter");
            layLinha.SetMargins(0, 0.003, 0, 0.003);

            var prefixo = ativo ? "★ " : "• ";
            var iconePerfil = CriarIconeClasse(p.classe, 0.075);
            var larguraSel = 0.72;
            if (iconePerfil) {
                iconePerfil.SetMargins(0, 0, 0.01, 0);
                layLinha.AddChild(iconePerfil);
                larguraSel = 0.635;
            }
            var btnSel = app.CreateButton(prefixo + p.nome + " (" + p.classe + " Lv." + p.level + ")", larguraSel, -1);
            btnSel.SetTextSize(10);
            btnSel.SetBackColor(ativo ? "#4A3700" : "#161A1E");
            btnSel.SetTextColor(ativo ? "#FFD700" : "#E6EEF3");
            btnSel.idxPerfil = idx;
            btnSel.SetOnTouch(SelecionarPerfilClick);
            layLinha.AddChild(btnSel);

            var esp = app.CreateText("", 0.02, -1);
            layLinha.AddChild(esp);

            var btnDel = app.CreateButton("Apagar", 0.18, -1);
            btnDel.SetTextSize(9.5);
            btnDel.SetBackColor("#4A1212");
            btnDel.SetTextColor("#FF9AA2");
            btnDel.idxPerfil = idx;
            btnDel.SetOnTouch(ApagarPerfilClick);
            layLinha.AddChild(btnDel);

            layLista.AddChild(layLinha);
            botoesLista.push(layLinha);
        })(i);
    }

    if (perfisSalvos.length < MAX_PERFIS) {
        var btnNovo = CriarBotaoAcaoTutor(
            "+ Criar Novo Personagem (" + perfisSalvos.length + "/" + MAX_PERFIS + ")",
            "#1B4332",
            "#A8F5C8",
            "#52B788",
            function() {
                IniciarFormularioPersonagem(false);
            }
        );
        layLista.AddChild(btnNovo);
        botoesLista.push(btnNovo);
    } else {
        var lblCheio = app.CreateText("Para criar um novo perfil, apague um dos 5 personagens acima.", 0.92, -1, "Center");
        lblCheio.SetTextColor("#FF9AA2");
        lblCheio.SetTextSize(9.5);
        lblCheio.SetMargins(0, 0.004, 0, 0.004);
        layLista.AddChild(lblCheio);
        botoesLista.push(lblCheio);
    }

    if (ObterPerfilAtivo()) {
        var btnVoltar = CriarBotaoAcaoTutor(
            "Voltar ao Painel do Tutor",
            "#25282C",
            "#CCCCCC",
            "#555555",
            function() {
                tutorModo = "painel";
                MostrarPainelTutor();
            }
        );
        layLista.AddChild(btnVoltar);
        botoesLista.push(btnVoltar);
    }
}

// Handlers GLOBAIS da paginacao do Tutor: leem tutorModo/subListaAtual em vez de usar closure.
function SubListaAnteriorClick(ev) {
    if (!ToqueDeBotaoValido(ev)) return;
    if (paginaTutorLista > 0) {
        paginaTutorLista--;
        MostrarSubListaTutor(tutorModo);
    }
}
function SubListaProximaClick(ev) {
    if (!ToqueDeBotaoValido(ev)) return;
    var total = Math.max(1, Math.ceil(subListaAtual.length / itensPorPaginaTutor));
    if ((paginaTutorLista + 1) < total) {
        paginaTutorLista++;
        MostrarSubListaTutor(tutorModo);
    }
}

function SubListaPrimeiraClick(ev) {
    if (!ToqueDeBotaoValido(ev)) return;
    if (paginaTutorLista > 0) {
        paginaTutorLista = 0;
        MostrarSubListaTutor(tutorModo);
    }
}
function SubListaUltimaClick(ev) {
    if (!ToqueDeBotaoValido(ev)) return;
    var total = Math.max(1, Math.ceil(subListaAtual.length / itensPorPaginaTutor));
    if ((paginaTutorLista + 1) < total) {
        paginaTutorLista = total - 1;
        MostrarSubListaTutor(tutorModo);
    }
}

function MostrarSubListaTutor(tipo) {
    LimparBotoes();
    tutorModo = tipo;
    var perfil = ObterPerfilAtivo();
    if (!perfil) {
        IniciarFormularioPersonagem(false);
        return;
    }

    var titulo = "";
    if (tipo === "mobs") {
        subListaAtual = ObterMobsParaNivel(perfil);
        subCatAtual = "Mobs";
        titulo = "MONSTROS PARA LV." + perfil.level + " (" + subListaAtual.length + ")";
    } else if (tipo === "armas") {
        subListaAtual = ObterItensUteisParaPerfil(perfil);
        subCatAtual = "Itens";
        titulo = "ITENS ÚTEIS P/ " + perfil.classe.toUpperCase() + " LV." + perfil.level + " (" + subListaAtual.length + ")";
    } else if (tipo === "bosses") {
        subListaAtual = ObterBossesParaPerfil(perfil);
        subCatAtual = "Bosses";
        titulo = "BOSSES DISPONÍVEIS LV." + perfil.level + " (" + subListaAtual.length + ")";
    }

    AjustarEscalaEFonteStats("", "");

    if (!subListaAtual || subListaAtual.length === 0) {
        ExibirTextoStats(titulo + "\nNenhum registro encontrado no banco para este nível/classe.", null);
        var btnVoltarVazio = CriarBotaoAcaoTutor(
            "← Voltar ao Painel",
            "#25282C",
            "#FFD700",
            "#D4AF37",
            function() {
                tutorModo = "painel";
                MostrarPainelTutor();
            }
        );
        layLista.AddChild(btnVoltarVazio);
        botoesLista.push(btnVoltarVazio);
        return;
    }

    var totalPag = Math.max(1, Math.ceil(subListaAtual.length / itensPorPaginaTutor));
    if (paginaTutorLista < 0) paginaTutorLista = 0;
    if (paginaTutorLista >= totalPag) paginaTutorLista = totalPag - 1;

    var ini = paginaTutorLista * itensPorPaginaTutor;
    var fim = Math.min(subListaAtual.length, ini + itensPorPaginaTutor);

    ExibirTextoStats(titulo + " | Pág. " + (paginaTutorLista + 1) + "/" + totalPag + "\nToque para ver detalhes e cálculo:", null);

    for (var i = ini; i < fim; i++) {
        var it = subListaAtual[i];
        var rotulo = it.nome;
        if (tipo === "mobs") {
            var qtdUpar = CalcularMobsParaUpar(perfil.xpRestante, it.xp);
            rotulo += " (" + it.xp + (qtdUpar !== null ? " • " + qtdUpar + "x p/ upar" : "") + ")";
        } else if (tipo === "armas") {
            rotulo += " (" + it.tipo + " • Lv." + it.reqLevel + ")";
        }
        var btn = CriarBotaoItem(rotulo, 10.5, subCatAtual, it);
        layLista.AddChild(btn);
        botoesLista.push(btn);
    }

    if (totalPag > 1) {
        var layPag = CriarBarraPaginas(paginaTutorLista, totalPag,
            SubListaPrimeiraClick, SubListaAnteriorClick, SubListaProximaClick, SubListaUltimaClick);
        layLista.AddChild(layPag);
        botoesLista.push(layPag);
    }

    var btnVoltar = CriarBotaoAcaoTutor(
        "← Voltar ao Painel do Personagem",
        "#25282C",
        "#FFD700",
        "#D4AF37",
        function() {
            tutorModo = "painel";
            MostrarPainelTutor();
        }
    );
    layLista.AddChild(btnVoltar);
    botoesLista.push(btnVoltar);
}

function NormalizarTexto(str) {
    if (!str) return "";
    return String(str)
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/\s+/g, " ")
        .trim();
}

// Campos que NAO entram na busca: caminhos de imagem e recompensa ainda "A definir",
// senao buscar "boss", "img" ou "png" devolvia quase todos os bosses.
// Recompensas reais (ex.: "Demonic Relic") continuam pesquisaveis.
var CAMPOS_IGNORADOS_BUSCA = { imagem: true };

function CampoBuscavel(chave, valor) {
    if (CAMPOS_IGNORADOS_BUSCA[chave]) return false;
    if (chave === "recompensasBoss" && !ValorDefinido(valor)) return false;
    return true;
}

function Filtrar(lista, termo) {
    if (!termo) return lista;
    var tNorm = NormalizarTexto(termo);
    var palavras = tNorm.split(" ").filter(function(p) { return p.length > 0; });
    var res = [];

    for (var i = 0; i < lista.length; i++) {
        var obj = lista[i];
        var txt = "";
        for (var k in obj) {
            if (obj.hasOwnProperty(k)) {
                if ((k === "mobs" || k === "itens" || k === "lojas") && Array.isArray(obj[k])) {
                    for (var m = 0; m < obj[k].length; m++) {
                        for (var mk in obj[k][m]) {
                            if (obj[k][m].hasOwnProperty(mk) && CampoBuscavel(mk, obj[k][m][mk])) {
                                txt += " " + NormalizarTexto(obj[k][m][mk]);
                            }
                        }
                    }
                } else if (CampoBuscavel(k, obj[k])) {
                    txt += " " + NormalizarTexto(obj[k]);
                }
            }
        }

        var bateTodas = true;
        for (var p = 0; p < palavras.length; p++) {
            if (txt.indexOf(palavras[p]) === -1) {
                bateTodas = false;
                break;
            }
        }
        if (bateTodas) res.push(obj);
    }
    return res;
}

function BuscarNoBancoLocal(termo) {
    var categorias = ["Bosses", "Mobs", "Itens", "Lojas"];
    var achados = [];

    for (var c = 0; c < categorias.length; c++) {
        var cat = categorias[c];
        var lista = DB_TIBIAME[cat] || [];
        var matches = Filtrar(lista, termo);
        for (var i = 0; i < matches.length; i++) {
            achados.push({
                cat: cat,
                item: matches[i]
            });
            if (cat === "Bosses" && Array.isArray(matches[i].mobs)) {
                var subMobs = Filtrar(matches[i].mobs, termo);
                for (var s = 0; s < subMobs.length; s++) {
                    achados.push({
                        cat: "Bosses",
                        item: subMobs[s]
                    });
                }
            }
        }
    }
    return achados;
}

function ResumirItemLocal(entrada) {
    var cat = entrada.cat;
    var item = entrada.item;
    if (cat === "Mobs") {
        var perfil = ObterPerfilAtivo();
        var extraUpar = "";
        if (perfil) {
            var qtd = CalcularMobsParaUpar(perfil.xpRestante, item.xp);
            if (qtd !== null) extraUpar = " | Matar p/ upar: " + qtd;
        }
        var lvTxt = item.level ? (" | Level: " + item.level) : " | Level: a definir";
        return "[" + RotuloCat(cat) + "] " + item.nome + lvTxt + " | HP: " + item.hp + " | XP: " + item.xp +
               extraUpar + " | Fraqueza: " + item.fraqueza;
    } else if (cat === "Bosses") {
        var lvBossTxt = item.level ? (" | Level: " + item.level) : " | Level: a definir";
        return "[" + RotuloCat(cat) + "] " + item.nome + lvBossTxt + " | Ilha: " + (item.ilha || item.local || "Aurea") +
               " | HP: " + (item.hp || "A definir");
    } else if (cat === "Itens") {
        return "[" + RotuloCat(cat) + "] " + item.nome + " (" + item.tipo + " - " + item.vocacao +
               ") | Req: " + item.reqLevel;
    } else if (cat === "Lojas") {
        return "[" + RotuloCat(cat) + "] " + item.nome + " | Cidade: " + item.cidade +
               " | NPC: " + item.npc;
    }
    return "[" + RotuloCat(cat) + "] " + item.nome;
}

function ExtrairTermoWiki(consulta) {
    var limpa = NormalizarTexto(consulta)
        .replace(/\b(onde fica|onde achar|como matar|fraqueza de|fraqueza do|drop de|drops de|o que e|o que sao|qual o|qual a|do|da|de|dos|das|um|uma|para|com)\b/g, " ")
        .replace(/\s+/g, " ")
        .trim();
    return limpa || consulta.trim();
}

function DecodificarEntidadesHtml(str) {
    if (!str) return "";
    return str
        .replace(/<[^>]*>/g, "")
        .replace(/&quot;/g, "\"")
        .replace(/&#039;/g, "'")
        .replace(/&amp;/g, "&")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/\s+/g, " ")
        .trim();
}

function CliqueItem(ev) {
    var acao = (ev && ev.action) ? ev.action : "";
    var alvo = ObterAlvoToque(this, ev, "itemObj");
    if (!alvo) return;
    var agora = Date.now ? Date.now() : (new Date()).getTime();

    // TODOS os itens (os que navegam e os simples) agem so ao SOLTAR o dedo e se ele nao arrastou.
    // Assim, rolar a lista nao seleciona nem abre nada no meio do gesto.
    if (acao === "Down") {
        toqueIniX = ev.x || 0; toqueIniY = ev.y || 0; toqueIniT = agora; toqueArrastou = false;
        return;
    }
    if (acao === "Move") {
        if (Math.abs((ev.x || 0) - toqueIniX) > 0.02 || Math.abs((ev.y || 0) - toqueIniY) > 0.02) toqueArrastou = true;
        return;
    }
    if (acao) {
        if (acao !== "Up") return;
        if (toqueArrastou || (agora - toqueIniT) > 450) return;
    }
    if (agora - bloqueioCliqueItem < 300) return;
    bloqueioCliqueItem = agora;

    if (alvo.acaoCustom) {
        alvo.acaoCustom.call(alvo, ev);
    } else {
        VerItem(alvo.catNome, alvo.itemObj);
    }
}

function CriarBotaoItem(texto, tamanhoTexto, cat, item, onClickCustom) {
    var box = app.CreateLayout("Linear", "Horizontal,VCenter,Left");
    box.SetSize(0.92, -1);
    box.SetMargins(0, 0.003, 0, 0.003);
    box.SetBackColor("#161A1E");
    box.SetPadding(0.01, 0.006, 0.01, 0.005);

    var imgSprite = null;
    if (item && item.imagem) {
        try {
            imgSprite = app.CreateImage(item.imagem, 0.065, -1);
            if (imgSprite) {
                imgSprite.SetMargins(0, 0, 0.015, 0);
                imgSprite.itemObj = item;
                imgSprite.catNome = cat;
                imgSprite.acaoCustom = onClickCustom;
                imgSprite.SetOnTouch(CliqueItem);
                pendImgLista++;
                imgSprite.SetOnLoad(ImgListaCarregou);
                box.AddChild(imgSprite);
            }
        } catch (e) {}
    }

    var colunaTexto = app.CreateLayout("Linear", "Vertical,VCenter,HCenter");
    colunaTexto.SetSize(imgSprite ? 0.81 : 0.89, -1);

    var lbl = app.CreateText(texto, -1, -1, "Center");
    lbl.SetTextSize(tamanhoTexto);
    var corNome = "";
    if (cat === "Bosses") {
        corNome = CorStatusBoss(StatusBossPerfil(ObterBossParaCor(item), ObterPerfilAtivo()));
    } else if ((cat === "Lojas" || cat === "LojaItem") && item && item.faixa) {
        corNome = CorFaixaLoja(item.faixa);
    }
    lbl.SetTextColor(corNome || "#E6EEF3");

    var fileteBrilho = app.CreateText("", 0.72, 0.004);
    fileteBrilho.SetBackColor("#161A1E");
    fileteBrilho.SetMargins(0, 0.003, 0, 0);

    var selecionadoInicial = (itemSelecionado === item && catSelecionada === cat);
    if (selecionadoInicial) {
        box.SetBackColor("#1B3B48");
        lbl.SetTextColor(corNome || "#A8F2FF");
        fileteBrilho.SetBackColor("#7CE8FF");
    }

    box.corNome = corNome;
    box.itemObj = item;
    box.catNome = cat;
    box.lbl = lbl;
    box.fileteBrilho = fileteBrilho;
    box.acaoCustom = onClickCustom;
    box.SetOnTouch(CliqueItem);

    colunaTexto.itemObj = item;
    colunaTexto.catNome = cat;
    colunaTexto.acaoCustom = onClickCustom;
    colunaTexto.SetOnTouch(CliqueItem);

    lbl.itemObj = item;
    lbl.catNome = cat;
    lbl.acaoCustom = onClickCustom;
    lbl.SetOnTouch(CliqueItem);

    fileteBrilho.itemObj = item;
    fileteBrilho.catNome = cat;
    fileteBrilho.acaoCustom = onClickCustom;
    fileteBrilho.SetOnTouch(CliqueItem);

    colunaTexto.AddChild(lbl);
    colunaTexto.AddChild(fileteBrilho);
    box.AddChild(colunaTexto);

    return box;
}

function AtualizarDestaqueBotoesItem() {
    for (var i = 0; i < botoesLista.length; i++) {
        var b = botoesLista[i];
        if (b && b.hasOwnProperty("itemObj") && b.lbl && b.fileteBrilho) {
            var ativo = (b.itemObj === itemSelecionado && b.catNome === catSelecionada);
            b.SetBackColor(ativo ? "#1B3B48" : "#161A1E");
            b.lbl.SetTextColor(b.corNome ? b.corNome : (ativo ? "#A8F2FF" : "#E6EEF3"));
            b.fileteBrilho.SetBackColor(ativo ? "#7CE8FF" : "#161A1E");
        }
    }
}

function AbrirLoja(lojaObj) {
    LimparBotoes();
    VerItem("Lojas", lojaObj);

    var itens = (lojaObj && Array.isArray(lojaObj.itens)) ? lojaObj.itens : [];
    for (var i = 0; i < itens.length; i++) {
        var btnIt = CriarBotaoItem(itens[i].nome, 10.5, "LojaItem", itens[i]);
        layLista.AddChild(btnIt);
        botoesLista.push(btnIt);
    }

    var btnVoltarLojas = CriarBotaoAcaoTutor(
        "← Voltar para lista de Lojas",
        "#25282C",
        "#FFD700",
        "#D4AF37",
        function() {
            itemSelecionado = null;
            catSelecionada = null;
            LimparBotoes();
            var termo = edtBusca ? edtBusca.GetText().trim() : "";
            MostrarLista("Lojas", Filtrar(DB_TIBIAME.Lojas || [], termo), termo);
        }
    );
    layLista.AddChild(btnVoltarLojas);
    botoesLista.push(btnVoltarLojas);
}

// Icone do elemento + valor (ex.: [icone] Fogo 1-10 ou [icone] Fogo 10%).
function MontarHtmlElementoComValor(el, valorTxt) {
    var arq = ICONES_ELEMENTO[ChaveElemento(el)];
    if (!arq) return "<span class='el'>" + EscaparHtml(el) + " " + EscaparHtml(valorTxt) + "</span>";
    return "<span class='el'><img data-n='" + arq + "' src='file:///android_asset/" + IMG_ELEMENTOS + arq +
           "' onerror='EF(this)'>" + EscaparHtml(el) + " " + EscaparHtml(valorTxt) + "</span>";
}

function TextoDanoLoja(item) {
    var t = [];
    for (var i = 0; item.dano && i < item.dano.length; i++) t.push(item.dano[i][0] + ": " + item.dano[i][1]);
    return t.join(" | ");
}

function TextoDefesaLoja(item) {
    var t = [];
    for (var i = 0; item.defesa && i < item.defesa.length; i++) t.push(item.defesa[i][0] + ": " + item.defesa[i][1] + "%");
    return t.join(" | ");
}

function MontarHtmlLojaItemDetalhe(item) {
    var linhas = [
        "<div><b>" + EscaparHtml(item.nome) + "</b></div>",
        "<div>Loja: " + EscaparHtml(item.loja || "A definir") + "</div>",
        "<div>Tipo: " + EscaparHtml(item.tipo || "A definir") + " | Level: " + EscaparHtml(item.level || "A definir") + "</div>",
        "<div>Vocacao: " + EscaparHtml(item.vocacao || "A definir") + "</div>",
        "<div>Preco: " + EscaparHtml(item.preco || "A definir") + "</div>"
    ];
    if (item.materiais) linhas.push("<div>Materiais: " + EscaparHtml(item.materiais) + "</div>");
    var i, partes;
    if (item.dano && item.dano.length) {
        partes = [];
        for (i = 0; i < item.dano.length; i++) partes.push(MontarHtmlElementoComValor(item.dano[i][0], item.dano[i][1]));
        linhas.push("<div>Ataque: " + partes.join(" ") + "</div>");
    } else if (item.elemento) {
        linhas.push("<div>Ataque elemental: " + MontarHtmlElementos(item.elemento) + "</div>");
    } else if (String(item.tipo || "") === "Arma") {
        linhas.push("<div>Ataque elemental: A definir</div>");
    }
    if (item.mana) linhas.push("<div>Custo de mana: " + EscaparHtml(item.mana) + "</div>");
    if (item.defesa && item.defesa.length) {
        partes = [];
        for (i = 0; i < item.defesa.length; i++) partes.push(MontarHtmlElementoComValor(item.defesa[i][0], item.defesa[i][1] + "%"));
        linhas.push("<div>Defesa: " + partes.join(" ") + "</div>");
    }
    if (item.obs) linhas.push("<div>Obs: " + EscaparHtml(item.obs) + "</div>");
    return "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width,initial-scale=1.0,user-scalable=no'>" +
           "<style>*{margin:0;padding:0;box-sizing:border-box;}" +
           "html,body{width:100%;height:100%;background:transparent;color:#FFFFFF;" +
           "font-family:sans-serif;font-size:11.5px;line-height:1.32;overflow-y:auto;padding:2px 4px;}" +
           "div{word-wrap:break-word;}</style>" + EstiloScriptElementos() + "</head>" +
           "<body>" + linhas.join("") + "</body></html>";
}

function MontarHtmlItemDetalhe(item) {
    var linhas = [
        "<div><b>" + EscaparHtml(item.nome) + "</b></div>",
        "<div>Tipo: " + EscaparHtml(item.tipo || "A definir") + " | Level: " + EscaparHtml(item.level || item.reqLevel || "A definir") + "</div>",
        "<div>Vocacao: " + EscaparHtml(item.vocacao || "A definir") + "</div>"
    ];
    var i, partes;
    if (item.dano && item.dano.length) {
        partes = [];
        for (i = 0; i < item.dano.length; i++) partes.push(MontarHtmlElementoComValor(item.dano[i][0], item.dano[i][1]));
        linhas.push("<div>Ataque: " + partes.join(" ") + "</div>");
    }
    if (item.mana) linhas.push("<div>Custo de mana: " + EscaparHtml(item.mana) + "</div>");
    if (item.defesa && item.defesa.length) {
        partes = [];
        for (i = 0; i < item.defesa.length; i++) partes.push(MontarHtmlElementoComValor(item.defesa[i][0], item.defesa[i][1] + "%"));
        linhas.push("<div>Defesa: " + partes.join(" ") + "</div>");
    }
    if (item.lojas && item.lojas.length) {
        linhas.push("<div>Onde comprar:</div>");
        for (i = 0; i < item.lojas.length; i++) {
            var lj = item.lojas[i];
            linhas.push("<div>&bull; " + EscaparHtml(lj.loja) + " - " + EscaparHtml(lj.preco || "A definir") + "</div>");
        }
    }
    if (item.dropsMobs && item.dropsMobs.length) {
        linhas.push("<div>Drop de: " + EscaparHtml(item.dropsMobs.join(", ")) + "</div>");
        if (item.locaisDrop && item.locaisDrop.length) linhas.push("<div>Locais dos drops: " + EscaparHtml(item.locaisDrop.join(", ")) + "</div>");
    }
    if ((!item.lojas || !item.lojas.length) && (!item.dropsMobs || !item.dropsMobs.length)) {
        linhas.push("<div>Onde achar: " + EscaparHtml(item.ondeAchar || "A definir") + "</div>");
    }
    if (item.obs) linhas.push("<div>Obs: " + EscaparHtml(item.obs) + "</div>");
    return "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width,initial-scale=1.0,user-scalable=no'>" +
           "<style>*{margin:0;padding:0;box-sizing:border-box;}" +
           "html,body{width:100%;height:100%;background:transparent;color:#FFFFFF;" +
           "font-family:sans-serif;font-size:11.5px;line-height:1.32;overflow-y:auto;padding:2px 4px;}" +
           "div{word-wrap:break-word;}</style>" + EstiloScriptElementos() + "</head>" +
           "<body>" + linhas.join("") + "</body></html>";
}

function AbrirBossComMobs(bossObj) {
    bossAbertoAtual = bossObj;
    LimparBotoes();
    VerItem("Bosses", bossObj);

    var mobsDoBoss = (bossObj && Array.isArray(bossObj.mobs)) ? bossObj.mobs : [];
    for (var i = 0; i < mobsDoBoss.length; i++) {
        var mobBoss = mobsDoBoss[i];
        var btnMob = CriarBotaoItem(mobBoss.nome, 10.5, "Bosses", mobBoss);
        layLista.AddChild(btnMob);
        botoesLista.push(btnMob);
    }

    var btnVoltarBosses = CriarBotaoAcaoTutor(
        "← Voltar para lista de Bosses",
        "#25282C",
        "#FFD700",
        "#D4AF37",
        function() {
            bossAbertoAtual = null;
            itemSelecionado = null;
            catSelecionada = null;
            LimparBotoes();
            var termo = edtBusca ? edtBusca.GetText().trim() : "";
            MostrarLista("Bosses", Filtrar(DB_TIBIAME.Bosses || [], termo), termo);
        }
    );
    layLista.AddChild(btnVoltarBosses);
    botoesLista.push(btnVoltarBosses);
}

// ==========================================
// PESQUISA NA WIKI (resumo completo + ficha tecnica)
// ==========================================
// Callbacks GLOBAIS (sem closure): usam o estado em wikiCtx, que e descartado se o usuario
// abrir um item, trocar de aba/tela ou apagar a busca antes da resposta chegar.
function WikiCtxValido(ctx) {
    if (!ctx || wikiCtx !== ctx) return false;
    if (abaAtual !== "Tutor") return false;
    if (edtBusca && edtBusca.GetText().trim() === "") return false;
    return true;
}

function LimparWikitext(v) {
    if (!v) return "";
    var t = String(v);
    t = t.replace(/<ref[^>]*>[\s\S]*?<\/ref>/gi, "").replace(/<ref[^>]*\/>/gi, "");
    t = t.replace(/<!--[\s\S]*?-->/g, "");
    t = t.replace(/<br\s*\/?>/gi, ", ");
    for (var k = 0; k < 4; k++) t = t.replace(/\{\{[^{}]*\}\}/g, "");   // templates (aninhados)
    t = t.replace(/\[\[(?:[^\]|]*\|)?([^\]]*)\]\]/g, "$1");
    t = t.replace(/'{2,}/g, "");
    t = t.replace(/<[^>]*>/g, "").replace(/&nbsp;/g, " ");
    return DecodificarEntidadesHtml(t).replace(/^[,\s]+|[,\s]+$/g, "");
}

function ExtrairFichaWiki(wikitexto) {
    var linhas = String(wikitexto || "").split("\n");
    var ignorar = /^(image|imagem|img|gif|sprite|icon|icone|title|titulo|caption|legenda|file|arquivo)/i;
    var out = [];
    for (var i = 0; i < linhas.length && out.length < 18; i++) {
        var m = linhas[i].match(/^\s*\|\s*([^=|{}\[\]]+?)\s*=\s*(.*)$/);
        if (!m) continue;
        var chave = m[1].replace(/_/g, " ").trim();
        if (!chave || ignorar.test(chave)) continue;
        var valor = LimparWikitext(m[2]);
        if (!valor || valor === "?" ) continue;
        if (valor.length > 160) valor = valor.substring(0, 157) + "...";
        out.push(chave.charAt(0).toUpperCase() + chave.substring(1) + ": " + valor);
    }
    return out;
}

function ResumirExtrato(txt, max) {
    if (!txt) return "";
    var t = String(txt).replace(/={2,}[^=\n]+={2,}/g, "").replace(/\r/g, "");
    t = t.replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
    if (t.length <= max) return t;
    var corte = t.substring(0, max);
    var p = Math.max(corte.lastIndexOf(". "), corte.lastIndexOf(".\n"));
    if (p > max * 0.5) return corte.substring(0, p + 1);
    return corte.replace(/\s+\S*$/, "") + "...";
}

var wikiToque = null;          // toque em andamento num card da wiki
var wikiUrlPendente = null;    // link aguardando confirmacao do usuario

function ConfirmarAbrirWiki(resposta) {
    var url = wikiUrlPendente;
    wikiUrlPendente = null;
    if (resposta === "Yes" && url) {
        try { app.OpenUrl(url); } catch (e) { app.ShowPopup("Nao foi possivel abrir o link."); }
    }
}

// Nao abre no "Down" (que acontece ao comecar a rolar). So considera um toque valido quando o
// dedo levanta no mesmo lugar (Up sem Move/Cancel) e entao pergunta se deseja sair para o site.
function CliqueWikiCard(ev) {
    if (!ev) return;
    var alvo = ObterAlvoToque(this, ev, "urlWiki");
    var acao = ev.action;

    if (acao === "Down") {
        wikiToque = (alvo && alvo.urlWiki) ? { x: ev.x, y: ev.y, url: alvo.urlWiki, titulo: alvo.tituloWiki || "" } : null;
        return;
    }
    if (!wikiToque) return;

    if (acao === "Move") {
        var dx = Math.abs((ev.x || 0) - (wikiToque.x || 0));
        var dy = Math.abs((ev.y || 0) - (wikiToque.y || 0));
        if (dx > 0.04 || dy > 0.02) wikiToque = null;   // arrastou = rolagem, nao clique
        return;
    }
    if (acao === "Up") {
        var t = wikiToque;
        wikiToque = null;
        wikiUrlPendente = t.url;
        try {
            var dlg = app.CreateYesNoDialog("Abrir \"" + t.titulo + "\" no navegador?\n\nVoce vai sair do app.");
            dlg.SetOnTouch(ConfirmarAbrirWiki);
            dlg.Show();
        } catch (e) {
            wikiUrlPendente = null;
            app.ShowPopup("Nao foi possivel exibir a confirmacao.");
        }
        return;
    }
    wikiToque = null;   // Cancel ou qualquer outro evento
}

function CriarCardWiki(titulo, corpo, url, destaque) {
    var box = app.CreateLayout("Linear", "Vertical,Left");
    box.SetSize(0.92, -1);
    box.SetMargins(0, 0.004, 0, 0.004);
    box.SetBackColor(destaque ? "#1B1606" : "#14181C");
    box.SetPadding(0.015, 0.01, 0.015, 0.01);

    var lt = app.CreateText(titulo, 0.88, -1, "Multiline,Left");
    lt.SetTextSize(14);
    lt.SetTextColor("#FFD700");
    box.AddChild(lt);

    var lc = app.CreateText(corpo, 0.88, -1, "Multiline,Left");
    lc.SetTextSize(11.5);
    lc.SetTextColor("#E6EEF3");
    lc.SetMargins(0, 0.006, 0, 0);
    box.AddChild(lc);

    var objs = [box, lt, lc];
    if (url) {
        var ll = app.CreateText("Toque para abrir na Wiki (pede confirmacao)", 0.88, -1, "Left");
        ll.SetTextSize(9.5);
        ll.SetTextColor("#8FA3B0");
        ll.SetMargins(0, 0.006, 0, 0);
        box.AddChild(ll);
        objs.push(ll);
    }
    for (var i = 0; i < objs.length; i++) {
        objs[i].urlWiki = url || "";
        objs[i].tituloWiki = titulo;
        objs[i].SetOnTouch(CliqueWikiCard);
    }
    return box;
}

function UrlPaginaWiki(titulo) {
    return "https://tibiame.fandom.com/wiki/" + encodeURIComponent(String(titulo).replace(/ /g, "_"));
}

// Chamada quando as respostas pendentes (busca + ficha) terminam: monta tudo de uma vez.
function FinalizarWiki(ctx) {
    if (!WikiCtxValido(ctx)) return;
    if (ctx.pend > 0) return;
    wikiCtx = null;

    var artigos = ctx.artigos || [];
    var ficha = ctx.ficha || null;

    if (ctx.erroRede && artigos.length === 0 && !ficha) {
        ExibirTextoStats(ctx.cab + "\nINTERNET (Wiki TibiaME):\n• Sem conexao ou erro ao consultar a Wiki.", null);
        return;
    }
    if (artigos.length === 0 && !ficha) {
        ExibirTextoStats(ctx.cab + "\nINTERNET (Wiki TibiaME):\n• Nenhum artigo encontrado para \"" + ctx.termo + "\".", null);
        return;
    }

    var cards = [];
    if (ficha) {
        cards.push(CriarCardWiki("FICHA: " + ficha.titulo, ficha.linhas.join("\n"), UrlPaginaWiki(ficha.titulo), true));
    }
    for (var j = 0; j < artigos.length; j++) {
        var ar = artigos[j];
        if (ficha && ar.titulo.toLowerCase() === ficha.titulo.toLowerCase() && ar.texto.length < 60) continue;
        cards.push(CriarCardWiki(ar.titulo, ar.texto || "(sem resumo disponivel)", ar.url, false));
    }
    for (var c = 0; c < cards.length; c++) {
        layLista.AddChild(cards[c]);
        botoesLista.push(cards[c]);
    }

    ExibirTextoStats(ctx.cab + "\nINTERNET (Wiki TibiaME): " + cards.length +
                     " resultado(s) - role a lista abaixo para ler os detalhes.", null);
}

// Resposta da busca com resumo (generator=search + extracts)
function AoReceberWiki(err, resp) {
    var ctx = wikiCtx;
    if (!WikiCtxValido(ctx)) return;
    var artigos = [];
    var temExtrato = false;

    if (err || !resp) {
        ctx.erroRede = true;
    } else {
        try {
            var data = JSON.parse(resp);
            var pages = (data.query && data.query.pages) ? data.query.pages : {};
            var lista = [];
            for (var id in pages) { if (pages.hasOwnProperty(id)) lista.push(pages[id]); }
            lista.sort(function(x, y) { return (x.index || 99) - (y.index || 99); });
            for (var i = 0; i < lista.length; i++) {
                var pg = lista[i];
                var ext = ResumirExtrato(pg.extract, 1100);
                if (ext) temExtrato = true;
                artigos.push({ titulo: pg.title, texto: ext, url: pg.fullurl || UrlPaginaWiki(pg.title) });
            }
        } catch (e) {
            ctx.erroRede = true;
        }
    }
    ctx.artigos = artigos;

    // Plano B: se a wiki nao devolveu resumos (extensao desligada), usa a busca simples com trechos.
    if (!temExtrato && !ctx.erroRede) {
        var urlLegado = "https://tibiame.fandom.com/api.php?action=query&list=search&srsearch=" +
                        encodeURIComponent(ctx.termo) + "&srlimit=5&format=json&utf8=1";
        app.HttpRequest("GET", urlLegado, null, null, AoReceberWikiLegado);
        return;
    }
    ctx.pend--;
    FinalizarWiki(ctx);
}

function AoReceberWikiLegado(err, resp) {
    var ctx = wikiCtx;
    if (!WikiCtxValido(ctx)) return;
    var artigos = [];
    if (!err && resp) {
        try {
            var data = JSON.parse(resp);
            var arr = (data.query && data.query.search) ? data.query.search : [];
            for (var i = 0; i < arr.length; i++) {
                artigos.push({
                    titulo: arr[i].title,
                    texto: DecodificarEntidadesHtml(arr[i].snippet),
                    url: UrlPaginaWiki(arr[i].title)
                });
            }
        } catch (e) {}
    } else {
        ctx.erroRede = true;
    }
    if (artigos.length > 0) ctx.artigos = artigos;
    ctx.pend--;
    FinalizarWiki(ctx);
}

// Resposta da ficha tecnica (infobox da pagina: HP, level, local, fraquezas, drops...)
function AoReceberWikiFicha(err, resp) {
    var ctx = wikiCtx;
    if (!WikiCtxValido(ctx)) return;
    if (!err && resp) {
        try {
            var data = JSON.parse(resp);
            if (data.parse && data.parse.wikitext) {
                var wt = data.parse.wikitext["*"] !== undefined ? data.parse.wikitext["*"] : data.parse.wikitext;
                var linhas = ExtrairFichaWiki(wt);
                if (linhas.length >= 2) ctx.ficha = { titulo: data.parse.title || ctx.termo, linhas: linhas };
            }
        } catch (e) {}
    }
    ctx.pend--;
    FinalizarWiki(ctx);
}

function PesquisarTutor(consulta) {
    if (!consulta) {
        AbrirMenuTutor();
        return;
    }

    LimparBotoes();
    AjustarEscalaEFonteStats("", "");
    var resultadosLocais = BuscarNoBancoLocal(consulta);

    // Voltar fica no TOPO da lista: assim nunca fica escondido atras do rodape.
    var btnVoltarTutor = CriarBotaoAcaoTutor(
        "← Voltar ao Menu do Personagem",
        "#25282C",
        "#FFD700",
        "#D4AF37",
        function() {
            if (edtBusca) edtBusca.SetText("");
            tutorModo = "auto";
            AbrirMenuTutor();
        }
    );
    layLista.AddChild(btnVoltarTutor);
    botoesLista.push(btnVoltarTutor);


    var cabLocal = "";
    if (resultadosLocais.length > 0) {
        // Agrupa por categoria para que Mobs, Itens e Lojas tambem aparecam (antes os Bosses
        // ocupavam todos os botoes porque vinham primeiro na lista).
        var ordemCats = ["Bosses", "Mobs", "Itens", "Lojas"];
        var porCat = {};
        for (var g = 0; g < resultadosLocais.length; g++) {
            var ct = resultadosLocais[g].cat;
            if (!porCat[ct]) porCat[ct] = [];
            porCat[ct].push(resultadosLocais[g]);
        }
        var limitePorCat = 4;
        var selecionados = [];
        var contagens = [];
        for (var oc = 0; oc < ordemCats.length; oc++) {
            var lc = porCat[ordemCats[oc]] || [];
            if (lc.length === 0) continue;
            contagens.push(RotuloCat(ordemCats[oc]) + " " + lc.length);
            for (var k = 0; k < Math.min(limitePorCat, lc.length); k++) selecionados.push(lc[k]);
        }

        cabLocal = "BANCO DO APP (" + resultadosLocais.length + " encontrado(s)):\n" + contagens.join(" | ") + "\n";

        // Resumo: o 1o resultado das duas primeiras categorias que tiveram resultado
        var resumidos = 0;
        for (var oc2 = 0; oc2 < ordemCats.length && resumidos < 2; oc2++) {
            var lc2 = porCat[ordemCats[oc2]];
            if (!lc2 || lc2.length === 0) continue;
            var linhaRes = ResumirItemLocal(lc2[0]);
            if (linhaRes.length > 85) linhaRes = linhaRes.substring(0, 82) + "...";
            cabLocal += "• " + linhaRes + "\n";
            resumidos++;
        }
        if (resultadosLocais.length > selecionados.length) {
            cabLocal += "(mostrando " + selecionados.length + " nos botoes; use as abas para ver todos)\n";
        }

        for (var b = 0; b < selecionados.length; b++) {
            var resObj = selecionados[b];
            var btnLocal = CriarBotaoItem(
                resObj.item.nome + " (" + RotuloCat(resObj.cat) + ")",
                10.5,
                resObj.cat,
                resObj.item
            );
            layLista.AddChild(btnLocal);
            botoesLista.push(btnLocal);
        }
    } else {
        cabLocal = "BANCO DO APP: nenhum resultado direto para \"" + consulta + "\".\n";
    }


    ExibirTextoStats(cabLocal + "\nINTERNET (Wiki TibiaME): pesquisando...", null);

    var termoWiki = ExtrairTermoWiki(consulta);
    var base = "https://tibiame.fandom.com/api.php?";
    var urlBusca = base + "action=query&generator=search&gsrsearch=" + encodeURIComponent(termoWiki) +
                   "&gsrlimit=4&prop=extracts%7Cinfo&exintro=1&explaintext=1&exchars=1200&exlimit=max" +
                   "&inprop=url&redirects=1&format=json&utf8=1";
    var tituloGuess = termoWiki.replace(/\b\w/g, function(ch) { return ch.toUpperCase(); });
    var urlFicha = base + "action=parse&page=" + encodeURIComponent(tituloGuess) +
                   "&prop=wikitext&section=0&redirects=1&format=json&utf8=1";

    wikiCtx = { cab: cabLocal, termo: termoWiki, btnVoltar: btnVoltarTutor, pend: 2,
                artigos: [], ficha: null, erroRede: false };
    app.HttpRequest("GET", urlBusca, null, null, AoReceberWiki);
    app.HttpRequest("GET", urlFicha, null, null, AoReceberWikiFicha);
}

function RodarBusca() {
    var termo = edtBusca ? edtBusca.GetText().trim() : "";
    if (abaAtual == "Tutor") {
        PesquisarTutor(termo);
        return;
    }
    paginaMob = 0;
    paginaBoss = 0;
    paginaItem = 0;
    itemSelecionado = null;
    catSelecionada = null;
    bossAbertoAtual = null;
    LimparBotoes();
    var lista = DB_TIBIAME[abaAtual] || [];
    MostrarLista(abaAtual, Filtrar(lista, termo), termo);
}

// Titulo colorido que separa as faixas de nivel na lista de lojas (sem toque).
function CriarCabecalhoFaixaLoja(faixa) {
    var info = INFO_FAIXA_LOJA[faixa];
    var box = app.CreateLayout("Linear", "Vertical,VCenter,HCenter");
    box.SetSize(0.92, -1);
    box.SetMargins(0, 0.012, 0, 0.004);

    var lbl = app.CreateText("● " + info.titulo + " (" + info.detalhe + ")", 0.92, -1, "Center");
    lbl.SetTextSize(11);
    lbl.SetTextColor(info.cor);
    box.AddChild(lbl);

    var barra = app.CreateText("", 0.92, 0.004);
    barra.SetBackColor(info.cor);
    barra.SetMargins(0, 0.003, 0, 0);
    box.AddChild(barra);
    return box;
}

function MostrarLista(cat, lista, termo) {
    if (!lista || lista.length == 0) {
        AjustarEscalaEFonteStats("", "");
        ExibirTextoStats(RotuloCat(cat) + ": nenhum resultado encontrado.", null);
        return;
    }

    var ini = 0;
    var fim = lista.length;
    var totalPag = 1;

    var paginada = (cat == "Mobs" || cat == "Bosses" || cat == "Itens");
    if (paginada) {
        catPaginada = cat;
        var pag = ObterPagina(cat);
        totalPag = Math.max(1, Math.ceil(lista.length / itensPorPagina));
        if (pag < 0) pag = 0;
        if (pag >= totalPag) pag = totalPag - 1;
        DefinirPagina(cat, pag);
        ini = pag * itensPorPagina;
        fim = Math.min(lista.length, ini + itensPorPagina);

        var cab = (cat == "Mobs" ? "MONSTROS" : (cat == "Bosses" ? "BOSSES" : "ITENS")) + " (" + (ini + 1) + "-" + fim + " de " + lista.length +
                  " | Pag. " + (pag + 1) + "/" + totalPag + ")";
        if (termo) cab += " [" + termo + "]";
        AjustarEscalaEFonteStats("", "");
        ExibirTextoStats(cab + (cat == "Mobs" ? "\nToque em um monstro:" : (cat == "Bosses" ? "\nToque no boss para ver status e monstros:" : "\nToque em um item para ver detalhes, lojas e drops:")), null);
    } else {
        var tit = RotuloCat(cat) + " (" + lista.length + ")";
        if (termo) tit += " [" + termo + "]";
        AjustarEscalaEFonteStats("", "");
        ExibirTextoStats(tit + (cat == "Lojas" ? "\nVerde = iniciante | Amarelo = intermediário | Vermelho = alto.\nToque em uma loja para ver armas e armaduras:" : "\nToque para ver detalhes:"), null);
    }

    // Monta a lista em pequenos lotes (cede tempo para a interface entre um lote e outro).
    // Assim a animacao do "Carregando..." consegue se mover enquanto os botoes sao criados.
    filaLista = {
        cat: cat, lista: lista, i: ini, fim: fim, faixa: "",
        paginada: paginada, totalPag: totalPag, token: tokenLista
    };
    ProximoLoteLista();
}

var filaLista = null;
var tokenLista = 0;
var LOTE_LISTA = 2;
var PAUSA_LOTE_MS = 25;

function ProximoLoteLista() {
    var f = filaLista;
    if (!f || f.token !== tokenLista) return;     // troca de tela: descarta o que faltava

    var cat = f.cat;
    var lista = f.lista;
    var limite = Math.min(f.fim, f.i + LOTE_LISTA);

    for (; f.i < limite; f.i++) {
        var item = lista[f.i];
        if (cat == "Lojas" && item.faixa && item.faixa !== f.faixa) {
            f.faixa = item.faixa;
            var cabFaixa = CriarCabecalhoFaixaLoja(item.faixa);
            layLista.AddChild(cabFaixa);
            botoesLista.push(cabFaixa);
        }
        var acaoBoss = (cat == "Bosses" && Array.isArray(item.mobs))
            ? (function(bossItem) {
                return function() { AbrirBossComMobs(bossItem); };
            })(item)
            : null;
        if (cat == "Lojas" && Array.isArray(item.itens)) {
            acaoBoss = (function(lojaItem) {
                return function() { AbrirLoja(lojaItem); };
            })(item);
        }

        var textoBtn = item.nome;
        if (cat == "Itens") {
            var vocCurta = (item.vocacao == "Guerreiro e Mago") ? "Ambos" : item.vocacao;
            textoBtn = item.nome + " (" + item.tipo + " • Lv." + item.level + " • " + vocCurta + ")";
        }
        var btn = CriarBotaoItem(textoBtn, 11, cat, item, acaoBoss);
        layLista.AddChild(btn);
        botoesLista.push(btn);
    }

    if (f.i < f.fim) {
        setTimeout(ProximoLoteLista, PAUSA_LOTE_MS);
        return;
    }

    // terminou todos os botoes: paginacao (setas) e exibicao da lista
    if (f.paginada && f.totalPag > 1) {
        var layPag = CriarBarraPaginas(ObterPagina(f.cat), f.totalPag,
            PaginaPrimeiraClick, PaginaAnteriorClick, PaginaProximaClick, PaginaUltimaClick);
        layLista.AddChild(layPag);
        botoesLista.push(layPag);
    }
    filaLista = null;
    MostrarScrLista();
}

// Barra de paginacao com setas (img/icones/seta.png e img/icones/setadupla.png, ambas apontando para a esquerda;
// as do lado direito sao as mesmas imagens espelhadas).
//  seta      = anda 1 pagina | setadupla = vai para a primeira/ultima pagina
//  1a pagina: so as setas da direita | ultima pagina: so as setas da esquerda | demais: todas.
// Os handlers recebidos sao funcoes GLOBAIS (sem closure).
function CriarSetaPagina(arquivo, espelhar, handler) {
    var img = app.CreateImage("img/icones/" + arquivo, 0.085, -1);
    img.SetMargins(0.012, 0.004, 0.012, 0.004);
    if (espelhar) {
        try { img.SetScale(-1, 1); } catch (e) { try { img.Rotate(180); } catch (e2) {} }
    }
    img.SetOnTouch(handler);
    return img;
}

function CriarBarraPaginas(pag, totalPag, hPrimeira, hAnterior, hProxima, hUltima) {
    var barra = app.CreateLayout("Linear", "Horizontal,VCenter");
    barra.SetSize(0.92, -1);

    var esq = app.CreateLayout("Linear", "Horizontal,VCenter,Left");
    esq.SetSize(0.46, -1);
    var dir = app.CreateLayout("Linear", "Horizontal,VCenter,Right");
    dir.SetSize(0.46, -1);

    if (pag > 0) {
        esq.AddChild(CriarSetaPagina("setadupla.png", false, hPrimeira));
        esq.AddChild(CriarSetaPagina("seta.png", false, hAnterior));
    }
    if (pag < totalPag - 1) {
        dir.AddChild(CriarSetaPagina("seta.png", true, hProxima));
        dir.AddChild(CriarSetaPagina("setadupla.png", true, hUltima));
    }
    barra.AddChild(esq);
    barra.AddChild(dir);
    return barra;
}

function ObterPagina(cat) { return (cat == "Bosses") ? paginaBoss : (cat == "Itens" ? paginaItem : paginaMob); }
function DefinirPagina(cat, v) { if (cat == "Bosses") paginaBoss = v; else if (cat == "Itens") paginaItem = v; else paginaMob = v; }

// Handlers GLOBAIS (sem closure), como pede o aviso do DroidScript acima: leem catPaginada.
function IrParaPagina(destino) {   // destino: indice absoluto; -1 = ultima
    var cat = catPaginada;
    var t = edtBusca ? edtBusca.GetText().trim() : "";
    var lista = Filtrar(DB_TIBIAME[cat] || [], t);
    var total = Math.max(1, Math.ceil(lista.length / itensPorPagina));
    var nova = (destino < 0) ? total - 1 : destino;
    if (nova < 0 || nova >= total || nova === ObterPagina(cat)) return;
    DefinirPagina(cat, nova);
    LimparBotoes();
    MostrarLista(cat, lista, t);
}
function MudarPagina(delta) { IrParaPagina(ObterPagina(catPaginada) + delta); }
function PaginaAnteriorClick(ev) { if (!ToqueDeBotaoValido(ev)) return; MudarPagina(-1); }
function PaginaProximaClick(ev) { if (!ToqueDeBotaoValido(ev)) return; MudarPagina(1); }
function PaginaPrimeiraClick(ev) { if (!ToqueDeBotaoValido(ev)) return; IrParaPagina(0); }
function PaginaUltimaClick(ev) { if (!ToqueDeBotaoValido(ev)) return; IrParaPagina(-1); }

function AtualizarMolduraEstatisticas(destacada) {
    if (!boxStats) return;
    try {
        boxStats.SetBackColor(destacada ? "#1C1404" : "#120E04");
        boxStats.SetBackGradient(destacada ? "#261B05" : "#1B1406", "#0D0A03");
    } catch (e) {}
    if (bordaStatsTopo) {
        bordaStatsTopo.SetBackColor(destacada ? "#FFD700" : "#C59B27");
    }
    if (bordaStatsBase) {
        bordaStatsBase.SetBackColor(destacada ? "#FFD700" : "#C59B27");
    }
}

function AjustarEscalaEFonteStats(cat, texto) {
    if (!txtInfo) return;
    AtualizarMolduraEstatisticas(cat === "Mobs" || cat === "Bosses");
    if (cat !== "Mobs" && cat !== "Bosses") {
        txtInfo.SetTextSize(13);
        try { txtInfo.SetScale(1.0, 1.0); } catch (e) {}
        return;
    }
    var tamanho = texto.length;
    var linhas = texto.split("\n").length;
    var fonte = 10.5;
    var escala = 0.90;

    if (tamanho > 240 || linhas > 7) {
        fonte = 8.5;
        escala = 0.78;
    } else if (tamanho > 170 || linhas > 6) {
        fonte = 9;
        escala = 0.82;
    } else if (tamanho > 140 || linhas > 5) {
        fonte = 9.5;
        escala = 0.85;
    }

    txtInfo.SetTextSize(fonte);
    try { txtInfo.SetScale(escala, escala); } catch (e) {}
}

function VerItem(cat, item) {
    wikiCtx = null;   // detalhes abertos: a wiki nao pode sobrescrever o painel
    itemSelecionado = item;
    catSelecionada = cat;
    AtualizarDestaqueBotoesItem();

    var msg = item.nome + " (" + RotuloCat(cat) + ")\n";
    if (cat == "Mobs") {
        var atk = item["tipo de atk"] || "";
        var linhaAtk = atk ? ("Atk: " + atk + " | ") : "";
        var lvValor = item.level || "a definir";
        var linhaLv = "Level: " + lvValor + " | ";
        var linhaUpar = "";
        var perfilAtivo = ObterPerfilAtivo();
        if (perfilAtivo) {
            var qtdMatar = CalcularMobsParaUpar(perfilAtivo.xpRestante, item.xp);
            if (qtdMatar !== null) {
                linhaUpar = "\nPara upar (" + perfilAtivo.xpRestante + " XP): matar " + qtdMatar + "x " + item.nome;
            }
        }
        msg += linhaLv + "HP: " + item.hp + " | XP: " + item.xp + " | Gold: " + item.gold + "\n" +
               linhaAtk + "Fraqueza: " + item.fraqueza + "\n" +
               "Locais: " + item.locais + "\n" +
               "Drops: " + item.drops +
               linhaUpar;
        AtualizarMolduraEstatisticas(true);
        if (webInfoBoss) {
            ExibirTextoStats(msg, MontarHtmlMobDetalhe(item, perfilAtivo));
        } else {
            AjustarEscalaEFonteStats(cat, msg);
            ExibirTextoStats(msg, null);
        }
    } else if (cat == "Bosses") {
        var recompBoss = ObterRecompensaBoss(item);
        var lvBossValor = item.level || "a definir";
        var perfilBoss = ObterPerfilAtivo();
        var reqNum = ExtrairLevelMinimo(lvBossValor);
        var stBoss = StatusBossPerfil(item, perfilBoss, true);
        var avisoBoss = (stBoss === "vermelho") ? " (Level baixo para enfrentar)"
            : (stBoss === "amarelo") ? " (Apenas em grupo)" : "";
        msg += "Level: " + lvBossValor + avisoBoss + "\n" +
               "HP: " + (item.hp || "A definir") + "\n" +
               "XP: " + (item.xp || "A definir") + "\n" +
               "Gold: " + (item.gold !== undefined ? item.gold : "0") + "\n" +
               "Ilha: " + (item.ilha || item.local || "A definir") + "\n" +
               (item.ataques ? "Ataques: " + item.ataques + "\n" : "") +
               (item.fraqueza ? "Fraqueza: " + item.fraqueza + "\n" : "") +
               "Itens dropados aleatoriamente: " + (item.drops || "A definir") + "\n" +
               "Recompensas do Boss: " + recompBoss;
        AtualizarMolduraEstatisticas(true);
        if (webInfoBoss) {
            ExibirTextoStats(msg, MontarHtmlBossDetalhe(item, perfilBoss));
        } else {
            AjustarEscalaEFonteStats(cat, msg);
            ExibirTextoStats(msg, null);
        }
    } else if (cat == "Itens") {
        msg += "\nTipo: " + item.tipo + " | Level: " + item.reqLevel + "\nVocacao: " + item.vocacao +
               "\nStats: " + item.stats + "\nOnde achar: " + item.ondeAchar + (item.obs ? "\nObs: " + item.obs : "");
        AtualizarMolduraEstatisticas(true);
        if (webInfoBoss) {
            ExibirTextoStats(msg, MontarHtmlItemDetalhe(item));
        } else {
            AjustarEscalaEFonteStats("Mobs", msg);
            ExibirTextoStats(msg, null);
        }
    } else if (cat == "Lojas") {
        msg += "\nFaixa: " + (INFO_FAIXA_LOJA[item.faixa] ? INFO_FAIXA_LOJA[item.faixa].titulo : "A definir") + "\nIlha/Cidade: " + item.cidade + "\nLoja/NPC: " + item.npc +
               "\nVende: " + item.itensVenda + "\nToque em uma arma ou armadura abaixo:";
        AjustarEscalaEFonteStats(cat, msg);
        ExibirTextoStats(msg, null);
    } else if (cat == "LojaItem") {
        msg = item.nome + " (" + item.loja + ")\nTipo: " + item.tipo + " | Level: " + item.level +
              "\nVocacao: " + item.vocacao + "\nPreco: " + (item.preco || "A definir") + (item.materiais ? "\nMateriais: " + item.materiais : "") +
              (TextoDanoLoja(item) ? "\nAtaque: " + TextoDanoLoja(item) : (item.elemento ? "\nAtaque elemental: " + item.elemento : "")) +
              (item.mana ? "\nCusto de mana: " + item.mana : "") +
              (TextoDefesaLoja(item) ? "\nDefesa: " + TextoDefesaLoja(item) : "") +
              (item.obs ? "\nObs: " + item.obs : "");
        AtualizarMolduraEstatisticas(true);
        if (webInfoBoss) {
            ExibirTextoStats(msg, MontarHtmlLojaItemDetalhe(item));
        } else {
            AjustarEscalaEFonteStats("Mobs", msg);
            ExibirTextoStats(msg, null);
        }
    }
}

function ConsultarWiki(consulta) {
    PesquisarTutor(consulta);
}